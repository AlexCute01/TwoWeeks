"""
Приём «сигнала об изменении таблицы» вместо опроса.

Откуда приходит сигнал (см. docs/SIGNAL.md):
  • Power Automate: «когда файл изменён» → HTTP POST с самим файлом (скачивать ничего не нужно);
  • Microsoft Graph (change notifications) → «пустой» сигнал, файл бот скачает один раз по SCHEDULE_URL;
  • что угодно ещё, что умеет отправить POST.

Debouncer: пока файл правят, сигналы идут пачкой — ждём DEBOUNCE_MIN минут «тишины» и применяем только
последнюю версию (студентам придёт одно уведомление вместо пяти). Ожидающий файл лежит на диске,
поэтому перезапуск бота ничего не теряет.
"""
import asyncio
import base64
import binascii
import json
import logging
from pathlib import Path

from aiogram import Bot

from .config import settings
from .outbox import alert_admins
from .sync import apply_data, fetch_xlsx
from .util import esc, now_local

log = logging.getLogger(__name__)


def extract_payload(body: bytes) -> bytes | None:
    """Достаёт xlsx из тела запроса. Поддерживает: «сырой» xlsx, JSON с base64, пустой сигнал (None)."""
    if body.startswith(b"PK"):
        return body
    if not body.strip():
        return None
    try:
        j = json.loads(body)
    except ValueError:
        return None
    if isinstance(j, dict):
        b64 = j.get("content") or j.get("$content") or j.get("file_base64") or j.get("body")
        if isinstance(b64, dict):                      # {"$content-type": "...", "$content": "..."}
            b64 = b64.get("$content")
        if isinstance(b64, str):
            try:
                raw = base64.b64decode(b64, validate=False)
            except (binascii.Error, ValueError):
                raise ValueError("bad base64")
            if raw.startswith(b"PK"):
                return raw
            raise ValueError("payload is not an xlsx file")
    return None


class Debouncer:
    def __init__(self) -> None:
        self.bot: Bot | None = None
        self._payload: bytes | None = None
        self._need_fetch = False
        self._task: asyncio.Task | None = None
        self._applying = False
        self._rerun = False
        self._retries = 0
        self._dir = Path(settings.state_dir)

    # --- состояние на диске ---
    def _save(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        if self._payload is not None:
            (self._dir / "pending.xlsx").write_bytes(self._payload)
        if self._need_fetch:
            (self._dir / "pending.fetch").touch()

    def _clear(self) -> None:
        for name in ("pending.xlsx", "pending.fetch"):
            (self._dir / name).unlink(missing_ok=True)

    def restore(self) -> None:
        """После перезапуска: если остался необработанный сигнал — обработать."""
        f = self._dir / "pending.xlsx"
        if f.exists():
            self._payload = f.read_bytes()
        self._need_fetch = (self._dir / "pending.fetch").exists()
        if self._payload is not None or self._need_fetch:
            log.info("restored pending signal")
            self._arm(delay=5)

    # --- публичное API ---
    def submit(self, data: bytes | None, source: str = "hook") -> None:
        log.info("signal from %s (with_file=%s)", source, data is not None)
        if data is not None:
            self._payload = data
        else:
            self._need_fetch = True
        self._save()
        if self._applying:
            self._rerun = True
        else:
            self._arm()

    # --- внутреннее ---
    def _arm(self, delay: float | None = None) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
        self._task = asyncio.create_task(self._run(settings.debounce_min * 60 if delay is None else delay))

    async def _run(self, delay: float) -> None:
        await asyncio.sleep(delay)          # отмена возможна только здесь — пока ждём «тишины»
        self._applying = True
        try:
            await self._apply()
        except Exception:
            log.exception("debouncer apply")
        finally:
            self._applying = False
            if self._rerun:
                self._rerun = False
                self._arm()

    async def _apply(self) -> None:
        data, need_fetch = self._payload, self._need_fetch
        if need_fetch or data is None:
            try:
                data = await fetch_xlsx()            # пустой сигнал: файл забираем по ссылке ОДИН раз
            except Exception as e:
                self._retries += 1
                if self._retries < 4:
                    log.warning("fetch failed (%s), retry %s", e, self._retries)
                    self._arm(delay=120)
                    return
                self._retries = 0
                self._payload, self._need_fetch = None, False
                self._clear()
                await alert_admins(f"⚠️ Пришёл сигнал об изменении файла, но скачать его не удалось:\n{esc(str(e))}",
                                   key=f"fetch:{now_local():%Y%m%d%H}")
                return
        self._retries = 0
        self._payload, self._need_fetch = None, False
        self._clear()
        res = await apply_data(data, self.bot)
        log.info("signal applied: %s", res)
        if "Изменений:" in res or "⚠️" in res:
            await alert_admins(f"📥 Сигнал обработан.\n{esc(res)}", key=f"sig:{now_local():%Y%m%d%H%M%S}")


debouncer = Debouncer()
