from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    bot_token: str
    database_url: str = "sqlite+aiosqlite:///./bot.db"
    schedule_url: str = ""                # ссылка на xlsx (SharePoint)
    admin_ids: str = ""                   # "123456,789012" — кто может слать xlsx и делать /sync
    timezone: str = "Asia/Almaty"
    # Дата начала семестра: от неё считается чётность недели.
    # Неделя, в которую попадает эта дата, считается НЕЧЁТНОЙ (1-я).
    semester_start: str = "2026-09-01"

    # --- сигнал об изменении файла (push, без опроса) ---
    hook_secret: str = ""                 # общий секрет для /hook/*; ПУСТО = приём сигналов выключен
    web_port: int = 8080                  # слушаем только 127.0.0.1, наружу смотрит Caddy (HTTPS)
    state_dir: str = "./state"            # сюда пишется «ожидающий» файл (переживает перезапуск)
    debounce_min: int = 2                 # после последнего сигнала ждём N минут «тишины» и только потом применяем
    min_lessons_ratio: float = 0.5        # если в новом файле пар < 50% от текущих — считаем файл сломанным
    include_hidden_sheets: bool = False   # скрытые листы = архив/черновики, по умолчанию пропускаем
    fallback_poll_min: int = 0            # 0 = опроса нет. Если >0 — редкая «страховочная» проверка по SCHEDULE_URL

    @property
    def admins(self) -> set[int]:
        return {int(x) for x in self.admin_ids.split(",") if x.strip()}


settings = Settings()

# Для самой первой пары дня напоминаем на столько минут раньше (время на сборы)
FIRST_PAIR_EXTRA_MIN = 20
# Доступные варианты «напомнить за N минут»
LEADS = (5, 10, 15, 30)
