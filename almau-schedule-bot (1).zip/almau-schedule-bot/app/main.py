"""Точка входа: Telegram (long polling) + HTTP для сигналов + фоновые циклы (очередь отправки, напоминания)."""
import asyncio
import logging
from pathlib import Path

import yaml
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from .cache import cache
from .config import settings
from .db import Room, Session, init_db
from .handlers import router
from .notify import run_due
from .outbox import sender_loop
from .signals import debouncer
from .util import norm_room
from .web import start_web

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")


async def seed_rooms() -> None:
    """Загружает data/rooms.yaml — только те аудитории, которых ещё нет в БД."""
    path = Path(__file__).parent.parent / "data" / "rooms.yaml"
    if not path.exists():
        return
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or []
    async with Session() as s:
        for r in data:
            code = norm_room(str(r["code"]))
            if not await s.get(Room, code):
                s.add(Room(code=code, building=r.get("building", ""), floor=r.get("floor"),
                           description=r.get("description", "")))
        await s.commit()


async def tick_loop() -> None:
    while True:
        try:
            await run_due()
        except Exception:
            log.exception("tick_loop")
        await asyncio.sleep(20)


async def fallback_loop() -> None:
    """Необязательная страховка (FALLBACK_POLL_MIN > 0): редкий «пустой сигнал» на случай потерянного сигнала."""
    while True:
        await asyncio.sleep(settings.fallback_poll_min * 60)
        debouncer.submit(None, source="fallback")


async def main() -> None:
    await init_db()
    await seed_rooms()
    await cache.reload()

    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    debouncer.bot = bot
    dp = Dispatcher()
    dp.include_router(router)

    runner = await start_web()
    debouncer.restore()
    loops = [sender_loop(bot), tick_loop()]
    if settings.fallback_poll_min > 0 and settings.schedule_url:
        loops.append(fallback_loop())
    tasks = [asyncio.create_task(c) for c in loops]
    try:
        await bot.delete_webhook(drop_pending_updates=False)
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        for t in tasks:
            t.cancel()
        await runner.cleanup()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
