"""
Применение нового файла расписания и рассылка об изменениях.

Файл приходит СИГНАЛОМ (см. signals.py / web.py) — бот его сам не опрашивает.
apply_data():
  1. хэш не изменился — ничего не делаем;
  2. защита: если в новом файле пар подозрительно мало (сломанный / недоредактированный файл) —
     расписание НЕ применяем, пишем админам;
  3. считаем точный дифф по каждой группе, пишем журнал и кладём уведомления в очередь outbox
     В ТОЙ ЖЕ ТРАНЗАКЦИИ, что и новое расписание (либо всё, либо ничего);
  4. уведомляем только тех, кого это касается (группа, подгруппа, не скрытые предметы);
     изменения на сегодня/завтра — «срочно», с высоким приоритетом.
"""
import asyncio
import hashlib
import logging
from collections import defaultdict

import httpx
from aiogram import Bot
from sqlalchemy import delete, select

from .cache import cache
from .changes import Change, Entry, Slot, build_message, describe, diff_group, is_relevant, slot_of
from .config import settings
from .db import ChangeLog, Group, HiddenSubject, Lesson, Session, User, meta_get, meta_set
from .outbox import PRIO_CHANGE, PRIO_URGENT, alert_admins, enqueue_many
from .parser import parse_workbook_ex
from .util import esc, now_local

log = logging.getLogger(__name__)


class SuspiciousFile(Exception):
    pass


async def fetch_xlsx(url: str | None = None) -> bytes:
    """Скачать файл по ссылке — только когда пришёл «пустой» сигнал без самого файла (или /sync у админа)."""
    url = url or settings.schedule_url
    if not url:
        raise ValueError("SCHEDULE_URL не задан")
    direct = url if "download=1" in url else url + ("&" if "?" in url else "?") + "download=1"
    async with httpx.AsyncClient(follow_redirects=True, timeout=60) as client:
        r = await client.get(direct)
    if r.status_code != 200 or not r.content.startswith(b"PK"):
        raise ValueError(
            "Не удалось скачать xlsx: ссылка, скорее всего, требует входа в аккаунт. "
            "Настрой сигнал так, чтобы файл приходил вместе с ним (docs/SIGNAL.md), или пришли файл боту.")
    return r.content


async def apply_data(data: bytes, bot: Bot | None = None, force: bool = False) -> str:
    """Безопасно применить файл. Ошибки не пробрасывает — возвращает текст и предупреждает админов."""
    digest = hashlib.sha256(data).hexdigest()
    async with Session() as s:
        if not force:
            if digest == await meta_get(s, "xlsx_hash"):
                return "Файл не изменился."
            if digest == await meta_get(s, "rejected_hash"):
                return "Этот файл уже отклонён как подозрительный."
    try:
        return await import_xlsx(data, bot, force=force)
    except SuspiciousFile as e:
        async with Session() as s:
            await meta_set(s, "rejected_hash", digest)
            await s.commit()
        await alert_admins(f"⚠️ {esc(str(e))}\n\nЕсли файл верный — пришли его сюда, импортирую принудительно.",
                           key=f"susp:{digest[:10]}")
        return str(e)
    except Exception as e:
        log.exception("apply_data failed")
        await alert_admins(f"❌ Не удалось применить файл расписания:\n{esc(str(e))}", key=f"err:{digest[:10]}")
        return f"Ошибка: {e}"


def _slots(entries) -> dict[Slot, list[Entry]]:
    d: dict[Slot, list[Entry]] = defaultdict(list)
    for slot, e in entries:
        d[slot].append(e)
    return d


async def import_xlsx(data: bytes, bot: Bot | None = None, force: bool = False) -> str:
    digest = hashlib.sha256(data).hexdigest()
    # разбор ~15 секунд процессора — в отдельном потоке, чтобы бот не «замирал»
    dtos, report = await asyncio.to_thread(parse_workbook_ex, data, settings.include_hidden_sheets)
    if not dtos:
        raise ValueError("Не нашёл ни одной пары: структура файла отличается от ожидаемой (см. parser.py).")
    now = now_local()

    async with Session() as s:
        if not force and digest == await meta_get(s, "xlsx_hash"):
            return "Файл не изменился — импорт не нужен."

        # --- что было ---
        old_by_group: dict[str, list] = defaultdict(list)
        old_count = 0
        rows = await s.execute(select(Group.name, Lesson).join(Lesson, Lesson.group_id == Group.id))
        for gname, l in rows:
            old_by_group[gname].append((slot_of(l.weekday, l.start, l.parity, l.subgroup),
                                        (l.subject, l.teacher, l.room, l.start, l.end)))
            old_count += 1

        if old_count and len(dtos) < old_count * settings.min_lessons_ratio and not force:
            raise SuspiciousFile(
                f"В новом файле пар: {len(dtos)}, а в текущем расписании: {old_count}. "
                "Похоже на сбой или недоредактированный файл — расписание НЕ обновлено.")

        # --- что стало ---
        new_by_group: dict[str, list] = defaultdict(list)
        for d in dtos:
            new_by_group[d.group].append((slot_of(d.weekday, d.start, d.parity, d.subgroup),
                                          (d.subject, d.teacher, d.room, d.start, d.end)))
        present = set(new_by_group) | set(report.groups)      # группы с корректной структурой листа

        groups = {g.name: g for g in await s.scalars(select(Group))}
        for name in present:
            if name not in groups:
                g = Group(name=name)
                s.add(g)
                await s.flush()
                groups[name] = g

        # заменяем пары только тех групп, что есть в файле (пропавшая группа не «обнуляется»)
        await s.execute(delete(Lesson).where(Lesson.group_id.in_([groups[n].id for n in present])))
        for d in dtos:
            s.add(Lesson(group_id=groups[d.group].id, weekday=d.weekday, pair_no=d.pair_no,
                         start=d.start, end=d.end, subject=d.subject, teacher=d.teacher,
                         room=d.room, kind=d.kind, parity=d.parity, subgroup=d.subgroup))

        # --- дифф и уведомления (в той же транзакции) ---
        changes: dict[int, tuple[str, list[Change]]] = {}
        if old_count:
            for name in present:
                if name not in old_by_group:
                    continue  # новая группа — уведомлять не о чем
                ch = diff_group(_slots(old_by_group[name]), _slots(new_by_group.get(name, [])))
                if ch:
                    changes[groups[name].id] = (name, ch)

        queued = 0
        if changes:
            for gid, (_, chs) in changes.items():
                for c in chs:
                    s.add(ChangeLog(group_id=gid, created_at=now, text=describe(c)))
            users = list(await s.scalars(select(User).where(
                User.group_id.in_(list(changes)), User.changes_on.is_(True), User.blocked.is_(False))))
            hidden: dict[int, list[str]] = defaultdict(list)
            if users:
                hrows = await s.execute(select(HiddenSubject.user_id, HiddenSubject.subject).where(
                    HiddenSubject.user_id.in_([u.tg_id for u in users])))
                for uid, subj in hrows:
                    hidden[uid].append(subj.lower())
            items = []
            for u in users:
                name, chs = changes[u.group_id]
                rel = [c for c in chs if is_relevant(c, u.subgroup, hidden[u.tg_id])]
                if not rel:
                    continue
                text, urgent = build_message(name, rel, now)
                items.append(dict(user_id=u.tg_id, text=text, dedupe_key=f"chg:{digest[:12]}:{u.tg_id}",
                                  priority=PRIO_URGENT if urgent else PRIO_CHANGE))
            queued = await enqueue_many(s, items)

        await meta_set(s, "xlsx_hash", digest)
        await meta_set(s, "applied_at", now.isoformat())
        await s.commit()

    await cache.reload()
    summary = f"Пар: {len(dtos)}, групп: {len(present)}."
    if changes:
        n_ch = sum(len(c) for _, c in changes.values())
        summary += f" Изменений: {n_ch} у {len(changes)} групп, уведомлений в очереди: {queued}."
    elif old_count:
        summary += " Изменений в парах нет."
    if report.sheets_failed:
        summary += f"\n⚠️ Листы, структуру которых не распознал: {', '.join(report.sheets_failed)}."
    return summary
