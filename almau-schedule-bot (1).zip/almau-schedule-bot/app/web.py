"""Маленький HTTP-сервер для сигналов. Слушает 127.0.0.1, наружу его выставляет Caddy (HTTPS)."""
import hmac
import logging

from aiohttp import web

from .config import settings
from .signals import debouncer, extract_payload

log = logging.getLogger(__name__)


def _authorized(request: web.Request) -> bool:
    if not settings.hook_secret:                      # секрет не задан — приём сигналов выключен
        return False
    given = request.headers.get("X-Hook-Secret") or request.query.get("secret", "")
    return hmac.compare_digest(given.encode(), settings.hook_secret.encode())


async def health(_: web.Request) -> web.Response:
    return web.json_response({"ok": True})


async def hook_schedule(request: web.Request) -> web.Response:
    """Power Automate / любой отправитель: POST с файлом (raw / JSON+base64) или пустой."""
    if not _authorized(request):
        return web.Response(status=403, text="forbidden")
    body = await request.read()
    try:
        data = extract_payload(body)
    except ValueError as e:
        return web.Response(status=400, text=str(e))
    debouncer.submit(data, source="hook")
    return web.json_response({"queued": True, "with_file": data is not None}, status=202)


async def hook_graph(request: web.Request) -> web.Response:
    """Microsoft Graph change notifications: рукопожатие + уведомления."""
    token = request.query.get("validationToken")
    if token:                                         # проверка при создании подписки: вернуть токен как есть
        return web.Response(text=token, content_type="text/plain")
    try:
        payload = await request.json()
    except Exception:
        return web.Response(status=400)
    ok = any(n.get("clientState") == settings.hook_secret for n in payload.get("value", [])) \
        if settings.hook_secret else False
    if ok:
        debouncer.submit(None, source="graph")
    return web.Response(status=202)                   # Graph ждёт ответ быстро (до 3 секунд)


def make_app() -> web.Application:
    app = web.Application(client_max_size=25 * 1024 * 1024)
    app.add_routes([
        web.get("/health", health),
        web.post("/hook/schedule", hook_schedule),
        web.post("/hook/graph", hook_graph),
    ])
    return app


async def start_web() -> web.AppRunner:
    runner = web.AppRunner(make_app())
    await runner.setup()
    await web.TCPSite(runner, "127.0.0.1", settings.web_port).start()
    log.info("web: listening on 127.0.0.1:%s", settings.web_port)
    return runner
