#!/usr/bin/env bash
# Установка на Oracle Cloud VM (Ubuntu 22.04/24.04, ARM или x86). Запуск от root из папки проекта:
#   sudo DOMAIN=mybot.duckdns.org bash deploy/setup.sh
# Необязательно: DUCKDNS_TOKEN=... — cron будет обновлять IP домена на duckdns.org
set -euo pipefail
: "${DOMAIN:?Укажи домен: sudo DOMAIN=mybot.duckdns.org bash deploy/setup.sh}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
export DEBIAN_FRONTEND=noninteractive

apt-get update -y
apt-get install -y python3-venv python3-pip sqlite3 rsync curl gnupg iptables-persistent \
  debian-keyring debian-archive-keyring apt-transport-https

# Swap — страховка, если RAM меньше 2 ГБ (x86 Micro)
if [ "$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)" -lt 2000 ] && ! swapon --show | grep -q swapfile; then
  fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

# Приложение
id bot &>/dev/null || useradd --system --home /opt/schedule-bot --shell /usr/sbin/nologin bot
mkdir -p /opt/schedule-bot
rsync -a --delete --exclude venv --exclude '*.db*' --exclude state "$SRC"/ /opt/schedule-bot/
python3 -m venv /opt/schedule-bot/venv
/opt/schedule-bot/venv/bin/pip install --no-cache-dir -r /opt/schedule-bot/requirements.txt
chown -R bot:bot /opt/schedule-bot

# Настройки
if [ ! -f /etc/schedule-bot.env ]; then
  cp /opt/schedule-bot/.env.example /etc/schedule-bot.env
  sed -i "s|^HOOK_SECRET=.*|HOOK_SECRET=$(openssl rand -hex 24)|" /etc/schedule-bot.env
  chmod 600 /etc/schedule-bot.env
  echo ">>> Заполни BOT_TOKEN и ADMIN_IDS:  sudo nano /etc/schedule-bot.env"
fi

# Caddy (HTTPS)
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy
fi
sed "s|__DOMAIN__|$DOMAIN|" /opt/schedule-bot/deploy/Caddyfile.template > /etc/caddy/Caddyfile
systemctl enable caddy && systemctl reload-or-restart caddy

# Firewall внутри VM: Oracle-образы Ubuntu по умолчанию режут всё, кроме SSH
for p in 80 443; do
  iptables -C INPUT -p tcp --dport $p -j ACCEPT 2>/dev/null || iptables -I INPUT 1 -p tcp --dport $p -j ACCEPT
done
netfilter-persistent save

# Сервис бота
cp /opt/schedule-bot/deploy/schedule-bot.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable schedule-bot
systemctl restart schedule-bot

# Бэкап БД раз в сутки
cp /opt/schedule-bot/deploy/backup.sh /usr/local/bin/schedule-bot-backup && chmod +x /usr/local/bin/schedule-bot-backup
echo '30 4 * * * root /usr/local/bin/schedule-bot-backup' > /etc/cron.d/schedule-bot-backup

# DuckDNS: держим IP домена актуальным
if [ -n "${DUCKDNS_TOKEN:-}" ] && [[ "$DOMAIN" == *.duckdns.org ]]; then
  echo "*/10 * * * * root curl -s 'https://www.duckdns.org/update?domains=${DOMAIN%.duckdns.org}&token=$DUCKDNS_TOKEN&ip=' >/dev/null" > /etc/cron.d/duckdns
fi

echo
echo "Готово. Проверка:   curl https://$DOMAIN/health"
echo "Секрет для сигналов: $(grep ^HOOK_SECRET /etc/schedule-bot.env | cut -d= -f2)"
echo "Логи:               journalctl -u schedule-bot -f"
