#!/usr/bin/env bash
# Ежедневная консистентная копия SQLite; хранится 14 дней. (В бесплатном Oracle автобэкапов нет!)
set -euo pipefail
DB=/var/lib/schedule-bot/bot.db
DIR=/var/backups/schedule-bot
mkdir -p "$DIR"
sqlite3 "$DB" ".backup '$DIR/bot-$(date +%F).db'"
gzip -f "$DIR/bot-$(date +%F).db"
find "$DIR" -name 'bot-*.db.gz' -mtime +14 -delete
