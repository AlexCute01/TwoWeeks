@echo off
cd /d "%~dp0"
title Journalisti.CO local server
echo ================================================================
echo  Starting Journalisti.CO server...
echo  Open: http://localhost:8080
echo ================================================================
start "" "http://localhost:8080"
where py >nul 2>nul && (py server.py) || (python server.py)
pause
