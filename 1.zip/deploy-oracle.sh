#!/usr/bin/env bash
# ==============================================================================
# Journalisti.CO — Автоматический деплой на Oracle Cloud Compute VM
# Поддерживает: Ubuntu 20.04 / 22.04 / 24.04 и Oracle Linux 8 / 9 (ARM64 и AMD64)
# Запуск: sudo bash deploy-oracle.sh [ВАШ_ПАРОЛЬ_РЕДАКЦИИ] [ВАШ_ДОМЕН_ОПЦИОНАЛЬНО]
# ==============================================================================
set -e

ADMIN_PASS="${1:-journalisti2026}"
DOMAIN="${2:-_}"
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_PORT=8080

echo "================================================================"
echo "✦ Установка и настройка Journalisti.CO для Oracle Cloud..."
echo "✦ Рабочая директория: $APP_DIR"
echo "================================================================"

# 1. Установка Python3 и Nginx
if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y python3 nginx iptables-persistent || apt-get install -y python3 nginx
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 nginx firewalld
fi

# 2. Открытие портов 80 и 443 во внутреннем файрволе Oracle Cloud VM (iptables / firewalld)
echo "✦ Настройка правил файрвола Oracle Cloud (порты 80 и 443)..."
if command -v iptables >/dev/null 2>&1; then
    iptables -I INPUT 1 -p tcp --dport 80 -j ACCEPT || true
    iptables -I INPUT 1 -p tcp --dport 443 -j ACCEPT || true
    if command -v netfilter-persistent >/dev/null 2>&1; then
        netfilter-persistent save || true
    fi
fi
if command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
    firewall-cmd --permanent --add-service=http || true
    firewall-cmd --permanent --add-service=https || true
    firewall-cmd --reload || true
fi

# 3. Создание systemd-сервиса journalisti.service
echo "✦ Настройка фонового сервиса systemd (journalisti.service)..."
cat >/etc/systemd/system/journalisti.service <<EOF
[Unit]
Description=Journalisti.CO Editorial Platform & CMS
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment="PORT=$APP_PORT"
Environment="HOST=127.0.0.1"
Environment="ADMIN_PASSWORD=$ADMIN_PASS"
ExecStart=/usr/bin/python3 $APP_DIR/server.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable journalisti.service
systemctl restart journalisti.service

# 4. Настройка Nginx Reverse Proxy
echo "✦ Настройка веб-сервера Nginx..."
NGINX_CONF="/etc/nginx/sites-available/journalisti"
if [ ! -d "/etc/nginx/sites-available" ]; then
    NGINX_CONF="/etc/nginx/conf.d/journalisti.conf"
fi

cat >"$NGINX_CONF" <<EOF
server {
    listen 80;
    server_name $DOMAIN;

    client_max_body_size 35M;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;

    location / {
        proxy_pass http://127.0.0.1:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

if [ -d "/etc/nginx/sites-enabled" ]; then
    ln -sf "$NGINX_CONF" /etc/nginx/sites-enabled/journalisti
    rm -f /etc/nginx/sites-enabled/default
fi

nginx -t
systemctl enable nginx
systemctl restart nginx

PUBLIC_IP=$(curl -s --max-time 4 ifconfig.me || hostname -I | awk '{print $1}')

echo "================================================================"
echo "✅ Journalisti.CO успешно развёрнут на Oracle Cloud!"
echo "🌐 Адрес сайта:       http://${PUBLIC_IP}"
echo "✦ Студия редакции:   http://${PUBLIC_IP}/#studio"
echo "🔑 Пароль редакции:   ${ADMIN_PASS}"
echo "================================================================"
echo "Не забудьте убедиться, что в панели Oracle Cloud (VCN -> Security Lists -> Ingress Rules)"
echo "открыт доступ для 0.0.0.0/0 на TCP-порты 80 и 443."
