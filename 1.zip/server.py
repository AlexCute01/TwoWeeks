#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Journalisti.CO — Editorial Publishing Server & CMS Backend
Ready for Oracle Cloud Compute VM (Ubuntu / Oracle Linux), Docker, and Local Run.
Zero external dependencies required (uses Python 3 standard library: sqlite3, http.server, json).
"""

import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import shutil
import sqlite3
import sys
import time
import urllib.parse
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = BASE_DIR / "uploads"
DB_PATH = DATA_DIR / "journalisti.db"
SEED_PATH = DATA_DIR / "seed_data.json"
LIVE_JSON_PATH = DATA_DIR / "live_state.json"

PORT = int(os.environ.get("PORT", "8080"))
HOST = os.environ.get("HOST", "0.0.0.0")
DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "journalisti2026")
SECRET_SALT = os.environ.get("SECRET_SALT", "journalisti-co-liquid-glass-secret-2026")


def hash_password(password: str) -> str:
    return hmac.new(
        SECRET_SALT.encode("utf-8"),
        password.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def make_token(password_hash: str) -> str:
    return hmac.new(
        SECRET_SALT.encode("utf-8"),
        f"session:{password_hash}".encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def init_storage():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

    # Copy root demo images to uploads if not already there
    for img in list(BASE_DIR.glob("100008707*_2.jpg")) + list(BASE_DIR.glob("case-*.jpg")) + list(BASE_DIR.glob("pavlodar-*.jpg")) + list(BASE_DIR.glob("zhailau-*.*")):
        target = UPLOADS_DIR / img.name
        if not target.exists():
            try:
                shutil.copy2(img, target)
            except OSError:
                pass

    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS kv_store (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at REAL NOT NULL
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS articles (
                id TEXT PRIMARY KEY,
                slug TEXT NOT NULL,
                sort_order INTEGER NOT NULL DEFAULT 0,
                is_cover INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'published',
                data TEXT NOT NULL,
                updated_at REAL NOT NULL
            )
            """
        )

        # Ensure admin password hash exists
        cur.execute("SELECT value FROM kv_store WHERE key = 'admin_password_hash'")
        if not cur.fetchone():
            cur.execute(
                "INSERT INTO kv_store (key, value, updated_at) VALUES (?, ?, ?)",
                ("admin_password_hash", hash_password(DEFAULT_ADMIN_PASSWORD), time.time()),
            )

        # Seed initial data if empty
        cur.execute("SELECT COUNT(*) FROM articles")
        count = cur.fetchone()[0]
        if count == 0 and SEED_PATH.exists():
            seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))
            settings = seed.get("settings", {})
            articles = seed.get("articles", [])

            cur.execute(
                "INSERT OR REPLACE INTO kv_store (key, value, updated_at) VALUES (?, ?, ?)",
                ("settings", json.dumps(settings, ensure_ascii=False), time.time()),
            )
            for idx, art in enumerate(articles):
                art_id = art.get("id") or f"article-{idx+1}"
                art["id"] = art_id
                art["slug"] = art.get("slug") or art_id
                cur.execute(
                    """
                    INSERT OR REPLACE INTO articles (id, slug, sort_order, is_cover, status, data, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        art_id,
                        art["slug"],
                        idx,
                        1 if art.get("isCoverStory") else 0,
                        art.get("status", "published"),
                        json.dumps(art, ensure_ascii=False),
                        time.time(),
                    ),
                )
        conn.commit()
    finally:
        conn.close()

    sync_json_snapshot()


def get_admin_password_hash() -> str:
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute("SELECT value FROM kv_store WHERE key = 'admin_password_hash'")
        row = cur.fetchone()
        return row[0] if row else hash_password(DEFAULT_ADMIN_PASSWORD)
    finally:
        conn.close()


def verify_token(token: str) -> bool:
    if not token:
        return False
    expected = make_token(get_admin_password_hash())
    return hmac.compare_digest(token, expected)


def load_state():
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute("SELECT value FROM kv_store WHERE key = 'settings'")
        row = cur.fetchone()
        settings = json.loads(row[0]) if row else {}

        cur.execute("SELECT data FROM articles ORDER BY sort_order ASC, updated_at DESC")
        articles = [json.loads(r[0]) for r in cur.fetchall()]
        return {"settings": settings, "articles": articles}
    finally:
        conn.close()


def sync_json_snapshot():
    state = load_state()
    LIVE_JSON_PATH.write_text(
        json.dumps(state, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return state


def save_settings(settings: dict):
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT OR REPLACE INTO kv_store (key, value, updated_at) VALUES (?, ?, ?)",
            ("settings", json.dumps(settings, ensure_ascii=False), time.time()),
        )
        conn.commit()
    finally:
        conn.close()
    return sync_json_snapshot()


def slugify(text: str) -> str:
    tr = {
        "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "yo",
        "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
        "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
        "ф": "f", "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch",
        "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
    }
    res = []
    for ch in text.lower():
        if ch in tr:
            res.append(tr[ch])
        elif ch.isalnum():
            res.append(ch)
        else:
            res.append("-")
    slug = re.sub(r"-+", "-", "".join(res)).strip("-")
    return slug[:64] or f"post-{int(time.time())}"


def upsert_article(article: dict):
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        art_id = (article.get("id") or "").strip()
        if not art_id:
            art_id = slugify(article.get("title") or "new-article") + "-" + str(int(time.time()))[-4:]
            article["id"] = art_id
        article["slug"] = (article.get("slug") or slugify(article.get("title") or art_id)).strip()

        # Check if article already exists
        cur.execute("SELECT sort_order FROM articles WHERE id = ?", (art_id,))
        existing = cur.fetchone()
        if existing is not None:
            sort_order = existing[0]
        else:
            # Place new bento articles right after cover story or at the top
            cur.execute("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM articles")
            sort_order = cur.fetchone()[0]

        # If this article is marked as Cover Story, unset isCoverStory on others
        if article.get("isCoverStory"):
            cur.execute("SELECT id, data FROM articles WHERE id != ?", (art_id,))
            for other_id, other_json in cur.fetchall():
                other_data = json.loads(other_json)
                if other_data.get("isCoverStory"):
                    other_data["isCoverStory"] = False
                    # Make sure former cover story stays visible in Bento if needed
                    cur.execute(
                        "UPDATE articles SET is_cover = 0, data = ?, updated_at = ? WHERE id = ?",
                        (json.dumps(other_data, ensure_ascii=False), time.time(), other_id),
                    )

        cur.execute(
            """
            INSERT OR REPLACE INTO articles (id, slug, sort_order, is_cover, status, data, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                art_id,
                article["slug"],
                sort_order,
                1 if article.get("isCoverStory") else 0,
                article.get("status", "published"),
                json.dumps(article, ensure_ascii=False),
                time.time(),
            ),
        )
        conn.commit()
    finally:
        conn.close()
    return sync_json_snapshot()


def delete_article(article_id: str):
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute("DELETE FROM articles WHERE id = ?", (article_id,))
        conn.commit()
    finally:
        conn.close()
    return sync_json_snapshot()


def reorder_articles(ordered_ids: list):
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        for idx, art_id in enumerate(ordered_ids):
            cur.execute(
                "UPDATE articles SET sort_order = ?, updated_at = ? WHERE id = ?",
                (idx, time.time(), art_id),
            )
        conn.commit()
    finally:
        conn.close()
    return sync_json_snapshot()


def replace_full_state(payload: dict):
    settings = payload.get("settings")
    articles = payload.get("articles")
    if not isinstance(settings, dict) or not isinstance(articles, list):
        raise ValueError("Некорректный формат данных: требуются поля settings и articles")

    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT OR REPLACE INTO kv_store (key, value, updated_at) VALUES (?, ?, ?)",
            ("settings", json.dumps(settings, ensure_ascii=False), time.time()),
        )
        cur.execute("DELETE FROM articles")
        for idx, art in enumerate(articles):
            art_id = art.get("id") or f"article-{idx+1}"
            art["id"] = art_id
            art["slug"] = art.get("slug") or slugify(art.get("title") or art_id)
            cur.execute(
                """
                INSERT INTO articles (id, slug, sort_order, is_cover, status, data, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    art_id,
                    art["slug"],
                    idx,
                    1 if art.get("isCoverStory") else 0,
                    art.get("status", "published"),
                    json.dumps(art, ensure_ascii=False),
                    time.time(),
                ),
            )
        conn.commit()
    finally:
        conn.close()
    return sync_json_snapshot()


def list_media_files():
    items = []
    seen = set()
    # Root images
    for ext in ("*.jpg", "*.jpeg", "*.png", "*.webp", "*.gif", "*.svg"):
        for p in sorted(BASE_DIR.glob(ext)):
            seen.add(p.name)
            items.append({
                "name": p.name,
                "url": p.name,
                "size": p.stat().st_size,
            })
        for p in sorted(UPLOADS_DIR.glob(ext)):
            if p.name not in seen:
                seen.add(p.name)
                items.append({
                    "name": p.name,
                    "url": f"uploads/{p.name}",
                    "size": p.stat().st_size,
                })
    return items


class JournalistiRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE_DIR), **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Admin-Token")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def get_auth_token(self) -> str:
        token = self.headers.get("X-Admin-Token", "").strip()
        if not token:
            auth = self.headers.get("Authorization", "").strip()
            if auth.lower().startswith("bearer "):
                token = auth[7:].strip()
        return token

    def send_json(self, data: dict, status: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        if length > 35 * 1024 * 1024:
            raise ValueError("Размер запроса превышает 35 МБ")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/health":
            return self.send_json({"status": "ok", "service": "Journalisti.CO", "timestamp": int(time.time())})

        if path == "/api/state":
            state = load_state()
            is_auth = verify_token(self.get_auth_token())
            return self.send_json({
                "ok": True,
                "isAuthenticated": is_auth,
                "serverMode": "oracle-cloud",
                "settings": state["settings"],
                "articles": state["articles"],
                "media": list_media_files(),
            })

        if path == "/api/media":
            return self.send_json({"ok": True, "media": list_media_files()})

        # Clean route fallback: serve index.html for /article/* or /studio
        if path.startswith("/article/") or path == "/studio":
            self.path = "/index.html"

        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        try:
            body = self.read_json_body()
        except Exception as exc:
            return self.send_json({"ok": False, "error": f"Ошибка чтения JSON: {exc}"}, 400)

        if path == "/api/auth/login":
            password = str(body.get("password", ""))
            current_hash = get_admin_password_hash()
            if hmac.compare_digest(hash_password(password), current_hash):
                return self.send_json({
                    "ok": True,
                    "token": make_token(current_hash),
                })
            return self.send_json({"ok": False, "error": "Неверный пароль редакции"}, 401)

        # All mutating endpoints below require valid editorial token
        if not verify_token(self.get_auth_token()):
            return self.send_json({"ok": False, "error": "Требуется авторизация редакции"}, 401)

        if path == "/api/auth/password":
            new_password = str(body.get("newPassword", "")).strip()
            if len(new_password) < 4:
                return self.send_json({"ok": False, "error": "Пароль должен содержать минимум 4 символа"}, 400)
            new_hash = hash_password(new_password)
            conn = sqlite3.connect(DB_PATH)
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT OR REPLACE INTO kv_store (key, value, updated_at) VALUES (?, ?, ?)",
                    ("admin_password_hash", new_hash, time.time()),
                )
                conn.commit()
            finally:
                conn.close()
            return self.send_json({"ok": True, "token": make_token(new_hash)})

        if path == "/api/articles":
            article = body.get("article")
            if not isinstance(article, dict) or not str(article.get("title", "")).strip():
                return self.send_json({"ok": False, "error": "Укажите заголовок статьи"}, 400)
            state = upsert_article(article)
            return self.send_json({"ok": True, "article": article, **state})

        if path == "/api/articles/reorder":
            ids = body.get("ids", [])
            if not isinstance(ids, list):
                return self.send_json({"ok": False, "error": "Ожидался список ID"}, 400)
            state = reorder_articles(ids)
            return self.send_json({"ok": True, **state})

        if path == "/api/settings":
            settings = body.get("settings")
            if not isinstance(settings, dict):
                return self.send_json({"ok": False, "error": "Некорректные настройки"}, 400)
            state = save_settings(settings)
            return self.send_json({"ok": True, **state})

        if path == "/api/upload":
            filename = str(body.get("filename", "image.jpg"))
            data_url = str(body.get("dataUrl", ""))
            if not data_url or "," not in data_url:
                return self.send_json({"ok": False, "error": "Не переданы данные изображения"}, 400)

            header, b64_data = data_url.split(",", 1)
            ext = Path(filename).suffix.lower()
            if ext not in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".svg"):
                if "png" in header:
                    ext = ".png"
                elif "webp" in header:
                    ext = ".webp"
                elif "gif" in header:
                    ext = ".gif"
                else:
                    ext = ".jpg"

            safe_stem = slugify(Path(filename).stem)[:40] or "photo"
            unique_name = f"{int(time.time())}_{safe_stem}{ext}"
            out_path = UPLOADS_DIR / unique_name

            raw_bytes = base64.b64decode(b64_data)
            out_path.write_bytes(raw_bytes)
            rel_url = f"uploads/{unique_name}"
            return self.send_json({
                "ok": True,
                "url": rel_url,
                "name": unique_name,
                "media": list_media_files(),
            })

        if path == "/api/import":
            try:
                state = replace_full_state(body)
                return self.send_json({"ok": True, **state})
            except Exception as exc:
                return self.send_json({"ok": False, "error": str(exc)}, 400)

        if path == "/api/reset":
            if SEED_PATH.exists():
                seed = json.loads(SEED_PATH.read_text(encoding="utf-8"))
                state = replace_full_state(seed)
                return self.send_json({"ok": True, **state})
            return self.send_json({"ok": False, "error": "Файл seed_data.json не найден"}, 404)

        return self.send_json({"ok": False, "error": "Маршрут не найден"}, 404)

    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if not verify_token(self.get_auth_token()):
            return self.send_json({"ok": False, "error": "Требуется авторизация редакции"}, 401)

        if path.startswith("/api/articles/"):
            art_id = urllib.parse.unquote(path[len("/api/articles/"):]).strip("/")
            if not art_id:
                return self.send_json({"ok": False, "error": "Не указан ID статьи"}, 400)
            state = delete_article(art_id)
            return self.send_json({"ok": True, **state})

        return self.send_json({"ok": False, "error": "Маршрут не найден"}, 404)


def main():
    mimetypes.init()
    mimetypes.add_type("image/webp", ".webp")
    mimetypes.add_type("application/javascript", ".js")
    mimetypes.add_type("text/css", ".css")

    init_storage()
    server = ThreadingHTTPServer((HOST, PORT), JournalistiRequestHandler)
    print("=" * 64)
    print(f"✦ Journalisti.CO Server запущен!")
    print(f"✦ Локальный адрес:   http://localhost:{PORT}")
    print(f"✦ Редакция (CMS):    http://localhost:{PORT}/#studio")
    print(f"✦ Пароль редакции:   {DEFAULT_ADMIN_PASSWORD}")
    print(f"✦ База данных SQLite: {DB_PATH}")
    print("=" * 64)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nОстановка сервера Journalisti.CO...")
        server.server_close()


if __name__ == "__main__":
    main()
