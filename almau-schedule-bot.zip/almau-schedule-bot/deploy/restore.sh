#!/usr/bin/env bash
# Восстановление БД из бэкапа:   sudo schedule-bot-restore /var/lib/schedule-bot/backups/daily-….db.gz
# (файл можно взять и из Telegram — бот каждую ночь присылает копию админам)
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти через sudo"; exit 1; }
FILE="${1:?Укажи файл бэкапа .db.gz}"
DATA=/var/lib/schedule-bot
systemctl stop schedule-bot
[ -f "$DATA/bot.db" ] && cp "$DATA/bot.db" "$DATA/bot.db.before-restore"
rm -f "$DATA"/bot.db-wal "$DATA"/bot.db-shm
gunzip -c "$FILE" > "$DATA/bot.db"
chown bot:bot "$DATA/bot.db"
systemctl start schedule-bot
echo "✅ База восстановлена из $FILE (прежняя сохранена как bot.db.before-restore)"
