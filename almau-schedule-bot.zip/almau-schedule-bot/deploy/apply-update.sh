#!/usr/bin/env bash
# Тонкая root-обёртка: единственное, что бот (пользователь bot) может запускать через sudo.
# Принимает ТОЛЬКО архив из /var/lib/schedule-bot/updates/ и запускает установку в отдельном systemd-юните,
# чтобы она пережила перезапуск самого бота.   Использование: schedule-bot-apply-update <zip> <chat_id>
set -euo pipefail
ZIP="$(readlink -f "${1:?}")"
CHAT="${2:-0}"
case "$ZIP" in /var/lib/schedule-bot/updates/update-[0-9]*.zip) ;; *) echo "недопустимый путь архива"; exit 1;; esac
[ -f "$ZIP" ] || { echo "архив не найден"; exit 1; }
[[ "$CHAT" =~ ^-?[0-9]+$ ]] || { echo "недопустимый chat id"; exit 1; }
systemd-run --unit="schedule-bot-updater-$(date +%s)" --collect --no-block \
  /usr/local/bin/schedule-bot-update "$ZIP" --notify "$CHAT"
echo "запущено"
