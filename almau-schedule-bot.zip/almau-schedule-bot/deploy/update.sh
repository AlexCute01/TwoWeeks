#!/usr/bin/env bash
# ОБНОВЛЕНИЕ бота:   sudo schedule-bot-update /путь/к/архиву.zip   (или к папке проекта)
# Вызывается также из Telegram (владелец присылает .zip боту) — тогда добавляется --notify <chat_id>.
#
# Защита данных:
#  • БД и настройки лежат ВНЕ кода (/var/lib/schedule-bot, /etc/schedule-bot.env) — обновление их не трогает;
#  • перед заменой кода делается резервная копия БД (pre-update-*.db.gz);
#  • новая версия запускается, и если не «оживает» за 90 секунд — автоматический откат;
#  • схема БД расширяется автоматически и только аддитивно, данные не удаляются.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти через sudo"; exit 1; }
SRC="${1:?Укажи архив .zip или папку с проектом}"; shift || true
FIRST=""; NOTIFY=""
while [ $# -gt 0 ]; do
  case "$1" in
    --first-install) FIRST=1;;
    --notify) NOTIFY="${2:-}"; shift;;
  esac
  shift
done
BASE=/opt/schedule-bot; DATA=/var/lib/schedule-bot
TS=$(date +%Y%m%d-%H%M%S)
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

report() {   # report <STATUS> <NOTE> — бот прочитает файл и сообщит тому, кто запускал обновление
  [ -n "$NOTIFY" ] || return 0
  mkdir -p "$DATA"
  printf 'STATUS=%s\nVERSION=%s\nCHAT=%s\nNOTE=%s\n' "$1" "$TS" "$NOTIFY" "$2" > "$DATA/update_report.txt"
  chown bot:bot "$DATA/update_report.txt" 2>/dev/null || true
}

# 1) распаковать
if [ -f "$SRC" ]; then unzip -q "$SRC" -d "$TMP"; else rsync -a --exclude venv --exclude __pycache__ "$SRC"/ "$TMP"/; fi
MAIN=$(find "$TMP" -maxdepth 4 -path '*/app/main.py' | head -1)
[ -n "$MAIN" ] || { echo "❌ В архиве не найден app/main.py"; report rejected "в архиве нет app/main.py"; exit 1; }
ROOT=$(dirname "$(dirname "$MAIN")")

# 2) проверить, что код компилируется — до того, как трогать работающую версию
if ! "$BASE/venv/bin/python" -m compileall -q "$ROOT/app" >/dev/null 2>"$TMP/err.txt"; then
  echo "❌ Ошибка в коде — обновление отменено, бот не тронут"; report rejected "ошибка компиляции: $(tail -c 300 "$TMP/err.txt" | tr '\n' ' ')"; exit 1
fi

# 3) резервная копия БД
if [ -s "$DATA/bot.db" ]; then
  mkdir -p "$DATA/backups"
  sqlite3 "$DATA/bot.db" ".backup '$DATA/backups/pre-update-$TS.db'" && gzip -f "$DATA/backups/pre-update-$TS.db"
  chown -R bot:bot "$DATA/backups"
  echo "💾 Копия БД: $DATA/backups/pre-update-$TS.db.gz"
fi

# 4) зависимости и новая версия
if ! "$BASE/venv/bin/pip" install --no-cache-dir -q -r "$ROOT/requirements.txt" 2>"$TMP/pip.txt"; then
  echo "❌ Не удалось поставить зависимости"; report rejected "pip: $(tail -c 300 "$TMP/pip.txt" | tr '\n' ' ')"; exit 1
fi
PREV=$(readlink -f "$BASE/current" 2>/dev/null || true)
mv "$ROOT" "$BASE/releases/$TS"
chown -R bot:bot "$BASE/releases/$TS"
ln -sfn "$BASE/releases/$TS" "$BASE/current"

# 5) перезапуск и проверка «жив ли»
rm -f "$DATA/heartbeat"
systemctl restart schedule-bot
OK=0
for i in $(seq 1 45); do
  sleep 2
  if systemctl is-active --quiet schedule-bot && [ -f "$DATA/heartbeat" ]; then OK=1; break; fi
done

if [ "$OK" != 1 ]; then
  if [ -n "$FIRST" ]; then
    echo "ℹ️  Код установлен, но бот не стартовал — скорее всего, ещё не вписан токен."
    echo "   Выполни: sudo nano /etc/schedule-bot.env   (BOT_TOKEN, ADMIN_IDS)  →  sudo systemctl restart schedule-bot"
    exit 0
  fi
  LOGTAIL=$(journalctl -u schedule-bot -n 6 --no-pager 2>/dev/null | tail -c 350 | tr '\n' ' ' || true)
  echo "❌ Новая версия не запустилась. Последние строки лога:"; journalctl -u schedule-bot -n 25 --no-pager || true
  if [ -n "$PREV" ] && [ -d "$PREV" ]; then
    echo "↩️  Откатываюсь на предыдущую версию…"
    ln -sfn "$PREV" "$BASE/current"
    systemctl restart schedule-bot
    report rolled_back "$LOGTAIL"
    echo "Откат выполнен. Данные целы."
  else
    report failed "$LOGTAIL"
  fi
  exit 1
fi

# 6) уборка: храним 5 последних версий; обновляем сами скрипты
ls -1dt "$BASE"/releases/* | tail -n +6 | xargs -r rm -rf
for f in update rollback restore apply-update; do
  [ -f "$BASE/current/deploy/$f.sh" ] && install -m 755 "$BASE/current/deploy/$f.sh" "/usr/local/bin/schedule-bot-$f"
done
cp "$BASE/current/deploy/schedule-bot.service" /etc/systemd/system/ && systemctl daemon-reload
report ok "версия $TS"
echo "✅ Версия $TS запущена и работает. Настройки и данные сохранены."
[ -n "$FIRST" ] || echo "   Если что-то не так: sudo schedule-bot-rollback"
