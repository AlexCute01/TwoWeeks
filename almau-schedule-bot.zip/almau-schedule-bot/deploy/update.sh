#!/usr/bin/env bash
# ОБНОВЛЕНИЕ бота:   sudo schedule-bot-update /путь/к/архиву.zip   (или к папке проекта)
#
# Защита данных:
#  • БД и настройки лежат ВНЕ кода (/var/lib/schedule-bot, /etc/schedule-bot.env) — обновление их не трогает;
#  • перед заменой кода делается резервная копия БД (pre-update-*.db.gz);
#  • новая версия запускается рядом, и если она не «оживает» за 90 секунд — автоматический откат;
#  • схема БД расширяется автоматически и только аддитивно (новые таблицы/колонки), данные не удаляются.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти через sudo"; exit 1; }
SRC="${1:?Укажи архив .zip или папку с проектом}"
FIRST="${2:-}"
BASE=/opt/schedule-bot; DATA=/var/lib/schedule-bot
TS=$(date +%Y%m%d-%H%M%S)
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT

# 1) распаковать
if [ -f "$SRC" ]; then unzip -q "$SRC" -d "$TMP"; else rsync -a --exclude venv --exclude __pycache__ "$SRC"/ "$TMP"/; fi
MAIN=$(find "$TMP" -maxdepth 4 -path '*/app/main.py' | head -1)
[ -n "$MAIN" ] || { echo "❌ В архиве не найден app/main.py"; exit 1; }
ROOT=$(dirname "$(dirname "$MAIN")")

# 2) проверить, что код вообще компилируется — до того, как трогать работающую версию
"$BASE/venv/bin/python" -m compileall -q "$ROOT/app" >/dev/null || { echo "❌ Ошибка в коде — обновление отменено, бот не тронут"; exit 1; }

# 3) резервная копия БД
if [ -s "$DATA/bot.db" ]; then
  mkdir -p "$DATA/backups"
  sqlite3 "$DATA/bot.db" ".backup '$DATA/backups/pre-update-$TS.db'" && gzip -f "$DATA/backups/pre-update-$TS.db"
  chown -R bot:bot "$DATA/backups"
  echo "💾 Копия БД: $DATA/backups/pre-update-$TS.db.gz"
fi

# 4) зависимости и новая версия
"$BASE/venv/bin/pip" install --no-cache-dir -q -r "$ROOT/requirements.txt"
PREV=$(readlink -f "$BASE/current" 2>/dev/null || true)
mv "$ROOT" "$BASE/releases/$TS"
chown -R bot:bot "$BASE/releases/$TS"
ln -sfn "$BASE/releases/$TS" "$BASE/current"

# 5) перезапуск и проверка «жив ли»
rm -f "$DATA/heartbeat"
systemctl restart schedule-bot
OK=0
for i in $(seq 1 45); do
  sleep 2
  if systemctl is-active --quiet schedule-bot && [ -f "$DATA/heartbeat" ]; then OK=1; break; fi
done

if [ "$OK" != 1 ]; then
  if [ -n "$FIRST" ]; then
    echo "ℹ️  Код установлен, но бот не стартовал — скорее всего, ещё не вписан токен."
    echo "   Выполни: sudo nano /etc/schedule-bot.env   (BOT_TOKEN, ADMIN_IDS)  →  sudo systemctl restart schedule-bot"
    exit 0
  fi
  echo "❌ Новая версия не запустилась. Последние строки лога:"
  journalctl -u schedule-bot -n 25 --no-pager || true
  if [ -n "$PREV" ] && [ -d "$PREV" ]; then
    echo "↩️  Откатываюсь на предыдущую версию…"
    ln -sfn "$PREV" "$BASE/current"
    systemctl restart schedule-bot
    echo "Откат выполнен. Данные целы."
  fi
  exit 1
fi

# 6) уборка: храним 5 последних версий; обновляем сами скрипты
ls -1dt "$BASE"/releases/* | tail -n +6 | xargs -r rm -rf
for f in update rollback restore; do
  [ -f "$BASE/current/deploy/$f.sh" ] && install -m 755 "$BASE/current/deploy/$f.sh" "/usr/local/bin/schedule-bot-$f"
done
cp "$BASE/current/deploy/schedule-bot.service" /etc/systemd/system/ && systemctl daemon-reload
echo "✅ Версия $TS запущена и работает. Настройки и данные сохранены."
[ -n "$FIRST" ] || echo "   Если что-то не так: sudo schedule-bot-rollback"
