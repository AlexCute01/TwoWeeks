# С ВАШЕГО Windows-компьютера (PowerShell; OpenSSH встроен в Windows 10/11):
#   .\deploy\push.ps1 -Server ubuntu@IP_СЕРВЕРА -Key C:\keys\oracle.key
param([Parameter(Mandatory=$true)][string]$Server, [string]$Key = "")
Set-Location (Join-Path $PSScriptRoot "..")
$zip = Join-Path $env:TEMP "bot-update.zip"
Remove-Item $zip -ErrorAction SilentlyContinue
tar.exe -a -cf $zip app data deploy requirements.txt README.md .env.example
$opts = @(); if ($Key) { $opts = @("-i", $Key) }
scp @opts $zip "${Server}:/tmp/bot-update.zip"
ssh @opts $Server "sudo schedule-bot-update /tmp/bot-update.zip; rm -f /tmp/bot-update.zip"
