#!/usr/bin/env bash
# Консистентная копия SQLite -> gzip -> Cloud Storage (5 ГБ в US-регионах бесплатно).
set -euo pipefail
set -a; . /etc/schedule-bot.env; set +a
[ -z "${BACKUP_BUCKET:-}" ] && { echo "BACKUP_BUCKET не задан — пропускаю"; exit 0; }
DB=/var/lib/schedule-bot/bot.db
TMP=$(mktemp -d)
sqlite3 "$DB" ".backup '$TMP/bot.db'"
gzip -9 "$TMP/bot.db"
gcloud storage cp "$TMP/bot.db.gz" "gs://$BACKUP_BUCKET/bot-$(date +%F).db.gz"
rm -rf "$TMP"
