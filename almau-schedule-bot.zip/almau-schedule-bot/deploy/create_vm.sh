#!/usr/bin/env bash
# Создаёт бесплатную VM (Always Free): e2-micro + 30 ГБ standard-диск, регион США.
# Запуск с твоего компьютера, где стоит gcloud:  bash deploy/create_vm.sh
set -euo pipefail
ZONE=${ZONE:-us-central1-a}      # бесплатно только: us-west1, us-central1, us-east1
VM=${VM:-schedule-bot}

gcloud compute instances create "$VM" \
  --zone="$ZONE" --machine-type=e2-micro \
  --boot-disk-size=30GB --boot-disk-type=pd-standard \
  --image-family=debian-12 --image-project=debian-cloud \
  --scopes=storage-rw

echo "Копирую проект на VM..."
sleep 20
gcloud compute scp --recurse --zone="$ZONE" "$(dirname "$0")/.." "$VM":~/schedule-bot-src
gcloud compute ssh --zone="$ZONE" "$VM" -- 'sudo apt-get install -y rsync >/dev/null && sudo bash ~/schedule-bot-src/deploy/setup.sh'
echo "Дальше: gcloud compute ssh $VM --zone=$ZONE  →  sudo nano /etc/schedule-bot.env  →  sudo systemctl restart schedule-bot"
