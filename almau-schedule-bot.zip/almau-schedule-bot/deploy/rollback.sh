#!/usr/bin/env bash
# Откат на предыдущую версию кода:   sudo schedule-bot-rollback
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти через sudo"; exit 1; }
BASE=/opt/schedule-bot
CUR=$(readlink -f "$BASE/current")
PREV=$(ls -1dt "$BASE"/releases/* | grep -v "^$CUR$" | head -1 || true)
[ -n "$PREV" ] || { echo "Нет предыдущих версий"; exit 1; }
ln -sfn "$PREV" "$BASE/current"
systemctl restart schedule-bot
echo "↩️  Вернул версию: $(basename "$PREV"). Данные не менялись."
