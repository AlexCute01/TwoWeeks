#!/usr/bin/env bash
# С ВАШЕГО компьютера (Linux/macOS/WSL/Git-Bash): упаковать, отправить и обновить сервер одной командой.
#   bash deploy/push.sh ubuntu@IP_СЕРВЕРА [путь/к/ssh-ключу]
set -euo pipefail
HOST="${1:?Пример: bash deploy/push.sh ubuntu@123.45.67.89 ~/.ssh/oracle.key}"
KEY="${2:-}"
cd "$(dirname "$0")/.."
ZIP="$(mktemp -u).zip"
zip -qr "$ZIP" app data deploy requirements.txt README.md .env.example -x '*/__pycache__/*'
OPTS=(); [ -n "$KEY" ] && OPTS=(-i "$KEY")
scp "${OPTS[@]}" "$ZIP" "$HOST:/tmp/bot-update.zip"
ssh "${OPTS[@]}" "$HOST" "sudo schedule-bot-update /tmp/bot-update.zip; rm -f /tmp/bot-update.zip"
rm -f "$ZIP"
