#!/usr/bin/env bash
# Запускать на VM от root:  sudo bash deploy/setup.sh   (из папки проекта)
set -euo pipefail
SRC="$(cd "$(dirname "$0")/.." && pwd)"

apt-get update -y
apt-get install -y python3-venv python3-pip sqlite3

# Swap 1 ГБ — страховка для e2-micro (1 ГБ RAM)
if ! swapon --show | grep -q swapfile; then
  fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

id bot &>/dev/null || useradd --system --home /opt/schedule-bot --shell /usr/sbin/nologin bot
mkdir -p /opt/schedule-bot
rsync -a --delete --exclude venv --exclude '*.db*' "$SRC"/ /opt/schedule-bot/ 2>/dev/null || cp -r "$SRC"/. /opt/schedule-bot/
python3 -m venv /opt/schedule-bot/venv
/opt/schedule-bot/venv/bin/pip install --no-cache-dir -r /opt/schedule-bot/requirements.txt
chown -R bot:bot /opt/schedule-bot

if [ ! -f /etc/schedule-bot.env ]; then
  cp /opt/schedule-bot/.env.example /etc/schedule-bot.env
  chmod 600 /etc/schedule-bot.env
  echo ">>> Заполни /etc/schedule-bot.env (BOT_TOKEN, ADMIN_IDS, SCHEDULE_URL), затем: sudo systemctl restart schedule-bot"
fi

cp /opt/schedule-bot/deploy/schedule-bot.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now schedule-bot

# Ежедневный бэкап БД в Cloud Storage (если задан BACKUP_BUCKET в /etc/schedule-bot.env)
cp /opt/schedule-bot/deploy/backup.sh /usr/local/bin/schedule-bot-backup
chmod +x /usr/local/bin/schedule-bot-backup
echo '30 4 * * * root /usr/local/bin/schedule-bot-backup >> /var/log/schedule-bot-backup.log 2>&1' > /etc/cron.d/schedule-bot-backup

echo "Готово. Логи: journalctl -u schedule-bot -f"
