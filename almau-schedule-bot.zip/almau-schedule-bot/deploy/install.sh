#!/usr/bin/env bash
# ПЕРВАЯ установка на Oracle Cloud VM (Ubuntu 22.04/24.04, ARM или x86).
# Запуск из папки проекта:   sudo bash deploy/install.sh
# Входящие порты открывать НЕ нужно (бот сам ходит в Telegram и SharePoint).
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти через sudo"; exit 1; }
SRC="$(cd "$(dirname "$0")/.." && pwd)"
BASE=/opt/schedule-bot; DATA=/var/lib/schedule-bot
export DEBIAN_FRONTEND=noninteractive

apt-get update -y
apt-get install -y python3-venv python3-pip sqlite3 unzip rsync

# Swap — страховка, если RAM меньше 2 ГБ (бесплатная x86-машина)
if [ "$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)" -lt 2000 ] && ! swapon --show | grep -q swapfile; then
  fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

id bot &>/dev/null || useradd --system --home "$BASE" --shell /usr/sbin/nologin bot
mkdir -p "$BASE/releases" "$DATA"
chown -R bot:bot "$DATA"

# Настройки живут в /etc/schedule-bot.env — update.sh их НИКОГДА не перезаписывает
if [ ! -f /etc/schedule-bot.env ]; then
  cp "$SRC/.env.example" /etc/schedule-bot.env
  chmod 600 /etc/schedule-bot.env
  echo ">>> Открой /etc/schedule-bot.env и впиши BOT_TOKEN и ADMIN_IDS:  sudo nano /etc/schedule-bot.env"
fi

# Дописываем в существующие настройки НОВЫЕ параметры из .env.example (ничего не перезаписывая);
# пустые ссылки на таблицы (SCHEDULE_URL…) заполняются значениями из примера.
while IFS= read -r line; do
  [[ "$line" =~ ^[A-Z_0-9]+= ]] || continue
  key="${line%%=*}"; val="${line#*=}"
  cur="$(grep "^${key}=" /etc/schedule-bot.env | head -1 | cut -d= -f2- || true)"
  if ! grep -q "^${key}=" /etc/schedule-bot.env; then
    echo "$line" >> /etc/schedule-bot.env
  elif [[ "$key" == SCHEDULE_URL* && -n "$val" && -z "$cur" ]]; then
    grep -v "^${key}=" /etc/schedule-bot.env > /etc/schedule-bot.env.tmp || true
    echo "$line" >> /etc/schedule-bot.env.tmp && mv /etc/schedule-bot.env.tmp /etc/schedule-bot.env
  fi
done < "$SRC/.env.example"
chmod 600 /etc/schedule-bot.env

python3 -m venv "$BASE/venv"
cp "$SRC/deploy/update.sh" /usr/local/bin/schedule-bot-update
cp "$SRC/deploy/rollback.sh" /usr/local/bin/schedule-bot-rollback
cp "$SRC/deploy/restore.sh" /usr/local/bin/schedule-bot-restore
cp "$SRC/deploy/apply-update.sh" /usr/local/bin/schedule-bot-apply-update
chmod 755 /usr/local/bin/schedule-bot-*
chown root:root /usr/local/bin/schedule-bot-*

# Обновление из Telegram: пользователю bot разрешён sudo ТОЛЬКО на одну команду-обёртку
mkdir -p "$DATA/updates" "$DATA/state"
chown -R bot:bot "$DATA"
echo 'bot ALL=(root) NOPASSWD: /usr/local/bin/schedule-bot-apply-update' > /etc/sudoers.d/schedule-bot
chmod 440 /etc/sudoers.d/schedule-bot
visudo -cf /etc/sudoers.d/schedule-bot >/dev/null || { rm -f /etc/sudoers.d/schedule-bot; echo "sudoers: ошибка"; }
cp "$SRC/deploy/schedule-bot.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable schedule-bot

# Первая версия кода ставится тем же скриптом, что и все обновления
/usr/local/bin/schedule-bot-update "$SRC" --first-install

echo
echo "Готово. Если вписывал токен уже после установки:  sudo systemctl restart schedule-bot"
echo "Логи:       journalctl -u schedule-bot -f"
echo "Обновление: пришли .zip боту в Telegram (владелец) ИЛИ  sudo schedule-bot-update ~/bot.zip"
