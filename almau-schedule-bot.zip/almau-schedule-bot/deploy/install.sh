#!/usr/bin/env bash
# ПЕРВАЯ установка на Oracle Cloud VM (Ubuntu 22.04/24.04, ARM или x86).
# Запуск из папки проекта:   sudo bash deploy/install.sh
# Входящие порты открывать НЕ нужно (бот сам ходит в Telegram и SharePoint).
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запусти через sudo"; exit 1; }
SRC="$(cd "$(dirname "$0")/.." && pwd)"
BASE=/opt/schedule-bot; DATA=/var/lib/schedule-bot
export DEBIAN_FRONTEND=noninteractive

apt-get update -y
apt-get install -y python3-venv python3-pip sqlite3 unzip rsync

# Swap — страховка, если RAM меньше 2 ГБ (бесплатная x86-машина)
if [ "$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)" -lt 2000 ] && ! swapon --show | grep -q swapfile; then
  fallocate -l 1G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

id bot &>/dev/null || useradd --system --home "$BASE" --shell /usr/sbin/nologin bot
mkdir -p "$BASE/releases" "$DATA"
chown -R bot:bot "$DATA"

# Настройки живут в /etc/schedule-bot.env — update.sh их НИКОГДА не перезаписывает
if [ ! -f /etc/schedule-bot.env ]; then
  cp "$SRC/.env.example" /etc/schedule-bot.env
  chmod 600 /etc/schedule-bot.env
  echo ">>> Открой /etc/schedule-bot.env и впиши BOT_TOKEN и ADMIN_IDS:  sudo nano /etc/schedule-bot.env"
fi

python3 -m venv "$BASE/venv"
cp "$SRC/deploy/update.sh" /usr/local/bin/schedule-bot-update
cp "$SRC/deploy/rollback.sh" /usr/local/bin/schedule-bot-rollback
cp "$SRC/deploy/restore.sh" /usr/local/bin/schedule-bot-restore
chmod +x /usr/local/bin/schedule-bot-*
cp "$SRC/deploy/schedule-bot.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable schedule-bot

# Первая версия кода ставится тем же скриптом, что и все обновления
/usr/local/bin/schedule-bot-update "$SRC" --first-install

echo
echo "Готово. Если вписывал токен уже после установки:  sudo systemctl restart schedule-bot"
echo "Логи:       journalctl -u schedule-bot -f"
echo "Обновление: sudo schedule-bot-update ~/bot.zip"
