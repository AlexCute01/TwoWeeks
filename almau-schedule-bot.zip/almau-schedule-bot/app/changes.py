"""
Определение изменений расписания и текст уведомления. Без БД — чистая логика.

Сравниваем расписание по «слотам» (день, номер пары, чётность, подгруппа) и внутри слота
смотрим, ЧТО именно поменялось — так студент видит «аудитория 305 → 210», а не «убрали одно, добавили другое».
"""
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from .util import WEEKDAYS_SHORT, esc, week_parity

Slot = tuple[int, int, int, str]      # (weekday, pair_no, parity, subgroup)
Entry = tuple[str, str, str, time]    # (subject, teacher, room, start)

MAX_LINES = 12   # сколько изменений показывать в одном сообщении


@dataclass
class Change:
    kind: str                 # "changed" | "added" | "removed"
    slot: Slot
    old: Entry | None
    new: Entry | None

    @property
    def weekday(self) -> int: return self.slot[0]
    @property
    def pair_no(self) -> int: return self.slot[1]
    @property
    def parity(self) -> int: return self.slot[2]
    @property
    def subgroup(self) -> str: return self.slot[3]


def diff_group(old: dict[Slot, list[Entry]], new: dict[Slot, list[Entry]]) -> list[Change]:
    out: list[Change] = []
    for slot in sorted(set(old) | set(new)):
        rem_old: list[Entry] = []
        left_new = list(new.get(slot, []))
        for x in old.get(slot, []):
            for y in left_new:
                if x[:3] == y[:3]:          # предмет, преподаватель, аудитория совпали — без изменений
                    left_new.remove(y)
                    break
            else:
                rem_old.append(x)
        for x, y in zip(rem_old, left_new):
            out.append(Change("changed", slot, x, y))
        for x in rem_old[len(left_new):]:
            out.append(Change("removed", slot, x, None))
        for y in left_new[len(rem_old):]:
            out.append(Change("added", slot, None, y))
    return out


def upcoming(ch: Change, now: datetime) -> date | None:
    """Ближайшая дата, когда изменение реально коснётся студента."""
    start = (ch.new or ch.old)[3]
    for i in range(15):
        d = now.date() + timedelta(days=i)
        if d.weekday() != ch.weekday:
            continue
        if ch.parity and ch.parity != week_parity(d):
            continue
        if datetime.combine(d, start) > now:
            return d
    return None


def is_relevant(ch: Change, subgroup: str, hidden: list[str]) -> bool:
    """Касается ли изменение конкретного студента (его подгруппа, скрытые предметы)."""
    if subgroup and ch.subgroup not in ("", subgroup):
        return False
    subjects = [e[0].lower() for e in (ch.old, ch.new) if e]
    return not any(h in s for h in hidden for s in subjects)


def describe(ch: Change, now: datetime | None = None) -> str:
    entry = ch.new or ch.old
    extra = ""
    if ch.parity:
        extra += " · нечёт." if ch.parity == 1 else " · чётн."
    if ch.subgroup:
        extra += f" · подгр. {esc(ch.subgroup)}"
    tag = ""
    if now:
        when = upcoming(ch, now)
        if when == now.date():
            tag = " · <b>сегодня</b>"
        elif when == now.date() + timedelta(days=1):
            tag = " · <b>завтра</b>"
    head = f"<b>{WEEKDAYS_SHORT[ch.weekday]}, {ch.pair_no} пара ({entry[3]:%H:%M})</b>{extra}{tag}"

    o, n = ch.old, ch.new
    if ch.kind == "removed":
        return f"❌ {head}\n      {esc(o[0])} — убрана из расписания"
    if ch.kind == "added":
        tail = (f" · 📍 {esc(n[2])}" if n[2] else "") + (f" · 👤 {esc(n[1])}" if n[1] else "")
        return f"➕ {head}\n      {esc(n[0])}{tail}"
    lines = [f"🔄 {head}", f"      {esc(n[0])}"]
    if o[0] != n[0]:
        lines.append(f"      🔁 было: {esc(o[0])}")
    if o[2] != n[2]:
        lines.append(f"      🚪 аудитория: {esc(o[2] or '—')} → <b>{esc(n[2] or '—')}</b>")
    if o[1] != n[1]:
        lines.append(f"      👤 {esc(o[1] or '—')} → <b>{esc(n[1] or '—')}</b>")
    return "\n".join(lines)


def build_message(group_name: str, changes: list[Change], now: datetime) -> tuple[str, bool]:
    """-> (текст, срочно_ли). Срочно = затрагивает сегодня (ещё не начавшуюся пару) или завтра."""
    items = sorted(((upcoming(c, now), c) for c in changes),
                   key=lambda x: (x[0] or date.max, x[1].pair_no))
    urgent = any(d and d <= now.date() + timedelta(days=1) for d, _ in items)
    head = "🚨 <b>Срочно: изменения в расписании</b>" if urgent else "🔄 <b>Изменения в расписании</b>"
    lines = [f"{head} · {esc(group_name)}", ""]
    for _, c in items[:MAX_LINES]:
        lines.append(describe(c, now))
        lines.append("")
    if len(items) > MAX_LINES:
        lines.append(f"…и ещё {len(items) - MAX_LINES}. Смотри /week и /changes")
    return "\n".join(lines).rstrip(), urgent
