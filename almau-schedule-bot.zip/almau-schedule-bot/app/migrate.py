"""
Безопасное обновление схемы БД.

При каждом запуске: сравниваем модели с реальной БД; если появились новые таблицы/колонки —
1) делаем резервную копию («pre-migrate-…»), 2) добавляем недостающее (ALTER TABLE ADD COLUMN).
Данные пользователей никогда не удаляются и не пересоздаются. Для не-аддитивных изменений
(переименование/удаление колонок) добавляйте явные шаги в MANUAL_MIGRATIONS.
"""
import asyncio
import datetime as dt
import logging

from sqlalchemy import inspect

from .backup import make_backup
from .db import Base, engine

log = logging.getLogger(__name__)

# (версия, SQL) — выполняются по порядку, один раз; версия хранится в PRAGMA user_version.
MANUAL_MIGRATIONS: list[tuple[int, str]] = []


def _default_sql(col) -> str | None:
    d = col.default
    if d is None or not getattr(d, "is_scalar", False):
        return None
    v = d.arg
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        return "'" + v.replace("'", "''") + "'"
    if isinstance(v, dt.time):
        return f"'{v:%H:%M:%S}.000000'"
    return None


def _find_missing(sync_conn):
    insp = inspect(sync_conn)
    tables = set(insp.get_table_names())
    missing_tables = [t.name for t in Base.metadata.sorted_tables if t.name not in tables]
    missing_cols = []
    for table in Base.metadata.sorted_tables:
        if table.name not in tables:
            continue
        have = {c["name"] for c in insp.get_columns(table.name)}
        missing_cols += [(table, c) for c in table.columns if c.name not in have]
    return missing_tables, missing_cols


async def migrate() -> None:
    async with engine.connect() as conn:
        missing_tables, missing_cols = await conn.run_sync(_find_missing)
        row = (await conn.exec_driver_sql("PRAGMA user_version")).fetchone()
        version = row[0] if row else 0
    pending_manual = [m for m in MANUAL_MIGRATIONS if m[0] > version]
    existing_db = len(missing_tables) < len(Base.metadata.tables)       # БД уже содержит данные

    if (missing_cols or pending_manual or (missing_tables and existing_db)):
        log.warning("schema changes: tables=%s cols=%s manual=%s", missing_tables,
                    [f"{t.name}.{c.name}" for t, c in missing_cols], [m[0] for m in pending_manual])
        await asyncio.to_thread(make_backup, "pre-migrate")      # страховка ПЕРЕД любыми изменениями

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)             # новые таблицы (существующие не трогает)
        for table, col in missing_cols:
            ddl = f'"{col.name}" {col.type.compile(dialect=conn.dialect)}'
            default = _default_sql(col)
            if default is not None:
                ddl += f" DEFAULT {default}"
            await conn.exec_driver_sql(f'ALTER TABLE "{table.name}" ADD COLUMN {ddl}')
        for ver, sql in pending_manual:
            await conn.exec_driver_sql(sql)
            await conn.exec_driver_sql(f"PRAGMA user_version = {ver}")
