"""Сборка расписания пользователя (кэш + личные события) и обёртки над форматированием."""
from datetime import date, datetime, timedelta

from sqlalchemy import select

from .cache import cache
from .db import HiddenSubject, PersonalLesson, Room, User
from .fmt import (Item, building_of, date_label, fmt_dur, format_day as _fmt_day, format_week as _fmt_week,  # noqa: F401
                  room_card, room_line)
from .util import WEEKDAYS_SHORT, esc, norm_room, now_local, week_parity  # noqa: F401


async def day_items(s, user: User, d: date) -> list[Item]:
    p = week_parity(d)
    items: list[Item] = []
    if user.group_id:
        hidden = [h.lower() for h in await s.scalars(
            select(HiddenSubject.subject).where(HiddenSubject.user_id == user.tg_id))]
        for l in cache.lessons(user.group_id, d.weekday()):
            if l.parity not in (0, p):
                continue
            if user.subgroup and l.subgroup not in ("", user.subgroup):
                continue
            if any(h in l.subject.lower() for h in hidden):
                continue
            items.append(Item(l.start, l.end, l.subject, l.room, l.teacher, l.kind, False, l.segments))

    q2 = select(PersonalLesson).where(
        PersonalLesson.user_id == user.tg_id,
        PersonalLesson.weekday == d.weekday(),
        PersonalLesson.parity.in_((0, p)),
    )
    for pl in await s.scalars(q2):
        items.append(Item(pl.start, pl.end, pl.title, pl.room, personal=True))
    items.sort(key=lambda i: (i.start, i.end))
    return items


async def next_item(s, user: User, now: datetime):
    for delta in range(8):
        d = now.date() + timedelta(days=delta)
        for it in await day_items(s, user, d):
            if datetime.combine(d, it.start) > now:
                return d, it
    return None


async def rooms_map(s) -> dict[str, Room]:
    return {r.code: r for r in await s.scalars(select(Room))}


async def render_day_text(s, user: User, d: date, rooms=None, now: datetime | None = None) -> str:
    rooms = rooms if rooms is not None else await rooms_map(s)
    return _fmt_day(await day_items(s, user, d), d, rooms, now or now_local(), cache.title(user.group_id))


def week_monday(today: date) -> date:
    m = today - timedelta(days=today.weekday())
    return m + timedelta(days=7) if today.weekday() == 6 else m     # в воскресенье показываем следующую неделю


async def render_week_text(s, user: User, monday: date, rooms=None) -> str:
    rooms = rooms if rooms is not None else await rooms_map(s)
    days = [(monday + timedelta(days=i), await day_items(s, user, monday + timedelta(days=i))) for i in range(6)]
    return _fmt_week(days, rooms, cache.title(user.group_id), now_local().date())
