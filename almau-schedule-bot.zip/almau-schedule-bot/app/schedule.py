"""Сборка расписания пользователя на день + красивое форматирование."""
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from sqlalchemy import select

from .cache import cache
from .db import HiddenSubject, PersonalLesson, Room, User
from .util import (MONTHS, WEEKDAYS, WEEKDAYS_SHORT, esc, norm_room, now_local,  # noqa: F401
                   parity_name, week_parity)


@dataclass
class Item:
    start: time
    end: time
    title: str
    room: str = ""
    teacher: str = ""
    kind: str = ""
    personal: bool = False


async def day_items(s, user: User, d: date) -> list[Item]:
    p = week_parity(d)
    items: list[Item] = []

    if user.group_id:
        hidden = [h.lower() for h in await s.scalars(
            select(HiddenSubject.subject).where(HiddenSubject.user_id == user.tg_id))]
        for l in cache.lessons(user.group_id, d.weekday()):
            if l.parity not in (0, p):
                continue
            if user.subgroup and l.subgroup not in ("", user.subgroup):
                continue
            if any(h in l.subject.lower() for h in hidden):
                continue
            items.append(Item(l.start, l.end, l.subject, l.room, l.teacher, l.kind))

    q2 = select(PersonalLesson).where(
        PersonalLesson.user_id == user.tg_id,
        PersonalLesson.weekday == d.weekday(),
        PersonalLesson.parity.in_((0, p)),
    )
    for pl in await s.scalars(q2):
        items.append(Item(pl.start, pl.end, pl.title, pl.room, personal=True))

    items.sort(key=lambda i: (i.start, i.end))
    return items


async def next_item(s, user: User, now: datetime):
    for delta in range(8):
        d = now.date() + timedelta(days=delta)
        for it in await day_items(s, user, d):
            if datetime.combine(d, it.start) > now:
                return d, it
    return None


# ---------- аудитории ----------

async def rooms_map(s) -> dict[str, Room]:
    return {r.code: r for r in await s.scalars(select(Room))}


def building_of(code: str, rooms: dict[str, Room]) -> str:
    r = rooms.get(norm_room(code))
    return r.building if r else ""


def room_line(code: str, rooms: dict[str, Room]) -> str:
    if not code:
        return ""
    r = rooms.get(norm_room(code))
    if not r:
        return esc(code)
    loc = ", ".join(x for x in (r.building, f"{r.floor} этаж" if r.floor else "") if x)
    return esc(code) + (f" — {esc(loc)}" if loc else "")


def room_card(code: str, rooms: dict[str, Room]) -> str:
    r = rooms.get(norm_room(code))
    if not r:
        return f"Про аудиторию <b>{esc(code)}</b> у меня пока нет описания 🤷"
    lines = [f"📍 <b>Аудитория {esc(code)}</b>"]
    if r.building:
        lines.append(f"🏢 {esc(r.building)}")
    if r.floor:
        lines.append(f"🪜 {r.floor} этаж")
    if r.description:
        lines.append(f"\n{esc(r.description)}")
    return "\n".join(lines)


# ---------- форматирование ----------

def _min(t: time) -> int:
    return t.hour * 60 + t.minute


def fmt_dur(minutes: int) -> str:
    h, m = divmod(minutes, 60)
    return " ".join(x for x in (f"{h} ч" if h else "", f"{m} мин" if m else "") if x)


def date_label(d: date) -> str:
    return f"{WEEKDAYS[d.weekday()]}, {d.day} {MONTHS[d.month - 1]}"


def _block(it: Item, rooms) -> str:
    star = "⭐ " if it.personal else ""
    head = f"<b>{it.start:%H:%M}–{it.end:%H:%M}</b> · {star}{esc(it.title)}"
    if it.kind:
        head += f" <i>({esc(it.kind)})</i>"
    tail = []
    if it.room:
        tail.append(f"📍 {room_line(it.room, rooms)}")
    if it.teacher:
        tail.append(f"👤 {esc(it.teacher)}")
    return head + ("\n      " + "  ".join(tail) if tail else "")


def format_day(items: list[Item], d: date, rooms) -> str:
    head = f"📅 <b>{date_label(d)}</b> · <i>{parity_name(week_parity(d))}</i>\n"
    if not items:
        return head + "\n🎉 Пар нет — отдыхай!"
    out = [head]
    prev = None
    for it in items:
        if prev:
            gap = _min(it.start) - _min(prev.end)
            if gap >= 50:
                out.append(f"      🕐 <i>окно {fmt_dur(gap)}</i>")
            pb, nb = building_of(prev.room, rooms), building_of(it.room, rooms)
            if pb and nb and pb != nb:
                out.append(f"      🚶 <i>смена корпуса: {esc(pb)} → {esc(nb)}</i>")
        out.append(_block(it, rooms))
        prev = it
    out.append(f"\n🏁 Заканчиваешь в <b>{prev.end:%H:%M}</b>")
    return "\n".join(out)


async def format_week(s, user: User, monday: date, rooms) -> str:
    out = [f"🗓 <b>Неделя с {monday.day} {MONTHS[monday.month - 1]}</b> · "
           f"<i>{parity_name(week_parity(monday))}</i>\n"]
    for i in range(6):
        d = monday + timedelta(days=i)
        items = await day_items(s, user, d)
        out.append(f"<b>{WEEKDAYS_SHORT[i]} {d.day:02d}.{d.month:02d}</b>")
        if not items:
            out.append("   —")
        for it in items:
            room = f" · {esc(it.room)}" if it.room else ""
            out.append(f"   {it.start:%H:%M} {esc(it.title)}{room}")
        out.append("")
    return "\n".join(out)
