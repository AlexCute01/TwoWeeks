"""Админ: кто пользуется ботом — список, поиск, карточка пользователя, смена его группы и личного расписания."""
import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import delete, func, select

from . import access
from .cache import cache
from .common import InState, eat, ephemeral, parse_hhmm, set_state, show
from .config import COURSES
from .db import Group, HiddenSubject, PersonalLesson, Session, User
from .handlers import ADD_RE
from .outbox import PRIO_ADMIN, enqueue
from .parser import DAYS, detect_parity
from .programs import DEPTS
from .schedule import render_day_text
from .ui import back_kb
from .util import WEEKDAYS_SHORT, esc, now_local

log = logging.getLogger(__name__)
router = Router()
B = InlineKeyboardButton
PAGE = 8


def _deny(ev) -> bool:
    return not access.is_admin(ev.from_user.id)


def ago(dt) -> str:
    if not dt:
        return "—"
    m = int((now_local() - dt).total_seconds() // 60)
    return "только что" if m < 1 else f"{m} мин назад" if m < 60 else f"{m // 60} ч назад" if m < 1440 else f"{m // 1440} дн назад"


def _label(u: User) -> str:
    name = (u.full_name or (f"@{u.username}" if u.username else str(u.tg_id)))[:18]
    grp = cache.title(u.group_id).replace(" курс · ", "к·")[:20] if u.group_id else "без группы"
    return f"{'🚫 ' if u.blocked else ''}{name} · {grp} · {ago(u.last_seen)}"


# ───────────────────────── список и поиск ─────────────────────────

@router.callback_query(F.data.startswith("ad:users:"))
async def cb_list(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id)
    await users_list(c, int(c.data.split(":")[2]))


async def users_list(target, page: int = 0, found: list[User] | None = None, title: str = ""):
    async with Session() as s:
        total = await s.scalar(select(func.count()).select_from(User))
        if found is None:
            users = list(await s.scalars(select(User).order_by(User.last_seen.desc().nulls_last())
                                         .offset(page * PAGE).limit(PAGE)))
        else:
            users = found[:PAGE]
    kb = InlineKeyboardBuilder()
    for u in users:
        kb.row(B(text=_label(u), callback_data=f"ad:u:{u.tg_id}"))
    if found is None:
        nav = []
        if page > 0:
            nav.append(B(text="◀️", callback_data=f"ad:users:{page - 1}"))
        if (page + 1) * PAGE < total:
            nav.append(B(text="▶️", callback_data=f"ad:users:{page + 1}"))
        if nav:
            kb.row(*nav)
    kb.row(B(text="🔎 Поиск", callback_data="ad:usearch"), B(text="⬅️ В админку", callback_data="ad:home"))
    head = title or f"👥 <b>Пользователи</b> · всего {total}\n<i>сначала те, кто заходил недавно</i>"
    if found is not None and not users:
        head += "\n\nНичего не найдено."
    await show(target, head, kb.as_markup(), **({"delete_src": False} if isinstance(target, Message) else {}))


@router.callback_query(F.data == "ad:usearch")
async def cb_search(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id, "adm_usearch")
    await show(c, "🔎 Пришли <b>имя</b>, <b>@username</b> или <b>Telegram ID</b> пользователя.", back_kb("ad:users:0", "⬅️ Отмена"))


@router.message(InState("adm_usearch"))
async def on_search(m: Message):
    if _deny(m):
        return
    q = (m.text or "").strip()
    await eat(m)
    await set_state(m.from_user.id)
    async with Session() as s:
        everyone = list(await s.scalars(select(User).order_by(User.last_seen.desc().nulls_last())))
    ql = q.lstrip("@").casefold()
    found = [u for u in everyone if (q.isdigit() and str(u.tg_id) == q) or ql in (u.username or "").casefold()
             or ql in (u.full_name or "").casefold()]
    await users_list(m, found=found, title=f"🔎 Результаты по «{esc(q)}»: {len(found)}")


# ───────────────────────── карточка ─────────────────────────

def _flags(u: User) -> str:
    def f(x): return "✅" if x else "⬜️"
    return (f"⏰{f(u.remind_on)} ({u.remind_before} мин) ▶️{f(u.start_on)} ☕{f(u.end_on)} 🕐{f(u.break_on)}\n"
            f"☀️{f(u.morning_on)} {u.morning_time:%H:%M} · 🌤{f(u.weather_on)} · 🌙{f(u.evening_on)} {u.evening_time:%H:%M}\n"
            f"🔄{f(u.changes_on)} 📰{f(u.news_on)} 🧹{f(u.autoclean_on)}" + ("" if u.notify_enabled else " · ⏸ пауза"))


async def card(target, uid: int):
    async with Session() as s:
        u = await s.get(User, uid)
        if not u:
            return await show(target, "Пользователь не найден.", back_kb("ad:users:0"))
        ev = await s.scalar(select(func.count()).select_from(PersonalLesson).where(PersonalLesson.user_id == uid))
        hid = await s.scalar(select(func.count()).select_from(HiddenSubject).where(HiddenSubject.user_id == uid))
    who = esc(u.full_name or "—") + (f" (@{esc(u.username)})" if u.username else "")
    text = (f"👤 <b>{who}</b>\n🆔 <code>{u.tg_id}</code>"
            + (" · 🛡 админ" if access.is_admin(uid) else "") + (" · 🚫 заблокировал бота" if u.blocked else "") + "\n"
            f"📘 {esc(cache.title(u.group_id)) if u.group_id else '<i>группа не выбрана</i>'}\n"
            f"🕘 заходил: {ago(u.last_seen)} · с нами с {u.created_at:%d.%m.%Y}\n\n"
            f"{_flags(u)}\n\n⭐ своих событий: {ev} · 🙈 скрытых предметов: {hid}")
    kb = InlineKeyboardBuilder()
    kb.button(text="📅 Его расписание сегодня", callback_data=f"ad:uday:{uid}")
    kb.button(text="👥 Сменить группу", callback_data=f"ad:ug:{uid}")
    kb.button(text="⭐ Личные события", callback_data=f"ad:ue:{uid}")
    kb.button(text="🙈 Сбросить скрытые", callback_data=f"ad:uh:{uid}")
    kb.button(text="✉️ Написать ему", callback_data=f"ad:um:{uid}")
    kb.button(text="⬅️ К списку", callback_data="ad:users:0")
    kb.adjust(1, 2, 2, 1)
    await show(target, text, kb.as_markup(), **({"delete_src": False} if isinstance(target, Message) else {}))


@router.callback_query(F.data.startswith("ad:u:"))
async def cb_card(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id)
    await card(c, int(c.data.split(":")[2]))


@router.callback_query(F.data.startswith("ad:uday:"))
async def cb_day(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    uid = int(c.data.split(":")[2])
    async with Session() as s:
        u = await s.get(User, uid)
        text = await render_day_text(s, u, now_local().date()) if u and u.group_id else "У него не выбрана группа."
    await show(c, "👁 <b>Так видит он:</b>\n\n" + text, back_kb(f"ad:u:{uid}", "⬅️ К карточке"))


# ───────────────────────── смена группы ─────────────────────────

@router.callback_query(F.data.startswith("ad:ug:"))
async def cb_group(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    uid = c.data.split(":")[2]
    kb = InlineKeyboardBuilder()
    for cc in COURSES:
        kb.button(text=f"📘 {cc} курс", callback_data=f"ad:ugc:{uid}:{cc}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:u:{uid}")
    kb.adjust(3, 1)
    await show(c, "Новая группа пользователя — выбери курс:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:ugc:"))
async def cb_group_course(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, uid, course = c.data.split(":")
    async with Session() as s:
        rows = await s.execute(select(Group.dept, func.count()).where(Group.course == int(course)).group_by(Group.dept))
        counts = {d or "": n for d, n in rows}
    kb = InlineKeyboardBuilder()
    for key, label in DEPTS.items():
        if counts.get(key):
            kb.button(text=label, callback_data=f"ad:ugd:{uid}:{course}:{key or '_'}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:ug:{uid}")
    kb.adjust(1)
    await show(c, f"{course} курс — отделение:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:ugd:"))
async def cb_group_dept(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, uid, course, dept = c.data.split(":")
    async with Session() as s:
        groups = list(await s.scalars(select(Group).where(Group.course == int(course), Group.dept == dept.replace("_", ""))
                                      .order_by(Group.title)))
    kb = InlineKeyboardBuilder()
    for g in groups:
        kb.button(text=(g.title or g.name)[:44], callback_data=f"ad:ugp:{uid}:{g.id}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:ugc:{uid}:{course}")
    kb.adjust(1)
    await show(c, "Программа:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:ugp:"))
async def cb_group_set(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, uid, gid = c.data.split(":")
    async with Session() as s:
        u = await s.get(User, int(uid))
        u.group_id = int(gid)
        await s.commit()
    await enqueue(int(uid), f"ℹ️ Администратор сменил вашу группу на <b>{esc(cache.title(int(gid)))}</b>.",
                  priority=PRIO_ADMIN)
    await c.answer("Группа изменена, пользователь уведомлён", show_alert=True)
    await card(c, int(uid))


# ───────────────────────── личные события, скрытые, сообщение ─────────────────────────

async def events_screen(target, uid: int):
    async with Session() as s:
        mine = list(await s.scalars(select(PersonalLesson).where(PersonalLesson.user_id == uid)
                                    .order_by(PersonalLesson.weekday, PersonalLesson.start)))
    kb = InlineKeyboardBuilder()
    lines = ["⭐ <b>Личные события пользователя</b>", ""]
    for p in mine:
        lines.append(f"• {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M}–{p.end:%H:%M} · {esc(p.title)}" + (f" · {esc(p.room)}" if p.room else ""))
        kb.button(text=f"🗑 {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M} {p.title[:18]}", callback_data=f"ad:ued:{uid}:{p.id}")
    if not mine:
        lines.append("Пока нет.")
    kb.button(text="➕ Добавить", callback_data=f"ad:uea:{uid}")
    kb.button(text="⬅️ К карточке", callback_data=f"ad:u:{uid}")
    kb.adjust(1)
    await show(target, "\n".join(lines), kb.as_markup(), **({"delete_src": False} if isinstance(target, Message) else {}))


@router.callback_query(F.data.startswith("ad:ue:"))
async def cb_events(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await events_screen(c, int(c.data.split(":")[2]))


@router.callback_query(F.data.startswith("ad:ued:"))
async def cb_event_del(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, uid, pid = c.data.split(":")
    async with Session() as s:
        await s.execute(delete(PersonalLesson).where(PersonalLesson.id == int(pid), PersonalLesson.user_id == int(uid)))
        await s.commit()
    await events_screen(c, int(uid))


@router.callback_query(F.data.startswith("ad:uea:"))
async def cb_event_add(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    uid = c.data.split(":")[2]
    await set_state(c.from_user.id, "adm_uevent", uid)
    await show(c, "➕ Событие для пользователя:\n<code>пн 15:00-16:30 Английский, 210</code>", back_kb(f"ad:ue:{uid}", "⬅️ Отмена"))


@router.message(InState("adm_uevent"))
async def on_event(m: Message, st_data: str):
    if _deny(m):
        return
    uid = int(st_data)
    mt = ADD_RE.match((m.text or "").strip())
    day = DAYS.get(mt[1].lower()) if mt else None
    t1, t2 = (parse_hhmm(mt[2]), parse_hhmm(mt[3])) if mt else (None, None)
    await eat(m)
    if not mt or day is None or not t1 or not t2 or t2 <= t1:
        await ephemeral(m, "Не разобрал. Пример: <code>пн 15:00-16:30 Английский, 210</code>", 7)
        return
    async with Session() as s:
        s.add(PersonalLesson(user_id=uid, weekday=day, start=t1, end=t2, title=mt[4].strip()[:200],
                             room=(mt[5] or "")[:50], parity=detect_parity(mt[4])))
        await s.commit()
    await set_state(m.from_user.id)
    await events_screen(m, uid)


@router.callback_query(F.data.startswith("ad:uh:"))
async def cb_hidden_reset(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    uid = int(c.data.split(":")[2])
    async with Session() as s:
        await s.execute(delete(HiddenSubject).where(HiddenSubject.user_id == uid))
        await s.commit()
    await c.answer("Скрытые предметы сброшены")
    await card(c, uid)


@router.callback_query(F.data.startswith("ad:um:"))
async def cb_msg(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    uid = c.data.split(":")[2]
    await set_state(c.from_user.id, "adm_umsg", uid)
    await show(c, "✉️ Напиши сообщение — оно придёт пользователю от имени администрации.", back_kb(f"ad:u:{uid}", "⬅️ Отмена"))


@router.message(InState("adm_umsg"))
async def on_msg(m: Message, st_data: str):
    if _deny(m) or not m.text:
        return
    uid = int(st_data)
    await eat(m)
    await enqueue(uid, f"✉️ <b>Сообщение от администрации:</b>\n\n{m.html_text}", priority=PRIO_ADMIN,
                  dedupe_key=f"dm:{uid}:{now_local():%Y%m%d%H%M%S}")
    await set_state(m.from_user.id)
    await ephemeral(m, "✅ Отправлено", 4)
    await card(m, uid)
