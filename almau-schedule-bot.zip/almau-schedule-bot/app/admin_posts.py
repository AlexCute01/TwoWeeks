"""Лента новостей — только для админов: создать пост, разослать, смотреть историю и доставку, править и удалять
у всех получателей. У студентов отдельной ленты нет — пост приходит сообщением (можно отписаться в настройках)."""
import logging

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select

from . import access
from .common import InState, eat, ephemeral, set_state, show
from .config import COURSES
from .db import Group, Outbox, Post, Session, User, meta_get, meta_set
from .outbox import PRIO_NEWS, enqueue_many
from .programs import DEPTS
from .ui import back_kb
from .util import esc, now_local

log = logging.getLogger(__name__)
router = Router()
B = InlineKeyboardButton
PAGE = 6


def _deny(ev) -> bool:
    return not access.is_admin(ev.from_user.id)


def _kind(m: Message) -> str:
    return ("photo" if m.photo else "video" if m.video else "file" if m.document else
            "text" if m.text else "other")


KIND_ICON = {"text": "📝", "photo": "🖼", "video": "🎬", "file": "📎", "other": "📦"}


def _trim(html: str, limit: int = 700) -> str:
    lines = (html or "").split("\n")
    while len("\n".join(lines)) > limit and len(lines) > 1:
        lines.pop()
    out = "\n".join(lines)
    return out if len(out) <= limit else out[:limit].rsplit(" ", 1)[0] + "…"


async def _audience(s, post: Post) -> list[int]:
    q = select(User.tg_id).where(User.news_on.is_(True), User.blocked.is_(False))
    if post.target_group_id:
        q = q.where(User.group_id == post.target_group_id)
    return list(await s.scalars(q))


async def _drop_preview(bot: Bot, chat_id: int, pid: int):
    async with Session() as s:
        mid = await meta_get(s, f"prev:{pid}")
        if mid:
            await meta_set(s, f"prev:{pid}", "")
            await s.commit()
    if mid:
        try:
            await bot.delete_message(chat_id, int(mid))
        except Exception:
            pass


# ───────────────────────── создание ─────────────────────────

@router.callback_query(F.data == "ad:post")
async def cb_post(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id, "post_compose")
    await show(c, "📰 <b>Новый пост</b>\n\nПришли сообщение для рассылки: текст, фото, видео или файл (с подписью). "
                  "Придёт всем в том же виде, форматирование (жирный, ссылки) сохранится.\n\n"
                  "Перед отправкой покажу превью и спрошу подтверждение. Позже пост можно будет <b>править и удалить у всех</b> "
                  "в «📚 Посты и лента».", back_kb("ad:home", "⬅️ Отмена"))


@router.message(InState("post_compose"))
async def on_compose(m: Message, bot: Bot):
    if _deny(m):
        return
    async with Session() as s:
        post = Post(author_id=m.from_user.id, src_chat_id=m.chat.id, src_message_id=m.message_id, status="draft",
                    created_at=now_local(), kind=_kind(m), html=(m.html_text if (m.text or m.caption) else "") or "")
        s.add(post)
        await s.commit()
        pid = post.id
    await set_state(m.from_user.id)
    if post.kind != "text":                       # превью вложения; текст покажем прямо в экране
        try:
            mid = await bot.copy_message(m.chat.id, m.chat.id, m.message_id)
            async with Session() as s:
                await meta_set(s, f"prev:{pid}", str(mid.message_id))
                await s.commit()
        except Exception:
            pass
    await _menu(m, pid)


async def _menu(target, pid: int):
    async with Session() as s:
        post = await s.get(Post, pid)
        n = len(await _audience(s, post))
        g = await s.get(Group, post.target_group_id) if post.target_group_id else None
    kb = InlineKeyboardBuilder()
    where = f"{g.course} курс · {g.title}" if g else "всем"
    kb.button(text=f"✅ Отправить: {where} ({n})", callback_data=f"ad:pconf:{pid}")
    kb.button(text="🎯 Только одной группе" if not g else "👥 Вернуть «всем»",
              callback_data=f"ad:pt:{pid}" if not g else f"ad:pall:{pid}")
    kb.button(text="🗑 Отменить пост", callback_data=f"ad:pdel:{pid}")
    kb.adjust(1)
    preview = (f"👆 <b>Так увидят студенты:</b>\n\n{post.html}\n\n" if post.kind == "text" else "👆 <b>Превью выше.</b>\n\n")
    await show(target, f"{preview}Получателей: <b>{n}</b> (кто не отказался от новостей)\n"
                       f"Цель: <b>{esc(where)}</b>", kb.as_markup(), delete_src=False)


@router.callback_query(F.data.startswith("ad:pall:"))
async def cb_all(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        (await s.get(Post, pid)).target_group_id = None
        await s.commit()
    await _menu(c, pid)


@router.callback_query(F.data.startswith("ad:pt:"))
async def cb_target(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = c.data.split(":")[2]
    kb = InlineKeyboardBuilder()
    for cc in COURSES:
        kb.button(text=f"📘 {cc} курс", callback_data=f"ad:pc:{pid}:{cc}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pall:{pid}")
    kb.adjust(3, 1)
    await show(c, "Выбери курс:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:pc:"))
async def cb_target_course(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, pid, course = c.data.split(":")
    async with Session() as s:
        rows = await s.execute(select(Group.dept, func.count()).where(Group.course == int(course)).group_by(Group.dept))
        counts = {d or "": n for d, n in rows}
    kb = InlineKeyboardBuilder()
    for key, label in DEPTS.items():
        if counts.get(key):
            kb.button(text=label, callback_data=f"ad:pd:{pid}:{course}:{key or '_'}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pt:{pid}")
    kb.adjust(1)
    await show(c, f"{course} курс — выбери отделение:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:pd:"))
async def cb_target_dept(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, pid, course, dept = c.data.split(":")
    async with Session() as s:
        groups = list(await s.scalars(select(Group).where(Group.course == int(course), Group.dept == dept.replace("_", ""))
                                      .order_by(Group.title)))
    kb = InlineKeyboardBuilder()
    for g in groups:
        kb.button(text=(g.title or g.name)[:44], callback_data=f"ad:pg:{pid}:{g.id}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pc:{pid}:{course}")
    kb.adjust(1)
    await show(c, "Выбери программу:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:pg:"))
async def cb_target_group(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, pid, gid = c.data.split(":")
    async with Session() as s:
        (await s.get(Post, int(pid))).target_group_id = int(gid)
        await s.commit()
    await _menu(c, int(pid))


@router.callback_query(F.data.startswith("ad:pconf:"))
async def cb_confirm(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        post = await s.get(Post, pid)
        n = len(await _audience(s, post))
    kb = InlineKeyboardBuilder()
    kb.button(text=f"🚀 Да, отправить ({n})", callback_data=f"ad:psend:{pid}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pall:{pid}" if not post.target_group_id else f"ad:pg:{pid}:{post.target_group_id}")
    kb.adjust(1)
    await show(c, f"⚠️ Отправить пост <b>{n}</b> получателям?\nПотом его можно будет исправить или удалить у всех "
                  "(Telegram позволяет удалять сообщения бота в течение 48 часов).", kb.as_markup())


@router.callback_query(F.data.startswith("ad:psend:"))
async def cb_send(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        post = await s.get(Post, pid)
        if post.status != "draft":
            return await c.answer("Этот пост уже отправлен", show_alert=True)
        ids = await _audience(s, post)
        queued = await enqueue_many(s, [dict(user_id=uid, kind="copy", src_chat_id=post.src_chat_id,
                                             src_message_id=post.src_message_id, post_id=pid, priority=PRIO_NEWS,
                                             dedupe_key=f"post:{pid}:{uid}") for uid in ids])
        post.status, post.sent_count = "sent", queued
        await s.commit()
    await _drop_preview(bot, c.message.chat.id, pid)
    await show(c, f"🚀 <b>Рассылка запущена</b>: {queued} получателей, доставка ~{max(1, queued // 25)} сек.\n"
                  "Следить, править и удалять — «📚 Посты и лента».", _after_kb(pid))


def _after_kb(pid: int):
    kb = InlineKeyboardBuilder()
    kb.button(text="📋 Карточка поста", callback_data=f"ad:p:{pid}")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    return kb.as_markup()


@router.callback_query(F.data.startswith("ad:pdel:"))
async def cb_draft_delete(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        post = await s.get(Post, pid)
        if post and post.status == "draft":
            await s.delete(post)
            await s.commit()
    await _drop_preview(bot, c.message.chat.id, pid)
    from .admin import admin_home
    await admin_home(c)


# ───────────────────────── история и управление ─────────────────────────

@router.callback_query(F.data.startswith("ad:posts:"))
async def cb_history(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await history(c, int(c.data.split(":")[2]))


async def history(c: CallbackQuery, page: int = 0):
    async with Session() as s:
        total = await s.scalar(select(func.count()).select_from(Post).where(Post.status != "draft"))
        posts = list(await s.scalars(select(Post).where(Post.status != "draft").order_by(Post.id.desc())
                                     .offset(page * PAGE).limit(PAGE)))
    kb = InlineKeyboardBuilder()
    for p in posts:
        icon = "🗑" if p.status == "deleted" else KIND_ICON.get(p.kind, "📦")
        snippet = (p.html or "").replace("\n", " ")
        snippet = "".join(ch for ch in snippet if ch not in "<>")[:22]
        kb.row(B(text=f"{icon} #{p.id} · {p.created_at:%d.%m %H:%M} · 👥{p.sent_count} · {snippet}",
                 callback_data=f"ad:p:{p.id}"))
    nav = []
    if page > 0:
        nav.append(B(text="◀️", callback_data=f"ad:posts:{page - 1}"))
    if (page + 1) * PAGE < total:
        nav.append(B(text="▶️", callback_data=f"ad:posts:{page + 1}"))
    if nav:
        kb.row(*nav)
    kb.row(B(text="📰 Новый пост", callback_data="ad:post"), B(text="⬅️ В админку", callback_data="ad:home"))
    await show(c, f"📚 <b>Посты и лента</b> · всего: {total}\n<i>История видна только админам.</i>"
                  + ("" if posts else "\n\nПока ничего не отправляли."), kb.as_markup())


async def _stats(s, pid: int) -> dict:
    rows = await s.execute(select(Outbox.status, func.count()).where(Outbox.post_id == pid, Outbox.kind == "copy")
                           .group_by(Outbox.status))
    d = dict(rows.all())
    return {"ok": d.get(1, 0) + d.get(3, 0), "wait": d.get(0, 0), "fail": d.get(2, 0)}


@router.callback_query(F.data.startswith("ad:p:"))
async def cb_card(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    await set_state(c.from_user.id)
    async with Session() as s:
        p = await s.get(Post, pid)
        if not p:
            return await c.answer("Пост не найден", show_alert=True)
        st = await _stats(s, pid)
        g = await s.get(Group, p.target_group_id) if p.target_group_id else None
    status = {"sent": "✅ отправлен", "deleted": "🗑 удалён у получателей", "draft": "📝 черновик"}[p.status]
    body = _trim(p.html) if p.html else "<i>без текста</i>"
    text = (f"{KIND_ICON.get(p.kind, '📦')} <b>Пост #{p.id}</b> · {p.created_at:%d.%m.%Y %H:%M}\n"
            f"{status} · цель: {esc(f'{g.course} курс · {g.title}') if g else 'все студенты'}\n"
            f"Доставка: ✅ {st['ok']} · ⏳ {st['wait']} · ❌ {st['fail']}" + (f" · правок: {p.rev}" if p.rev else "")
            + f"\n\n{body}")
    kb = InlineKeyboardBuilder()
    if p.status == "sent":
        kb.button(text="✏️ Изменить текст у всех", callback_data=f"ad:pe:{pid}")
        kb.button(text="🗑 Удалить у всех получателей", callback_data=f"ad:pdx:{pid}")
    if p.kind != "text":
        kb.button(text="👁 Показать вложение", callback_data=f"ad:pv:{pid}")
    kb.button(text="🗂 Убрать из истории", callback_data=f"ad:ph:{pid}")
    kb.button(text="⬅️ К списку", callback_data="ad:posts:0")
    kb.adjust(1)
    await show(c, text, kb.as_markup())


@router.callback_query(F.data.startswith("ad:pv:"))
async def cb_view_attachment(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    async with Session() as s:
        p = await s.get(Post, int(c.data.split(":")[2]))
    try:
        mid = await bot.copy_message(c.message.chat.id, p.src_chat_id, p.src_message_id, caption=p.html or None,
                                     reply_markup=back_kb("x:close", "✖️ Закрыть"))
        await c.answer()
    except Exception:
        await c.answer("Оригинал недоступен (удалён из чата)", show_alert=True)


@router.callback_query(F.data.startswith("ad:pe:"))
async def cb_edit(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = c.data.split(":")[2]
    await set_state(c.from_user.id, "post_edit", pid)
    await show(c, "✏️ Пришли <b>новый текст</b> (для постов с фото/файлом — новую подпись). Форматирование сохранится.\n"
                  "Текст обновится у всех, кто уже получил пост.", back_kb(f"ad:p:{pid}", "⬅️ Отмена"))


@router.message(InState("post_edit"))
async def on_edit(m: Message, st_data: str):
    if _deny(m) or not (m.text or m.caption):
        return
    pid = int(st_data)
    new_html = m.html_text
    await eat(m)
    async with Session() as s:
        p = await s.get(Post, pid)
        p.html, p.rev = new_html, p.rev + 1
        rows = await s.execute(select(Outbox.user_id, Outbox.sent_msg_id).where(
            Outbox.post_id == pid, Outbox.kind == "copy", Outbox.status == 1, Outbox.sent_msg_id.is_not(None)))
        items = [dict(user_id=uid, kind="edit", src_message_id=mid, text=new_html, post_id=pid, priority=PRIO_NEWS,
                      dedupe_key=f"pedit:{pid}:{p.rev}:{uid}") for uid, mid in rows]
        n = await enqueue_many(s, items)
        await s.commit()
    await set_state(m.from_user.id)
    await ephemeral(m, f"✅ Текст обновлён у {n} получателей (доставка займёт пару секунд).", 6)
    await _card_for(m, pid)


async def _card_for(m: Message, pid: int):
    async with Session() as s:
        p = await s.get(Post, pid)
        st = await _stats(s, pid)
    kb = InlineKeyboardBuilder()
    kb.button(text="📋 Открыть карточку", callback_data=f"ad:p:{pid}")
    kb.button(text="⬅️ К списку", callback_data="ad:posts:0")
    kb.adjust(1)
    await show(m, f"✅ Пост #{pid} обновлён (правка №{p.rev}).\nДоставка исходной рассылки: ✅ {st['ok']}", kb.as_markup(),
               delete_src=False)


@router.callback_query(F.data.startswith("ad:pdx:"))
async def cb_delete_ask(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = c.data.split(":")[2]
    kb = InlineKeyboardBuilder()
    kb.button(text="🗑 Да, удалить у всех", callback_data=f"ad:pdxok:{pid}")
    kb.button(text="⬅️ Нет", callback_data=f"ad:p:{pid}")
    kb.adjust(1)
    await show(c, "Удалить это сообщение <b>у всех получателей</b>?\n<i>Telegram позволяет боту удалять свои сообщения "
                  "только в течение 48 часов после отправки — у остальных оно останется.</i>", kb.as_markup())


@router.callback_query(F.data.startswith("ad:pdxok:"))
async def cb_delete(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        p = await s.get(Post, pid)
        rows = await s.execute(select(Outbox.user_id, Outbox.sent_msg_id).where(
            Outbox.post_id == pid, Outbox.kind == "copy", Outbox.status == 1, Outbox.sent_msg_id.is_not(None)))
        n = await enqueue_many(s, [dict(user_id=uid, kind="delete", src_message_id=mid, post_id=pid, priority=PRIO_NEWS,
                                        dedupe_key=f"pdel:{pid}:{uid}") for uid, mid in rows])
        p.status = "deleted"
        await s.commit()
    await c.answer(f"Удаляю у {n} получателей", show_alert=True)
    await history(c, 0)


@router.callback_query(F.data.startswith("ad:ph:"))
async def cb_hide(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    async with Session() as s:
        p = await s.get(Post, int(c.data.split(":")[2]))
        if p:
            await s.delete(p)
            await s.commit()
    await history(c, 0)
