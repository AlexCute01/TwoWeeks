from datetime import time

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    bot_token: str
    database_url: str = "sqlite+aiosqlite:///./bot.db"
    schedule_url: str = ""                # ссылка на xlsx (SharePoint)
    admin_ids: str = ""                   # "123456,789012" — кто может слать xlsx и делать /sync
    timezone: str = "Asia/Almaty"
    # Дата начала семестра: от неё считается чётность недели.
    # Неделя, в которую попадает эта дата, считается НЕЧЁТНОЙ (1-я).
    semester_start: str = "2026-09-01"

    # --- слежение за изменениями расписания ---
    sync_interval_min: int = 3            # как часто скачиваем файл
    debounce_min: int = 3                 # файл должен «постоять» без правок столько минут (защита от спама)
    min_lessons_ratio: float = 0.5        # если в новом файле пар < 50% от текущих — считаем файл сломанным

    @property
    def admins(self) -> set[int]:
        return {int(x) for x in self.admin_ids.split(",") if x.strip()}


settings = Settings()

# ⚠️ ПРИМЕР! Замени на реальное время пар вашего университета
# (или скажи мне — вытащим из файла, если оно там указано).
PAIR_TIMES: dict[int, tuple[time, time]] = {
    1: (time(9, 0), time(10, 20)),
    2: (time(10, 30), time(11, 50)),
    3: (time(12, 0), time(13, 20)),
    4: (time(13, 30), time(14, 50)),
    5: (time(15, 0), time(16, 20)),
    6: (time(16, 30), time(17, 50)),
    7: (time(18, 0), time(19, 20)),
}

# Для самой первой пары дня напоминаем на столько минут раньше (время на сборы)
FIRST_PAIR_EXTRA_MIN = 20
# Доступные варианты «напомнить за N минут»
LEADS = (5, 10, 15, 30)
