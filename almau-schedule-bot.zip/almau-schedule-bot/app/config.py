from datetime import time

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    bot_token: str
    admin_ids: str = ""                   # ВЛАДЕЛЬЦЫ (через запятую): всегда админы, их нельзя удалить из бота
    data_dir: str = "./data_local"        # БД, бэкапы — всё, что нельзя терять при обновлении
    database_url: str = "sqlite+aiosqlite:///./data_local/bot.db"
    schedule_url: str = ""                # ссылка на xlsx (SharePoint)
    timezone: str = "Asia/Almaty"
    semester_start: str = "2026-09-01"    # для чётных/нечётных недель, если появятся в таблице

    # --- проверка расписания: с sync_start до sync_end каждые sync_every_min минут ---
    sync_start: str = "06:00"
    sync_end: str = "18:00"
    sync_every_min: int = 50
    min_lessons_ratio: float = 0.5        # пар в новом файле < 50% от текущих — файл сломан, не применяем
    include_hidden_sheets: bool = False   # скрытые листы = архив/черновики

    # --- бэкап ---
    backup_time: str = "04:30"
    backup_keep_days: int = 14

    @property
    def owners(self) -> set[int]:
        return {int(x) for x in self.admin_ids.replace(";", ",").split(",") if x.strip().isdigit()}

    def sync_slots(self) -> set[str]:
        """{'06:00', '06:50', '07:40', ...} — минуты, в которые бот проверяет файл."""
        def to_min(s: str) -> int:
            h, m = s.split(":")
            return int(h) * 60 + int(m)
        out, t, end = set(), to_min(self.sync_start), to_min(self.sync_end)
        while t <= end:
            out.add(f"{t // 60:02d}:{t % 60:02d}")
            t += max(5, self.sync_every_min)
        return out


settings = Settings()

# Варианты в настройках
REMIND_OPTIONS = (5, 10, 15, 20, 30, 45, 60)      # «напомнить за N минут»
FIRST_EXTRA_OPTIONS = (0, 15, 30, 60)             # «первую пару дня — ещё на N минут раньше»
MORNING_PRESETS = (time(6, 30), time(7, 0), time(7, 30), time(8, 0), time(8, 30), time(9, 0))
EVENING_PRESETS = (time(19, 0), time(20, 0), time(21, 0), time(21, 30), time(22, 0), time(23, 0))
