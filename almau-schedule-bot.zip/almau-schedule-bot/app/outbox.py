"""
Очередь исходящих сообщений.

Зачем: у Telegram лимит ~30 сообщений/сек на бота. Когда расписание поменялось у всего потока,
а уведомления нужны 3000 людям, отправлять «в лоб» нельзя. Поэтому все уведомления кладутся
в таблицу outbox (атомарно с изменением расписания!), а sender_loop отправляет их
со скоростью 25/сек, по приоритету, с повтором при ошибках. Перезапуск бота ничего не теряет.
"""
import asyncio
import logging
import time as _time
from datetime import timedelta

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from sqlalchemy import select, update
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from .config import settings
from .db import Outbox, Session, User
from .util import now_local

log = logging.getLogger(__name__)

RATE = 25          # сообщений в секунду
MAX_ATTEMPTS = 6

PRIO_REMINDER, PRIO_URGENT, PRIO_CHANGE, PRIO_ADMIN, PRIO_DIGEST = 9, 5, 3, 8, 1


async def enqueue_many(s, items: list[dict]) -> int:
    """items: {user_id, text, dedupe_key?, priority?, expires_at?}. Возвращает, сколько реально добавлено
    (дубли по dedupe_key молча пропускаются). Коммит — на вызывающем."""
    if not items:
        return 0
    now = now_local()
    rows = [dict(user_id=i["user_id"], text=i["text"], dedupe_key=i.get("dedupe_key"),
                 priority=i.get("priority", 0), status=0, attempts=0, send_after=now,
                 expires_at=i.get("expires_at"), created_at=now) for i in items]
    added = 0
    for k in range(0, len(rows), 300):
        res = await s.execute(
            sqlite_insert(Outbox).values(rows[k:k + 300]).on_conflict_do_nothing(index_elements=["dedupe_key"]))
        added += res.rowcount or 0
    return added


async def enqueue(user_id: int, text: str, **kw) -> int:
    async with Session() as s:
        n = await enqueue_many(s, [dict(user_id=user_id, text=text, **kw)])
        await s.commit()
    return n


async def alert_admins(text: str, key: str) -> None:
    """Сообщение админам; key делает его «не чаще раза» (например, раз в день)."""
    for admin in settings.admins:
        await enqueue(admin, text, dedupe_key=f"{key}:{admin}", priority=PRIO_ADMIN)


async def _deliver(bot: Bot, row: Outbox) -> tuple[str, float]:
    try:
        await bot.send_message(row.user_id, row.text)
        return "sent", 0.0
    except TelegramRetryAfter as e:
        return "retry", float(e.retry_after)
    except TelegramForbiddenError:
        return "blocked", 0.0
    except TelegramBadRequest as e:
        log.warning("drop message to %s: %s", row.user_id, e)
        return "drop", 0.0
    except Exception as e:  # сеть и т.п. — повторим позже
        log.warning("send to %s failed: %s", row.user_id, e)
        return "error", 0.0


async def send_batch(bot: Bot) -> int:
    now = now_local()
    pause = 0.0
    async with Session() as s:
        rows = list(await s.scalars(
            select(Outbox).where(Outbox.status == 0, Outbox.send_after <= now)
            .order_by(Outbox.priority.desc(), Outbox.id).limit(RATE)))
        if not rows:
            return 0
        live = []
        for r in rows:
            if r.expires_at and r.expires_at < now:   # напоминание о паре, которая уже началась
                r.status = 2
            else:
                live.append(r)
        results = await asyncio.gather(*(_deliver(bot, r) for r in live))

        blocked: list[int] = []
        for r, (res, delay) in zip(live, results):
            if res == "sent":
                r.status = 1
            elif res == "retry":
                r.send_after = now + timedelta(seconds=delay + 1)
                pause = max(pause, delay)
            elif res in ("blocked", "drop"):
                r.status = 2
                if res == "blocked":
                    blocked.append(r.user_id)
            else:
                r.attempts += 1
                if r.attempts >= MAX_ATTEMPTS:
                    r.status = 2
                else:
                    r.send_after = now + timedelta(seconds=30 * r.attempts)
        if blocked:
            await s.execute(update(User).where(User.tg_id.in_(blocked)).values(blocked=True))
            await s.execute(update(Outbox).where(Outbox.user_id.in_(blocked), Outbox.status == 0)
                            .values(status=2))
        await s.commit()
    if pause:
        await asyncio.sleep(pause)
    return len(rows)


async def sender_loop(bot: Bot) -> None:
    while True:
        t0 = _time.monotonic()
        try:
            n = await send_batch(bot)
        except Exception:
            log.exception("sender_loop")
            n = 0
        spent = _time.monotonic() - t0
        await asyncio.sleep(max(0.0, 1.0 - spent) if n else 1.0)
