"""
Очередь исходящих сообщений.

Лимит Telegram — ~30 сообщений/сек на бота, поэтому всё (уведомления, рассылки, правки и удаления постов)
кладётся в таблицу outbox, а sender_loop отправляет со скоростью 25/сек по приоритету, с повторами при ошибках.
Перезапуск ничего не теряет. Для каждого отправленного сообщения запоминается его id — по нему работают
правка/удаление постов и автоочистка устаревших уведомлений (janitor_loop).
"""
import asyncio
import logging
import time as _time
from datetime import timedelta

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from sqlalchemy import select, update
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from .config import settings
from .db import Outbox, Session, User
from .util import now_local

log = logging.getLogger(__name__)

RATE = 25          # сообщений в секунду
MAX_ATTEMPTS = 6

PRIO_REMINDER, PRIO_ADMIN, PRIO_URGENT, PRIO_CHANGE, PRIO_NEWS, PRIO_DIGEST = 9, 8, 5, 3, 2, 1


async def enqueue_many(s, items: list[dict]) -> int:
    """items: {user_id, text | src_chat_id+src_message_id, kind?, post_id?, dedupe_key?, priority?, expires_at?, delete_after?}.
    Дубли по dedupe_key молча пропускаются. Коммит — на вызывающем."""
    if not items:
        return 0
    now = now_local()
    rows = [dict(user_id=i["user_id"], kind=i.get("kind") or ("copy" if i.get("src_chat_id") else "text"),
                 post_id=i.get("post_id"), text=i.get("text", ""), src_chat_id=i.get("src_chat_id"),
                 src_message_id=i.get("src_message_id"), dedupe_key=i.get("dedupe_key"),
                 priority=i.get("priority", 0), status=0, attempts=0, send_after=now,
                 expires_at=i.get("expires_at"), delete_after=i.get("delete_after"), created_at=now,
                 sent_msg_id=None) for i in items]
    added = 0
    for k in range(0, len(rows), 200):
        res = await s.execute(
            sqlite_insert(Outbox).values(rows[k:k + 200]).on_conflict_do_nothing(index_elements=["dedupe_key"]))
        added += res.rowcount or 0
    return added


async def enqueue(user_id: int, text: str, **kw) -> int:
    async with Session() as s:
        n = await enqueue_many(s, [dict(user_id=user_id, text=text, **kw)])
        await s.commit()
    return n


async def alert_admins(text: str, key: str, ids=None) -> None:
    """Сообщение админам; key делает его «не чаще раза» (например, раз в день)."""
    from . import access
    for admin in (ids if ids is not None else access.all_admins() or settings.owners):
        await enqueue(admin, text, dedupe_key=f"{key}:{admin}", priority=PRIO_ADMIN)


async def _deliver(bot: Bot, row: Outbox) -> tuple[str, float, int | None]:
    try:
        if row.kind == "copy":
            mid = await bot.copy_message(row.user_id, row.src_chat_id, row.src_message_id)
            return "sent", 0.0, mid.message_id
        if row.kind == "edit":
            try:
                await bot.edit_message_text(text=row.text, chat_id=row.user_id, message_id=row.src_message_id)
            except TelegramBadRequest as e:
                low = str(e).lower()
                if "not modified" in low:
                    return "sent", 0.0, None
                if "no text" in low:      # у сообщения нет текста — это подпись к медиа
                    await bot.edit_message_caption(chat_id=row.user_id, message_id=row.src_message_id, caption=row.text)
                else:
                    raise
            return "sent", 0.0, None
        if row.kind == "delete":
            try:
                await bot.delete_message(row.user_id, row.src_message_id)
            except TelegramBadRequest:
                pass                      # уже удалено / старше 48 ч — считаем выполненным
            return "sent", 0.0, None
        m = await bot.send_message(row.user_id, row.text)
        return "sent", 0.0, m.message_id
    except TelegramRetryAfter as e:
        return "retry", float(e.retry_after), None
    except TelegramForbiddenError:
        return "blocked", 0.0, None
    except TelegramBadRequest as e:
        log.warning("drop message to %s: %s", row.user_id, e)
        return "drop", 0.0, None
    except Exception as e:  # сеть и т.п. — повторим позже
        log.warning("send to %s failed: %s", row.user_id, e)
        return "error", 0.0, None


async def send_batch(bot: Bot) -> int:
    now = now_local()
    pause = 0.0
    async with Session() as s:
        rows = list(await s.scalars(
            select(Outbox).where(Outbox.status == 0, Outbox.send_after <= now)
            .order_by(Outbox.priority.desc(), Outbox.id).limit(RATE)))
        if not rows:
            return 0
        live = []
        for r in rows:
            if r.expires_at and r.expires_at < now:   # напоминание о паре, которая уже началась
                r.status = 2
            else:
                live.append(r)
        results = await asyncio.gather(*(_deliver(bot, r) for r in live))

        blocked: list[int] = []
        for r, (res, delay, mid) in zip(live, results):
            if res == "sent":
                r.status, r.sent_msg_id = 1, mid
            elif res == "retry":
                r.send_after = now + timedelta(seconds=delay + 1)
                pause = max(pause, delay)
            elif res in ("blocked", "drop"):
                r.status = 2
                if res == "blocked":
                    blocked.append(r.user_id)
            else:
                r.attempts += 1
                if r.attempts >= MAX_ATTEMPTS:
                    r.status = 2
                else:
                    r.send_after = now + timedelta(seconds=30 * r.attempts)
        if blocked:
            await s.execute(update(User).where(User.tg_id.in_(blocked)).values(blocked=True))
            await s.execute(update(Outbox).where(Outbox.user_id.in_(blocked), Outbox.status == 0)
                            .values(status=2))
        await s.commit()
    if pause:
        await asyncio.sleep(pause)
    return len(rows)


async def sender_loop(bot: Bot) -> None:
    while True:
        t0 = _time.monotonic()
        try:
            n = await send_batch(bot)
        except Exception:
            log.exception("sender_loop")
            n = 0
        spent = _time.monotonic() - t0
        await asyncio.sleep(max(0.0, 1.0 - spent) if n else 1.0)


async def janitor_loop(bot: Bot) -> None:
    """Автоочистка: удаляет у пользователей устаревшие уведомления (напоминание после начала пары и т.п.)."""
    while True:
        await asyncio.sleep(15)
        try:
            async with Session() as s:
                rows = list(await s.scalars(
                    select(Outbox).where(Outbox.status == 1, Outbox.delete_after.is_not(None),
                                         Outbox.delete_after <= now_local(), Outbox.sent_msg_id.is_not(None))
                    .limit(150)))
                for k in range(0, len(rows), 20):
                    chunk = rows[k:k + 20]

                    async def _del(r):
                        try:
                            await bot.delete_message(r.user_id, r.sent_msg_id)
                        except Exception:
                            pass
                        r.status = 3
                    await asyncio.gather(*(_del(r) for r in chunk))
                    await asyncio.sleep(0.8)
                await s.commit()
        except Exception:
            log.exception("janitor_loop")
