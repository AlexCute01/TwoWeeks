"""Красивое форматирование расписания (HTML для Telegram). Без БД и aiogram."""
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from .util import MONTHS, WEEKDAYS, WEEKDAYS_SHORT, esc, norm_room

NUM = ["0️⃣", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"]


@dataclass
class Item:
    start: time
    end: time
    title: str
    room: str = ""
    teacher: str = ""
    kind: str = ""
    personal: bool = False
    segs: tuple = ()          # академические часы: ((start, end), ...)


def _min(t: time) -> int:
    return t.hour * 60 + t.minute


def fmt_dur(minutes: int) -> str:
    h, m = divmod(max(0, int(minutes)), 60)
    return " ".join(x for x in (f"{h} ч" if h else "", f"{m} мин" if m else "") if x) or "0 мин"


def date_label(d: date) -> str:
    return f"{WEEKDAYS[d.weekday()]}, {d.day} {MONTHS[d.month - 1]}"


def building_of(code: str, rooms) -> str:
    for part in (p.strip() for p in (code or "").split(",")):
        r = rooms.get(norm_room(part))
        if r and r.building:
            return r.building
    return ""


def room_line(code: str, rooms) -> str:
    if not code:
        return ""
    if code.lower().startswith("http"):
        return f"онлайн 🔗 {esc(code)}"
    parts = [p.strip() for p in code.split(",") if p.strip()]
    if len(parts) > 1:
        return ", ".join(room_line(p, rooms) for p in parts)
    r = rooms.get(norm_room(code))
    if not r:
        return esc(code)
    loc = ", ".join(x for x in (r.building, f"{r.floor} этаж" if r.floor else "") if x)
    return esc(code) + (f" — {esc(loc)}" if loc else "")


def room_card(code: str, rooms) -> str:
    r = rooms.get(norm_room(code))
    if not r:
        return f"Про аудиторию <b>{esc(code)}</b> у меня пока нет описания 🤷"
    lines = [f"📍 <b>Аудитория {esc(code)}</b>"]
    if r.building:
        lines.append(f"🏢 {esc(r.building)}")
    if r.floor:
        lines.append(f"🪜 {r.floor} этаж")
    if r.description:
        lines.append(f"\n{esc(r.description)}")
    return "\n".join(lines)


def hours_label(it: Item) -> str:
    n = len(it.segs)
    return f" · {n} ак. ч" if n > 1 else ""


def _block(num: int, it: Item, rooms, marker: str = "", status: str = "") -> str:
    star = "⭐ " if it.personal else ""
    head = f"{marker or (NUM[num] if num < 10 else f'{num}.')} <b>{it.start:%H:%M}–{it.end:%H:%M}</b>{hours_label(it)}{status}"
    lines = [head, f"┃ 📚 <b>{star}{esc(it.title)}</b>" + (f" <i>({esc(it.kind)})</i>" if it.kind else "")]
    meta = []
    if it.room:
        meta.append(f"📍 {room_line(it.room, rooms)}")
    if it.teacher:
        meta.append(f"👤 {esc(it.teacher)}")
    lines += [f"┃ {m}" for m in meta]
    return "\n".join(lines)


def format_day(items: list[Item], d: date, rooms, now: datetime | None = None, title: str = "") -> str:
    head = f"📅 <b>{date_label(d)}</b>" + (f"\n<i>{esc(title)}</i>" if title else "")
    if not items:
        return head + "\n\n🎉 <b>Пар нет</b> — отдыхай!"
    live = bool(now) and d == now.date()
    nowt = now.time() if live else None
    out = [head, ""]
    prev = None
    next_marked = False
    for i, it in enumerate(items, 1):
        if prev:
            gap = _min(it.start) - _min(prev.end)
            if gap >= 50:
                out.append(f"┈┈ ⏸ <i>окно {fmt_dur(gap)}</i>")
            pb, nb = building_of(prev.room, rooms), building_of(it.room, rooms)
            if pb and nb and pb != nb:
                out.append(f"┈┈ 🚶 <i>смена корпуса: {esc(pb)} → {esc(nb)}</i>")
        marker, status = "", ""
        if live:
            if it.start <= nowt < it.end:
                marker, status = "🟢", f" · <b>идёт</b>, осталось {fmt_dur(_min(it.end) - _min(nowt))}"
            elif it.end <= nowt:
                marker = "✅"
            elif not next_marked:
                next_marked = True
                status = f" · <b>через {fmt_dur(_min(it.start) - _min(nowt))}</b>"
        out.append(_block(i, it, rooms, marker, status))
        out.append("")
        prev = it
    out.append(f"🏁 Заканчиваешь в <b>{prev.end:%H:%M}</b>")
    return "\n".join(out)


def format_week(days: list[tuple[date, list[Item]]], rooms, title: str = "", today: date | None = None) -> str:
    monday = days[0][0]
    out = [f"🗓 <b>Неделя с {monday.day} {MONTHS[monday.month - 1]}</b>" + (f"\n<i>{esc(title)}</i>" if title else ""), ""]
    for d, items in days:
        mark = "🔸" if today and d == today else "▫️"
        out.append(f"{mark} <b>{WEEKDAYS_SHORT[d.weekday()]} {d.day:02d}.{d.month:02d}</b>" + ("" if items else " — <i>пар нет</i>"))
        for it in items:
            room = f" · 📍{esc(it.room)}" if it.room else ""
            out.append(f"   <code>{it.start:%H:%M}</code> {esc(it.title)}{room}")
        out.append("")
    return "\n".join(out).rstrip()
