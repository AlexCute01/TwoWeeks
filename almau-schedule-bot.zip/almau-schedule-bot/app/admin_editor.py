"""Редактор расписания для админа: курс → отделение → программа → день → пара.
Пара открывается «карточкой» с курсором по ячейкам (⬆️⬇️), стрелками времени (◀ ▶) и переходом между парами дня."""
import logging

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select

from . import access, editing
from .changes import build_message
from .common import InState, eat, set_state, show
from .config import COURSES
from .db import Group, Lesson, Session
from .programs import DEPTS
from .sync import enqueue_actual, reapply_stored, record_and_notify, stored_path
from .util import WEEKDAYS_SHORT, esc, now_local

log = logging.getLogger(__name__)
router = Router()
B = InlineKeyboardButton


def _deny(c) -> bool:
    return not access.is_admin(c.from_user.id)


def _title(g: Group) -> str:
    return f"{g.course} курс · {g.title or g.name.split('|', 1)[-1]}"


# ───────────────────────── выбор программы ─────────────────────────

@router.callback_query(F.data == "ed:home")
async def cb_home(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    async with Session() as s:
        rows = await s.execute(select(Group.course, func.count()).group_by(Group.course))
        counts = dict(rows.all())
    kb = InlineKeyboardBuilder()
    for course in COURSES:
        if counts.get(course):
            kb.button(text=f"📘 {course} курс · {counts[course]}", callback_data=f"ed:c:{course}")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    await show(c, "🗓 <b>Редактор расписания</b>\n\nВыбери курс. Правки сохраняются поверх файла: "
                  "следующая загрузка таблицы их не затирает.", kb.as_markup())


@router.callback_query(F.data.startswith("ed:c:"))
async def cb_course(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    course = int(c.data.split(":")[2])
    async with Session() as s:
        rows = await s.execute(select(Group.dept, func.count()).where(Group.course == course).group_by(Group.dept))
        counts = {d or "": n for d, n in rows}
    kb = InlineKeyboardBuilder()
    for key, label in DEPTS.items():
        if counts.get(key):
            kb.button(text=f"{label} · {counts[key]}", callback_data=f"ed:d:{course}:{key or '_'}")
    kb.button(text="⬅️ К курсам", callback_data="ed:home")
    kb.adjust(1)
    await show(c, f"🗓 <b>{course} курс</b> — выбери отделение:", kb.as_markup())


@router.callback_query(F.data.startswith("ed:d:"))
async def cb_dept(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, course, dept = c.data.split(":")
    dept = dept.replace("_", "")
    async with Session() as s:
        groups = list(await s.scalars(select(Group).where(Group.course == int(course), Group.dept == dept)
                                      .order_by(Group.title)))
    kb = InlineKeyboardBuilder()
    for g in groups:
        kb.button(text=(g.title or g.name)[:44], callback_data=f"ed:g:{g.id}")
    kb.button(text="⬅️ Назад", callback_data=f"ed:c:{course}")
    kb.adjust(1)
    await show(c, f"🗓 {course} курс · {DEPTS.get(dept, '')}\nВыбери программу:", kb.as_markup())


@router.callback_query(F.data.startswith("ed:g:"))
async def cb_group(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    wd = now_local().weekday()
    await day_view(c, int(c.data.split(":")[2]), wd if wd < 6 else 0)


# ───────────────────────── день программы ─────────────────────────

async def day_view(target, gid: int, wd: int):
    async with Session() as s:
        g = await s.get(Group, gid)
        lessons = await editing.day_lessons(s, gid, wd)
        n_pending = len(await editing.pending(s, gid))
    lines = [f"🗓 <b>Редактор</b> · {esc(_title(g))}", f"📅 <b>{editing.DAYS_FULL[wd]}</b>", ""]
    kb = InlineKeyboardBuilder()
    for i, l in enumerate(lessons, 1):
        mark = ("🟡" if l.deleted else "") + ("✋" if l.manual else "")
        lines.append(f"{i}. <code>{l.start:%H:%M}–{l.end:%H:%M}</code> {mark} {esc(l.subject)} · {esc(l.room) or '—'}")
        kb.row(B(text=f"{i}. {l.start:%H:%M} {l.subject[:26]}", callback_data=f"ed:l:{l.id}:0"))
    if not lessons:
        lines.append("<i>В этот день пар нет</i>")
    lines += ["", "<i>✋ — изменено вручную · 🟡 — черновик, студентам не виден</i>"]
    kb.row(*[B(text=(f"【{WEEKDAYS_SHORT[i]}】" if i == wd else WEEKDAYS_SHORT[i]), callback_data=f"ed:v:{gid}:{i}")
             for i in range(6)])
    kb.row(B(text="◀️", callback_data=f"ed:v:{gid}:{(wd - 1) % 6}"),
           B(text="➕ Добавить пару", callback_data=f"ed:add:{gid}:{wd}"),
           B(text="▶️", callback_data=f"ed:v:{gid}:{(wd + 1) % 6}"))
    if n_pending:
        kb.row(B(text=f"📣 Разослать правки студентам ({n_pending})", callback_data=f"ed:send:{gid}"))
    kb.row(B(text="↩️ Сбросить правки", callback_data=f"ed:reset:{gid}"),
           B(text="⬅️ К программам", callback_data=f"ed:c:{g.course}"))
    await show(target, "\n".join(lines), kb.as_markup())


@router.callback_query(F.data.startswith("ed:v:"))
async def cb_view(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, gid, wd = c.data.split(":")
    await set_state(c.from_user.id)
    await day_view(c, int(gid), int(wd))


@router.callback_query(F.data.startswith("ed:add:"))
async def cb_add(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, gid, wd = c.data.split(":")
    async with Session() as s:
        l = await editing.create_draft(s, int(gid), int(wd))
        await s.commit()
        lid = l.id
    await card(c, lid, 0)


# ───────────────────────── карточка пары ─────────────────────────

def _value(l: Lesson, field: str) -> str:
    return {"subject": l.subject, "teacher": l.teacher or "—", "room": l.room or "—",
            "start": f"{l.start:%H:%M}", "end": f"{l.end:%H:%M}", "day": editing.DAYS_FULL[l.weekday]}[field]


async def card(target, lid: int, cur: int = 0):
    async with Session() as s:
        l = await s.get(Lesson, lid)
        if not l:
            await show(target, "Пара не найдена.")
            return
        g = await s.get(Group, l.group_id)
        sibs = await editing.day_lessons(s, l.group_id, l.weekday, include_id=l.id)
    cur %= len(editing.FIELDS)
    ids = [x.id for x in sibs]
    idx = ids.index(l.id) if l.id in ids else 0
    status = ("🟡 <b>Черновик</b> — студентам не виден, пока не опубликуешь" if l.deleted
              else "✋ изменено вручную" if l.manual else "📄 из файла (при первой правке станет ручной)")
    lines = [f"✏️ <b>Пара {idx + 1} из {len(ids)}</b> · {esc(_title(g))}", status, ""]
    for i, f in enumerate(editing.FIELDS):
        lines.append(f"{'▶️' if i == cur else '▫️'} {editing.LABELS[f]}: <b>{esc(_value(l, f))}</b>")
    lines += ["", "<i>⬆️⬇️ — выбрать ячейку, затем меняй её. ◀️▶️ внизу — соседние пары.</i>"]

    field = editing.FIELDS[cur]
    kb = InlineKeyboardBuilder()
    kb.row(B(text="⬆️", callback_data=f"ed:l:{lid}:{(cur - 1) % 6}"),
           B(text=f"{editing.LABELS[field]}", callback_data="noop"),
           B(text="⬇️", callback_data=f"ed:l:{lid}:{(cur + 1) % 6}"))
    if field in ("subject", "teacher", "room"):
        kb.row(B(text="✏️ Изменить значение", callback_data=f"ed:t:{lid}:{cur}"))
    elif field in ("start", "end"):
        kb.row(B(text="⏪ −50", callback_data=f"ed:m:{lid}:{cur}:-50"), B(text="◀️ −10", callback_data=f"ed:m:{lid}:{cur}:-10"),
               B(text="+10 ▶️", callback_data=f"ed:m:{lid}:{cur}:10"), B(text="+50 ⏩", callback_data=f"ed:m:{lid}:{cur}:50"))
        kb.row(B(text="−5", callback_data=f"ed:m:{lid}:{cur}:-5"), B(text="+5", callback_data=f"ed:m:{lid}:{cur}:5"))
    else:
        kb.row(B(text="◀️ Раньше (день)", callback_data=f"ed:dy:{lid}:{cur}:-1"),
               B(text="Позже (день) ▶️", callback_data=f"ed:dy:{lid}:{cur}:1"))
    prev_id = ids[idx - 1] if idx > 0 else None
    next_id = ids[idx + 1] if idx + 1 < len(ids) else None
    kb.row(B(text="◀️ Пред. пара" if prev_id else "·", callback_data=f"ed:l:{prev_id}:{cur}" if prev_id else "noop"),
           B(text="След. пара ▶️" if next_id else "·", callback_data=f"ed:l:{next_id}:{cur}" if next_id else "noop"))
    row = [B(text="🗑 Удалить", callback_data=f"ed:del:{lid}")]
    if l.deleted:
        row.insert(0, B(text="✅ Опубликовать", callback_data=f"ed:pub:{lid}"))
    kb.row(*row)
    kb.row(B(text="⬅️ К дню", callback_data=f"ed:v:{l.group_id}:{l.weekday}"))
    await show(target, "\n".join(lines), kb.as_markup())


@router.callback_query(F.data == "noop")
async def cb_noop(c: CallbackQuery):
    await c.answer()


@router.callback_query(F.data.startswith("ed:l:"))
async def cb_card(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, lid, cur = c.data.split(":")
    await set_state(c.from_user.id)
    await card(c, int(lid), int(cur))


@router.callback_query(F.data.startswith("ed:t:"))
async def cb_text_prompt(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, lid, cur = c.data.split(":")
    field = editing.FIELDS[int(cur) % 6]
    await set_state(c.from_user.id, "ed_text", f"{lid}:{cur}")
    kb = InlineKeyboardBuilder()
    kb.button(text="⬅️ Отмена", callback_data=f"ed:l:{lid}:{cur}")
    hint = "\n«-» — очистить значение." if field != "subject" else ""
    await show(c, f"✏️ Напиши новое значение: <b>{editing.LABELS[field]}</b>{hint}", kb.as_markup())


@router.message(InState("ed_text"))
async def on_text(m: Message, st_data: str):
    if not access.is_admin(m.from_user.id):
        return
    lid, cur = (int(x) for x in st_data.split(":"))
    field = editing.FIELDS[cur % 6]
    async with Session() as s:
        l = await s.get(Lesson, lid)
        if l:
            await editing.set_text(s, l, field, m.text or "")
            await s.commit()
    await set_state(m.from_user.id)
    await eat(m)
    await card(m, lid, cur)


@router.callback_query(F.data.startswith("ed:m:"))
async def cb_shift_time(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, lid, cur, delta = c.data.split(":")
    which = editing.FIELDS[int(cur) % 6]
    async with Session() as s:
        l = await s.get(Lesson, int(lid))
        ok = await editing.shift_time(s, l, which, int(delta))
        await s.commit()
    if not ok:
        await c.answer("Конец должен быть позже начала", show_alert=True)
        return
    await card(c, int(lid), int(cur))


@router.callback_query(F.data.startswith("ed:dy:"))
async def cb_shift_day(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, lid, cur, delta = c.data.split(":")
    async with Session() as s:
        l = await s.get(Lesson, int(lid))
        await editing.shift_day(s, l, int(delta))
        await s.commit()
    await card(c, int(lid), int(cur))


@router.callback_query(F.data.startswith("ed:pub:"))
async def cb_publish(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    lid = int(c.data.split(":")[2])
    async with Session() as s:
        l = await s.get(Lesson, lid)
        await editing.publish(s, l)
        await s.commit()
        gid, wd = l.group_id, l.weekday
    await c.answer("Опубликовано ✅")
    await day_view(c, gid, wd)


@router.callback_query(F.data.startswith("ed:del:"))
async def cb_delete_ask(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    lid = int(c.data.split(":")[2])
    kb = InlineKeyboardBuilder()
    kb.button(text="🗑 Да, удалить пару", callback_data=f"ed:delok:{lid}")
    kb.button(text="⬅️ Нет", callback_data=f"ed:l:{lid}:0")
    kb.adjust(1)
    await show(c, "Удалить эту пару из расписания? Студентам она пропадёт (уведомление уйдёт, когда нажмёшь "
                  "«Разослать правки»).", kb.as_markup())


@router.callback_query(F.data.startswith("ed:delok:"))
async def cb_delete(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    lid = int(c.data.split(":")[2])
    async with Session() as s:
        l = await s.get(Lesson, lid)
        gid, wd = l.group_id, l.weekday
        await editing.delete_lesson(s, l)
        await s.commit()
    await day_view(c, gid, wd)


# ───────────────────────── рассылка правок / сброс ─────────────────────────

@router.callback_query(F.data.startswith("ed:send:"))
async def cb_send_preview(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    gid = int(c.data.split(":")[2])
    async with Session() as s:
        g = await s.get(Group, gid)
        chs = await editing.pending(s, gid)
    if not chs:
        await c.answer("Нет неотправленных правок", show_alert=True)
        return
    text, urgent = build_message(g.title or g.name, chs, now_local())
    kb = InlineKeyboardBuilder()
    kb.button(text="📣 Разослать студентам", callback_data=f"ed:sendok:{gid}")
    kb.button(text="🤫 Сохранить без рассылки", callback_data=f"ed:sendsil:{gid}")
    kb.button(text="⬅️ Назад", callback_data=f"ed:v:{gid}:0")
    kb.adjust(1)
    await show(c, "👀 <b>Так увидят студенты:</b>\n\n" + text, kb.as_markup())


async def _flush(c: CallbackQuery, gid: int, notify: bool):
    now = now_local()
    async with Session() as s:
        g = await s.get(Group, gid)
        chs = await editing.pending(s, gid)
        key = f"ed{gid}-{now:%y%m%d%H%M%S}"
        recipients, queued = await record_and_notify(s, {gid: (g.title or g.name, chs)}, key, now, notify=notify)
        await editing.clear_base(s, gid)
        await s.commit()
    if notify:
        await enqueue_actual(recipients, key, now)
    await c.answer(f"Разослано: {len(recipients)} получателям" if notify else "Сохранено без рассылки", show_alert=True)
    await day_view(c, gid, 0)


@router.callback_query(F.data.startswith("ed:sendok:"))
async def cb_send(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await _flush(c, int(c.data.split(":")[2]), True)


@router.callback_query(F.data.startswith("ed:sendsil:"))
async def cb_send_silent(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await _flush(c, int(c.data.split(":")[2]), False)


@router.callback_query(F.data.startswith("ed:reset:"))
async def cb_reset_ask(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    gid = int(c.data.split(":")[2])
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ Да, сбросить все правки", callback_data=f"ed:resetok:{gid}")
    kb.button(text="⬅️ Нет", callback_data=f"ed:v:{gid}:0")
    kb.adjust(1)
    await show(c, "Сбросить <b>все ручные правки</b> этой программы и вернуть расписание из файла? "
                  "Студентам уйдёт тихо, без уведомления.", kb.as_markup())


@router.callback_query(F.data.startswith("ed:resetok:"))
async def cb_reset(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    gid = int(c.data.split(":")[2])
    async with Session() as s:
        g = await s.get(Group, gid)
        course = g.course
        if not stored_path(course).exists():
            await c.answer("Нет сохранённой копии файла этого курса — сначала загрузите таблицу (иначе пары не восстановить).",
                           show_alert=True)
            return
        await editing.reset_group(s, gid)
        await s.commit()
    res = await reapply_stored(course, bot)
    await c.answer(res.splitlines()[0][:180], show_alert=True)
    await day_view(c, gid, 0)
