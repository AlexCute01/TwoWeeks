"""Общее для обработчиков: пользователь, ответ/редактирование, фильтр состояний, разбор времени."""
import re
from datetime import time

from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Filter
from aiogram.types import CallbackQuery, Message

from .db import Session, User
from .ui import MENU_TEXTS
from .util import now_local


async def get_user(s, tg_user) -> User:
    """Находит/создаёт пользователя, обновляет @username и имя, снимает флаг «заблокировал бота»."""
    u = await s.get(User, tg_user.id)
    changed = False
    if not u:
        u = User(tg_id=tg_user.id, created_at=now_local())
        s.add(u)
        changed = True
    uname, name = (tg_user.username or ""), (tg_user.full_name or "")[:200]
    if u.username != uname:
        u.username, changed = uname, True
    if u.full_name != name:
        u.full_name, changed = name, True
    if u.blocked:
        u.blocked, changed = False, True
    if changed:
        await s.commit()
    return u


async def set_state(tg_id: int, state: str = "", data: str = "") -> None:
    async with Session() as s:
        u = await s.get(User, tg_id)
        if u:
            u.state, u.state_data = state, data
            await s.commit()


async def reply(target, text: str, kb=None) -> None:
    """Message -> новое сообщение; CallbackQuery -> правим текущее (экраны «перелистываются» на месте)."""
    if isinstance(target, CallbackQuery):
        try:
            await target.message.edit_text(text, reply_markup=kb)
        except TelegramBadRequest:
            pass                                     # «message is not modified»
        await target.answer()
    else:
        await target.answer(text, reply_markup=kb)


class InState(Filter):
    """Срабатывает, если пользователь сейчас «вводит» что-то (состояние хранится в БД — переживает перезапуск).
    Команды и кнопки меню состояние не перехватывают."""

    def __init__(self, *states: str):
        self.states = set(states)

    async def __call__(self, message: Message):
        if message.text and (message.text.startswith("/") or message.text in MENU_TEXTS):
            return False
        async with Session() as s:
            u = await s.get(User, message.from_user.id)
        if u and u.state in self.states:
            return {"st": u.state, "st_data": u.state_data}
        return False


def parse_hhmm(text: str) -> time | None:
    m = re.fullmatch(r"\s*(\d{1,2})\s*[:.\-]?\s*(\d{2})\s*", text or "")
    if not m or int(m[1]) > 23 or int(m[2]) > 59:
        return None
    return time(int(m[1]), int(m[2]))
