"""Общее для обработчиков: пользователь, «экраны» без засорения чата, фильтр состояний, разбор времени."""
import asyncio
import logging
import re
from datetime import time, timedelta

from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Filter
from aiogram.types import CallbackQuery, Message

from .db import Session, User
from .ui import MENU_TEXTS
from .util import now_local

log = logging.getLogger(__name__)
_bg: set[asyncio.Task] = set()


async def get_user(s, tg_user) -> User:
    """Находит/создаёт пользователя, обновляет @username, имя и «был в сети», снимает флаг «заблокировал бота»."""
    u = await s.get(User, tg_user.id)
    changed = False
    now = now_local()
    if not u:
        u = User(tg_id=tg_user.id, created_at=now)
        s.add(u)
        changed = True
    uname, name = (tg_user.username or ""), (tg_user.full_name or "")[:200]
    if u.username != uname:
        u.username, changed = uname, True
    if u.full_name != name:
        u.full_name, changed = name, True
    if u.blocked:
        u.blocked, changed = False, True
    if not u.last_seen or now - u.last_seen > timedelta(minutes=5):
        u.last_seen, changed = now, True
    if changed:
        await s.commit()
    return u


async def set_state(tg_id: int, state: str = "", data: str = "") -> None:
    async with Session() as s:
        u = await s.get(User, tg_id)
        if u:
            u.state, u.state_data = state, data
            await s.commit()


# ───────────────────── «экраны»: одно сообщение вместо потока ─────────────────────

async def _safe_delete(bot, chat_id: int, message_id: int) -> None:
    try:
        await bot.delete_message(chat_id, message_id)
    except Exception:
        pass


async def _screen(uid: int, new_id: int | None = None) -> int:
    async with Session() as s:
        u = await s.get(User, uid)
        if not u:
            return 0
        old = u.screen_id or 0
        if new_id is not None and new_id != old:
            u.screen_id = new_id
            await s.commit()
        return old


async def show(target, text: str, kb=None, *, user=None, delete_src: bool = True) -> None:
    """Показывает экран.
    • из кнопки (CallbackQuery) — правим это же сообщение на месте;
    • из команды/кнопки меню (Message) — удаляем сообщение пользователя и прошлый экран и шлём новый внизу чата.
    Так в чате остаётся ОДИН экран, а не вереница ответов."""
    if isinstance(target, CallbackQuery):
        msg = target.message
        try:
            await msg.edit_text(text, reply_markup=kb)
            await _screen(target.from_user.id, msg.message_id)
        except TelegramBadRequest as e:
            if "not modified" not in str(e).lower():          # нельзя править (например, это фото) — шлём новое
                sent = await msg.answer(text, reply_markup=kb)
                await _safe_delete(msg.bot, msg.chat.id, msg.message_id)
                await _screen(target.from_user.id, sent.message_id)
        await target.answer()
        return
    uid = (user or target.from_user).id
    bot, chat = target.bot, target.chat.id
    if delete_src:
        await _safe_delete(bot, chat, target.message_id)
    old = await _screen(uid)
    sent = await bot.send_message(chat, text, reply_markup=kb)
    await _screen(uid, sent.message_id)
    if old and old != sent.message_id:
        await _safe_delete(bot, chat, old)


async def show_photo(target, photo_id: str, caption: str, kb=None, *, user=None, delete_src: bool = True) -> None:
    uid = (user or target.from_user).id
    msg = target.message if isinstance(target, CallbackQuery) else target
    bot, chat = msg.bot, msg.chat.id
    if isinstance(target, CallbackQuery):
        await target.answer()
        await _safe_delete(bot, chat, msg.message_id)
    elif delete_src:
        await _safe_delete(bot, chat, target.message_id)
    old = await _screen(uid)
    sent = await bot.send_photo(chat, photo_id, caption=caption, reply_markup=kb)
    await _screen(uid, sent.message_id)
    if old and old != sent.message_id and old != getattr(msg, "message_id", 0):
        await _safe_delete(bot, chat, old)


async def ephemeral(m: Message, text: str, seconds: int = 7, kb=None) -> None:
    """Короткая подсказка, которая сама исчезает (и не засоряет чат)."""
    sent = await m.answer(text, reply_markup=kb)

    async def _later():
        await asyncio.sleep(seconds)
        await _safe_delete(m.bot, m.chat.id, sent.message_id)
    t = asyncio.create_task(_later())
    _bg.add(t)
    t.add_done_callback(_bg.discard)


async def eat(m: Message) -> None:
    """Удалить сообщение пользователя (введённый текст/кнопку), чтобы не копились в чате."""
    await _safe_delete(m.bot, m.chat.id, m.message_id)


class InState(Filter):
    """Срабатывает, если пользователь сейчас «вводит» что-то (состояние хранится в БД — переживает перезапуск).
    Команды и кнопки меню состояние не перехватывают."""

    def __init__(self, *states: str):
        self.states = set(states)

    async def __call__(self, message: Message):
        if message.text and (message.text.startswith("/") or message.text in MENU_TEXTS):
            return False
        async with Session() as s:
            u = await s.get(User, message.from_user.id)
        if u and any(u.state == st or u.state.startswith(st + ":") for st in self.states):
            return {"st": u.state, "st_data": u.state_data}
        return False


def parse_hhmm(text: str) -> time | None:
    m = re.fullmatch(r"\s*(\d{1,2})\s*[:.\-]?\s*(\d{2})\s*", text or "")
    if not m or int(m[1]) > 23 or int(m[2]) > 59:
        return None
    return time(int(m[1]), int(m[2]))
