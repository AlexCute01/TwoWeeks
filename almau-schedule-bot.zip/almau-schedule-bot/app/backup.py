"""Бэкапы SQLite: консистентная копия (sqlite3 backup API) + gzip + ротация. Работает и при запущенном боте."""
import asyncio
import gzip
import logging
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from .config import settings
from .util import now_local

log = logging.getLogger(__name__)


def db_file() -> Path | None:
    url = settings.database_url
    prefix = "sqlite+aiosqlite:///"
    return Path(url[len(prefix):]) if url.startswith(prefix) else None


def backups_dir() -> Path:
    d = Path(settings.data_dir) / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def make_backup(tag: str = "daily") -> Path | None:
    """Синхронная функция (вызывать через asyncio.to_thread). Возвращает путь к .db.gz."""
    src = db_file()
    if not src or not src.exists() or src.stat().st_size == 0:
        return None
    ts = now_local().strftime("%Y%m%d-%H%M%S")
    raw = backups_dir() / f"{tag}-{ts}.db"
    a, b = sqlite3.connect(src), sqlite3.connect(raw)
    try:
        a.backup(b)
    finally:
        b.close()
        a.close()
    gz = raw.with_suffix(".db.gz")
    with open(raw, "rb") as f_in, gzip.open(gz, "wb", compresslevel=6) as f_out:
        shutil.copyfileobj(f_in, f_out)
    raw.unlink()
    _prune()
    log.info("backup created: %s (%s KB)", gz.name, gz.stat().st_size // 1024)
    return gz


def _prune() -> None:
    now = datetime.now().timestamp()
    files = sorted(backups_dir().glob("*.db.gz"), key=lambda p: p.stat().st_mtime, reverse=True)
    keep_s = settings.backup_keep_days * 86400
    pre = [p for p in files if p.name.startswith("pre-")]
    for p in files:
        if p.name.startswith("pre-"):
            if p in pre[15:]:             # «страховочных» копий перед обновлением храним 15 последних
                p.unlink(missing_ok=True)
        elif now - p.stat().st_mtime > keep_s:
            p.unlink(missing_ok=True)


async def send_backup(bot, to_ids, caption: str = "💾 Резервная копия базы") -> int:
    """Делает бэкап и отправляет файл админам в Telegram (внешняя копия на случай потери сервера)."""
    from aiogram.types import BufferedInputFile
    path = await asyncio.to_thread(make_backup, "daily")
    if not path:
        return 0
    data = path.read_bytes()
    if len(data) > 49 * 1024 * 1024:
        log.warning("backup too large for Telegram: %s MB", len(data) // 1048576)
        return 0
    sent = 0
    for uid in to_ids:
        try:
            await bot.send_document(uid, BufferedInputFile(data, filename=path.name),
                                    caption=f"{caption}\n{path.name} · {len(data) // 1024} КБ")
            sent += 1
        except Exception as e:
            log.warning("send backup to %s failed: %s", uid, e)
    return sent
