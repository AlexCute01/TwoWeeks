import io
import re
from datetime import date, datetime, time, timedelta

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import delete, func, select

from .config import settings
from .db import (ChangeLog, Group, HiddenSubject, Lesson, Outbox, PersonalLesson, Room, Session, User,
                 meta_get)
from .parser import DAYS, detect_parity
from .schedule import (WEEKDAYS_SHORT, date_label, day_items, esc, format_day, format_week,
                       next_item, norm_room, now_local, room_card, rooms_map, room_line)
from .sync import import_xlsx, poll_once

router = Router()

HELP = """<b>Команды</b>
/today — пары на сегодня
/tomorrow — на завтра
/week — вся неделя
/next — ближайшая пара
/changes — что менялось в расписании за последние 2 недели
/room 305 — где находится аудитория

<b>Моё расписание</b>
/group — сменить группу
/sub 1 — моя подгруппа (/sub 0 — сбросить)
/add пн 15:00-16:30 Английский, 210 — добавить своё событие
/my — мои события и скрытые предметы
/hide физкультура — скрыть предмет из моего расписания
/unhide физкультура — вернуть

<b>Уведомления</b>
Если расписание твоей группы изменится — я напишу сам 🔔
/settings — время напоминаний, сводки
/morning 07:30 · /evening 21:00 — время сводок"""


async def get_user(s, tg_id: int) -> User:
    u = await s.get(User, tg_id)
    if not u:
        u = User(tg_id=tg_id)
        s.add(u)
        await s.commit()
    elif u.blocked:          # снова написал боту — значит, разблокировал
        u.blocked = False
        await s.commit()
    return u


def parse_hhmm(text: str) -> time | None:
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*", text or "")
    if not m or int(m[1]) > 23 or int(m[2]) > 59:
        return None
    return time(int(m[1]), int(m[2]))


# ---------- старт / группа ----------

@router.message(CommandStart())
async def cmd_start(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if u.group_id:
            await m.answer("С возвращением! /today — пары на сегодня, /help — все команды.")
            return
        u.state = "group"
        await s.commit()
    await m.answer("Привет! Я бот расписания 📚 Напомню о парах и сразу напишу, если расписание изменится.\n\nНапиши название своей группы — так, как оно указано в расписании.")


@router.message(Command("help"))
async def cmd_help(m: Message):
    await m.answer(HELP)


@router.message(Command("group"))
async def cmd_group(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        u.state = "group"
        await s.commit()
    await m.answer("Напиши название группы:")


async def find_group(m: Message, s, u: User, query: str):
    q = query.strip().casefold()
    groups = list(await s.scalars(select(Group).order_by(Group.name)))
    if not groups:
        await m.answer("База расписания пока пуста. Загляни чуть позже 🙏")
        return
    hits = [g for g in groups if g.name.casefold() == q] or [g for g in groups if q in g.name.casefold()]
    if len(hits) == 1:
        await apply_group(m, s, u, hits[0])
    elif 1 < len(hits) <= 20:
        kb = InlineKeyboardBuilder()
        for g in hits:
            kb.button(text=g.name, callback_data=f"g:{g.id}")
        kb.adjust(2)
        await m.answer("Нашёл несколько — выбери:", reply_markup=kb.as_markup())
    else:
        sample = ", ".join(g.name for g in groups[:15])
        await m.answer(f"Не нашёл такую группу 🤔 Примеры из базы: {esc(sample)}")


async def apply_group(m: Message, s, u: User, g: Group):
    u.group_id, u.state, u.subgroup = g.id, "", ""
    await s.commit()
    await m.answer(
        f"Готово! Группа <b>{esc(g.name)}</b> ✅\n"
        f"Напоминаю о парах за {u.remind_before} мин и сообщу, если расписание изменится. "
        "Настроить — /settings, расписание — /today.")


@router.callback_query(F.data.startswith("g:"))
async def cb_group(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user.id)
        g = await s.get(Group, int(c.data[2:]))
        if g:
            await apply_group(c.message, s, u, g)
    await c.answer()


# ---------- показ расписания ----------

async def render_day(s, u: User, d: date):
    items = await day_items(s, u, d)
    text = format_day(items, d, await rooms_map(s))
    today = now_local().date()
    kb = InlineKeyboardBuilder()
    kb.button(text="◀️", callback_data=f"d:{d - timedelta(days=1)}")
    kb.button(text="Сегодня", callback_data=f"d:{today}")
    kb.button(text="▶️", callback_data=f"d:{d + timedelta(days=1)}")
    kb.button(text="🗓 Неделя", callback_data=f"w:{d - timedelta(days=d.weekday())}")
    kb.adjust(3, 1)
    return text, kb.as_markup()


async def render_week(s, u: User, monday: date):
    text = await format_week(s, u, monday, await rooms_map(s))
    kb = InlineKeyboardBuilder()
    for i in range(6):
        kb.button(text=WEEKDAYS_SHORT[i], callback_data=f"d:{monday + timedelta(days=i)}")
    kb.button(text="◀️ Пред. неделя", callback_data=f"w:{monday - timedelta(days=7)}")
    kb.button(text="След. неделя ▶️", callback_data=f"w:{monday + timedelta(days=7)}")
    kb.adjust(6, 2)
    return text, kb.as_markup()


async def _ensure_group(m: Message, s, u: User) -> bool:
    if u.group_id:
        return True
    u.state = "group"
    await s.commit()
    await m.answer("Сначала выбери группу — напиши её название:")
    return False


@router.message(Command("today"))
async def cmd_today(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if not await _ensure_group(m, s, u):
            return
        text, kb = await render_day(s, u, now_local().date())
    await m.answer(text, reply_markup=kb)


@router.message(Command("tomorrow"))
async def cmd_tomorrow(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if not await _ensure_group(m, s, u):
            return
        text, kb = await render_day(s, u, now_local().date() + timedelta(days=1))
    await m.answer(text, reply_markup=kb)


@router.message(Command("week"))
async def cmd_week(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if not await _ensure_group(m, s, u):
            return
        d = now_local().date()
        monday = d - timedelta(days=d.weekday())
        if d.weekday() == 6:  # в воскресенье показываем следующую неделю
            monday += timedelta(days=7)
        text, kb = await render_week(s, u, monday)
    await m.answer(text, reply_markup=kb)


async def _edit(c: CallbackQuery, text: str, kb):
    try:
        await c.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass  # "message is not modified"
    await c.answer()


@router.callback_query(F.data.startswith("d:"))
async def cb_day(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user.id)
        text, kb = await render_day(s, u, date.fromisoformat(c.data[2:]))
    await _edit(c, text, kb)


@router.callback_query(F.data.startswith("w:"))
async def cb_week(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user.id)
        text, kb = await render_week(s, u, date.fromisoformat(c.data[2:]))
    await _edit(c, text, kb)


@router.message(Command("next"))
async def cmd_next(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if not await _ensure_group(m, s, u):
            return
        now = now_local()
        res = await next_item(s, u, now)
        rooms = await rooms_map(s)
    if not res:
        await m.answer("В ближайшую неделю пар не нашёл 🎉")
        return
    d, it = res
    left = datetime.combine(d, it.start) - now
    mins = int(left.total_seconds() // 60)
    when = f"через {mins // 60} ч {mins % 60} мин" if mins >= 60 else f"через {mins} мин"
    lines = [f"➡️ <b>{esc(it.title)}</b>", f"🕘 {date_label(d)}, {it.start:%H:%M}–{it.end:%H:%M} ({when})"]
    if it.room:
        lines.append(f"📍 {room_line(it.room, rooms)}")
    if it.teacher:
        lines.append(f"👤 {esc(it.teacher)}")
    await m.answer("\n".join(lines))


@router.message(Command("room"))
async def cmd_room(m: Message, command: CommandObject):
    if not command.args:
        await m.answer("Напиши номер: <code>/room 305</code>")
        return
    async with Session() as s:
        rooms = await rooms_map(s)
    await m.answer(room_card(command.args.strip(), rooms))


# ---------- индивидуальное расписание ----------

@router.message(Command("sub"))
async def cmd_sub(m: Message, command: CommandObject):
    arg = (command.args or "").strip()
    if not arg:
        await m.answer("Укажи номер подгруппы: <code>/sub 1</code> (или <code>/sub 0</code> — сбросить)")
        return
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        u.subgroup = "" if arg == "0" else arg[:8]
        await s.commit()
    await m.answer("Подгруппа сброшена — показываю все пары." if arg == "0" else f"Подгруппа: {esc(arg)} ✅")


ADD_RE = re.compile(
    r"^(\S+)\s+(\d{1,2}:\d{2})\s*[-–—]\s*(\d{1,2}:\d{2})\s+(.+?)(?:,\s*(?:ауд\w*\.?\s*)?(\S+))?$", re.I)


@router.message(Command("add"))
async def cmd_add(m: Message, command: CommandObject):
    fmt = "Формат: <code>/add пн 15:00-16:30 Английский, 210</code>\n(можно добавить «чётная»/«нечётная» в название)"
    mt = ADD_RE.match((command.args or "").strip())
    if not mt:
        await m.answer(fmt)
        return
    day = DAYS.get(mt[1].lower())
    t1, t2 = parse_hhmm(mt[2]), parse_hhmm(mt[3])
    if day is None or not t1 or not t2 or t2 <= t1:
        await m.answer(fmt)
        return
    title, room = mt[4].strip(), (mt[5] or "")
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        s.add(PersonalLesson(user_id=u.tg_id, weekday=day, start=t1, end=t2, title=title[:200],
                             room=room[:50], parity=detect_parity(title)))
        await s.commit()
    await m.answer(f"Добавил ⭐ <b>{esc(title)}</b> — {WEEKDAYS_SHORT[day]} {t1:%H:%M}–{t2:%H:%M}. Список — /my")


@router.message(Command("my"))
async def cmd_my(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        mine = list(await s.scalars(select(PersonalLesson).where(PersonalLesson.user_id == u.tg_id)
                                    .order_by(PersonalLesson.weekday, PersonalLesson.start)))
        hidden = list(await s.scalars(select(HiddenSubject.subject).where(HiddenSubject.user_id == u.tg_id)))
    lines = ["<b>Мои события</b>"]
    kb = InlineKeyboardBuilder()
    for p in mine:
        lines.append(f"⭐ {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M}–{p.end:%H:%M} · {esc(p.title)}"
                     + (f" · {esc(p.room)}" if p.room else ""))
        kb.button(text=f"🗑 {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M} {p.title[:18]}", callback_data=f"del:{p.id}")
    if not mine:
        lines.append("пока пусто — добавь через /add")
    lines.append("\n<b>Скрытые предметы</b>")
    lines.append(", ".join(esc(h) for h in hidden) if hidden else "нет (скрыть — /hide название)")
    kb.adjust(1)
    await m.answer("\n".join(lines), reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("del:"))
async def cb_del(c: CallbackQuery):
    async with Session() as s:
        await s.execute(delete(PersonalLesson).where(
            PersonalLesson.id == int(c.data[4:]), PersonalLesson.user_id == c.from_user.id))
        await s.commit()
    await c.answer("Удалено")
    await c.message.answer("Удалил. Обновлённый список — /my")


@router.message(Command("hide"))
async def cmd_hide(m: Message, command: CommandObject):
    name = (command.args or "").strip()
    if not name:
        await m.answer("Напиши часть названия: <code>/hide физкультура</code>")
        return
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        s.add(HiddenSubject(user_id=u.tg_id, subject=name[:200]))
        await s.commit()
    await m.answer(f"Скрыл всё, где в названии «{esc(name)}» 🙈 Вернуть — /unhide {esc(name)}")


@router.message(Command("unhide"))
async def cmd_unhide(m: Message, command: CommandObject):
    name = (command.args or "").strip()
    async with Session() as s:
        await s.execute(delete(HiddenSubject).where(
            HiddenSubject.user_id == m.from_user.id, HiddenSubject.subject.ilike(name)))
        await s.commit()
    await m.answer("Готово ✅")


@router.message(Command("changes"))
async def cmd_changes(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if not await _ensure_group(m, s, u):
            return
        since = now_local() - timedelta(days=14)
        rows = list(await s.scalars(select(ChangeLog).where(
            ChangeLog.group_id == u.group_id, ChangeLog.created_at >= since)
            .order_by(ChangeLog.id.desc()).limit(12)))
    if not rows:
        await m.answer("За последние 2 недели расписание твоей группы не менялось ✅")
        return
    parts = [f"<i>{r.created_at:%d.%m %H:%M}</i>\n{r.text}" for r in rows]
    await m.answer("🕓 <b>Последние изменения</b>\n\n" + "\n\n".join(parts))


# ---------- настройки уведомлений ----------

def settings_view(u: User):
    text = (
        "⚙️ <b>Уведомления</b>\n\n"
        f"🔔 Напоминания о парах: {'вкл' if u.notify_enabled else 'выкл'} (за {u.remind_before} мин; "
        "перед первой парой дня — раньше)\n"
        f"☀️ Утренняя сводка: {'вкл, ' + format(u.morning_time, '%H:%M') if u.morning_on else 'выкл'}\n"
        f"🌙 Вечерняя сводка на завтра: {'вкл, ' + format(u.evening_time, '%H:%M') if u.evening_on else 'выкл'}\n"
        f"🔄 Об изменениях в расписании: {'вкл' if u.changes_on else '⚠️ выкл — рекомендую включить'}\n\n"
        "Время сводок: /morning 07:30 и /evening 21:00")
    kb = InlineKeyboardBuilder()
    for n in (5, 10, 15, 30):
        kb.button(text=("✅ " if u.remind_before == n else "") + f"{n} мин", callback_data=f"set:rb:{n}")
    kb.button(text=f"{'🔔' if u.notify_enabled else '🔕'} Напоминания", callback_data="set:on")
    kb.button(text=f"{'✅' if u.morning_on else '⬜'} Утро", callback_data="set:am")
    kb.button(text=f"{'✅' if u.evening_on else '⬜'} Вечер", callback_data="set:ev")
    kb.button(text=f"{'✅' if u.changes_on else '⬜'} Изменения", callback_data="set:ch")
    kb.adjust(4, 1, 3)
    return text, kb.as_markup()


@router.message(Command("settings"))
async def cmd_settings(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        text, kb = settings_view(u)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("set:"))
async def cb_settings(c: CallbackQuery):
    parts = c.data.split(":")
    async with Session() as s:
        u = await get_user(s, c.from_user.id)
        if parts[1] == "rb":
            u.remind_before = int(parts[2])
        elif parts[1] == "on":
            u.notify_enabled = not u.notify_enabled
        elif parts[1] == "am":
            u.morning_on = not u.morning_on
        elif parts[1] == "ev":
            u.evening_on = not u.evening_on
        elif parts[1] == "ch":
            u.changes_on = not u.changes_on
        await s.commit()
        text, kb = settings_view(u)
    await _edit(c, text, kb)


async def _set_digest_time(m: Message, command: CommandObject, field: str, label: str):
    t = parse_hhmm(command.args or "")
    if not t:
        await m.answer(f"Укажи время: <code>/{label} 07:30</code>")
        return
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        setattr(u, f"{field}_time", t)
        setattr(u, f"{field}_on", True)
        await s.commit()
    await m.answer(f"Ок, сводка будет приходить в {t:%H:%M} ✅")


@router.message(Command("morning"))
async def cmd_morning(m: Message, command: CommandObject):
    await _set_digest_time(m, command, "morning", "morning")


@router.message(Command("evening"))
async def cmd_evening(m: Message, command: CommandObject):
    await _set_digest_time(m, command, "evening", "evening")


# ---------- админ ----------

def is_admin(m: Message) -> bool:
    return m.from_user.id in settings.admins


@router.message(Command("sync"))
async def cmd_sync(m: Message, bot: Bot):
    if not is_admin(m):
        return
    try:
        res = await poll_once(bot, force=True)
    except Exception as e:
        res = f"❌ {esc(str(e))}"
    await m.answer(esc(res))


@router.message(Command("stats"))
async def cmd_stats(m: Message):
    if not is_admin(m):
        return
    async with Session() as s:
        users = await s.scalar(select(func.count()).select_from(User))
        with_group = await s.scalar(select(func.count()).select_from(User).where(User.group_id.is_not(None)))
        blocked = await s.scalar(select(func.count()).select_from(User).where(User.blocked.is_(True)))
        groups = await s.scalar(select(func.count()).select_from(Group))
        lessons = await s.scalar(select(func.count()).select_from(Lesson))
        pending = await s.scalar(select(func.count()).select_from(Outbox).where(Outbox.status == 0))
        applied = await meta_get(s, "applied_at")
        fails = await meta_get(s, "fail_count")
    await m.answer(
        f"👥 Пользователей: {users} (с группой: {with_group}, заблокировали бота: {blocked})\n"
        f"📚 Групп: {groups}, пар: {lessons}\n"
        f"📨 В очереди на отправку: {pending}\n"
        f"🔄 Расписание применено: {applied or '—'}\n"
        f"⚠️ Подряд неудачных синхронизаций: {fails or 0}")


@router.message(F.document)
async def on_document(m: Message, bot: Bot):
    if not is_admin(m):
        return
    if not (m.document.file_name or "").lower().endswith((".xlsx", ".xlsm")):
        await m.answer("Нужен файл .xlsx")
        return
    buf = io.BytesIO()
    await bot.download(m.document, destination=buf)
    try:
        res = await import_xlsx(buf.getvalue(), bot, force=True)
    except Exception as e:
        res = f"❌ {esc(str(e))}"
    await m.answer(res)


@router.message(Command("setroom"))
async def cmd_setroom(m: Message, command: CommandObject):
    """/setroom 305 | Главный корпус | 3 | Лифт слева, налево от буфета"""
    if not is_admin(m):
        return
    parts = [p.strip() for p in (command.args or "").split("|")]
    if len(parts) < 2 or not parts[0]:
        await m.answer("Формат: <code>/setroom 305 | Главный корпус | 3 | описание</code>")
        return
    floor = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None
    async with Session() as s:
        code = norm_room(parts[0])
        r = await s.get(Room, code) or Room(code=code)
        r.building, r.floor = parts[1], floor
        r.description = parts[3] if len(parts) > 3 else r.description or ""
        s.add(r)
        await s.commit()
    await m.answer("Сохранил ✅")


# ---------- текст (должен быть последним) ----------

@router.message(F.text & ~F.text.startswith("/"))
async def on_text(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user.id)
        if u.state == "group" or not u.group_id:
            await find_group(m, s, u, m.text)
        else:
            await m.answer("Не понял 🤔 Список команд — /help")
