"""Обработчики для студентов: меню, расписание, выбор группы, настройки, новости, личные события."""
import re
from datetime import date, datetime, timedelta

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import delete, func, select

from . import access
from .cache import cache
from .common import InState, get_user, parse_hhmm, reply, set_state
from .config import EVENING_PRESETS, FIRST_EXTRA_OPTIONS, MORNING_PRESETS, REMIND_OPTIONS
from .db import ChangeLog, Group, HiddenSubject, PersonalLesson, Post, Session, User
from .fmt import fmt_dur, room_card, room_line
from .parser import DAYS, detect_parity
from .programs import DEPTS, norm
from .schedule import (next_item, render_day_text, render_week_text, rooms_map, week_monday)
from .ui import (BTN_NEWS, BTN_NEXT, BTN_SETTINGS, BTN_TODAY, BTN_TOMORROW, BTN_WEEK, back_kb, day_kb,
                 main_menu, week_kb)
from .util import WEEKDAYS_SHORT, esc, now_local

router = Router()

HELP = """<b>📖 Как пользоваться</b>

Внизу — кнопки: расписание на сегодня, завтра, неделю, ближайшая пара, новости и настройки.

<b>Команды</b>
/today /tomorrow /week /next — расписание
/changes — что менялось за последние 2 недели
/room 305 — как найти аудиторию
/group — сменить группу
/settings — уведомления и время сводок
/my — свои события и скрытые предметы
/news — лента новостей
/cancel — отменить ввод

<b>Свои события:</b> /add пн 15:00-16:30 Английский, 210
<b>Скрыть предмет:</b> /hide физкультура"""

WELCOME = ("👋 <b>Привет! Я бот расписания.</b>\n\n"
           "• напомню о паре заранее, скажу когда она закончилась и что дальше;\n"
           "• <b>сразу напишу, если расписание изменится</b>;\n"
           "• присылаю новости университета.\n\n"
           "Для начала выбери своё отделение 👇")


# ───────────────────────── выбор группы ─────────────────────────

async def show_depts(target, change: bool = False):
    async with Session() as s:
        rows = await s.execute(select(Group.dept, func.count()).group_by(Group.dept))
        counts = {d or "": n for d, n in rows}
    if not counts:
        await reply(target, "База расписания пока пуста. Загляни чуть позже 🙏")
        return
    kb = InlineKeyboardBuilder()
    for key, label in DEPTS.items():
        if counts.get(key):
            kb.button(text=f"{label} · {counts[key]}", callback_data=f"gd:{key or '_'}")
    kb.button(text="🔎 Найти по названию", callback_data="gs")
    kb.adjust(1)
    head = "🔄 <b>Смена группы</b>\n\n" if change else ""
    await reply(target, head + "Выбери своё <b>отделение</b>:", kb.as_markup())


@router.callback_query(F.data.startswith("gd:"))
async def cb_dept(c: CallbackQuery):
    dept = c.data[3:].replace("_", "")
    async with Session() as s:
        groups = list(await s.scalars(select(Group).where(Group.dept == dept).order_by(Group.title)))
    kb = InlineKeyboardBuilder()
    for g in groups:
        kb.button(text=(g.title or g.name)[:40], callback_data=f"gp:{g.id}")
    kb.button(text="⬅️ К отделениям", callback_data="gb")
    kb.adjust(1) if any(len(g.title or g.name) > 22 for g in groups) else kb.adjust(2)
    await reply(c, f"{DEPTS.get(dept, '📂')}\n\nВыбери свою <b>программу</b>:", kb.as_markup())


@router.callback_query(F.data == "gb")
async def cb_dept_back(c: CallbackQuery):
    await show_depts(c)


@router.callback_query(F.data == "gs")
async def cb_group_search(c: CallbackQuery):
    await set_state(c.from_user.id, "group_search")
    await reply(c, "🔎 Напиши часть названия — например: <i>юр</i>, <i>маркетинг</i>, <i>fintech</i>, <i>учёт</i>.",
                back_kb("gb", "⬅️ К отделениям"))


@router.callback_query(F.data.startswith("gp:"))
async def cb_pick_group(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user)
        g = await s.get(Group, int(c.data[3:]))
        if not g:
            await c.answer("Не нашёл такую группу", show_alert=True)
            return
        first_time = u.group_id is None
        u.group_id, u.state, u.state_data, u.subgroup = g.id, "", "", ""
        await s.commit()
    await reply(c, f"✅ Группа выбрана: <b>{esc(g.title or g.name)}</b>")
    await c.message.answer(
        ("🎉 <b>Готово!</b> " if first_time else "") +
        "Кнопки внизу — расписание и настройки. Напоминания включены, а если расписание изменится — "
        "я напишу сам.\n\nНастроить время напоминаний и сводок: ⚙️ Настройки.",
        reply_markup=main_menu(access.is_admin(c.from_user.id)))
    await show_day(c.message, user=c.from_user)


async def find_group(m: Message, query: str):
    q = norm(query)
    if len(q) < 2:
        await m.answer("Напиши хотя бы 2 буквы 🙂")
        return
    async with Session() as s:
        groups = list(await s.scalars(select(Group).order_by(Group.title)))
    hits = [g for g in groups if q in norm(g.title) or q in norm(g.name) or q in norm(g.codes)]
    if not hits:
        await m.answer("Ничего не нашёл 🤔 Попробуй другое слово или выбери из списка: /group")
        return
    kb = InlineKeyboardBuilder()
    for g in hits[:12]:
        kb.button(text=(g.title or g.name)[:40], callback_data=f"gp:{g.id}")
    kb.button(text="⬅️ К отделениям", callback_data="gb")
    kb.adjust(1)
    await m.answer(f"Нашёл: {len(hits)}. Выбери свою:" + (" (показаны первые 12)" if len(hits) > 12 else ""),
                   reply_markup=kb.as_markup())


# ───────────────────────── старт / меню ─────────────────────────

@router.message(CommandStart())
async def cmd_start(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user)
        has_group = bool(u.group_id)
        u.state, u.state_data = "", ""
        await s.commit()
    kb = main_menu(access.is_admin(m.from_user.id))
    if has_group:
        await m.answer("👋 С возвращением! Расписание ниже, кнопки — внизу.", reply_markup=kb)
        await show_day(m)
    else:
        await m.answer(WELCOME, reply_markup=kb)
        await show_depts(m)


@router.message(Command("help"))
async def cmd_help(m: Message):
    await m.answer(HELP)


@router.message(Command("cancel"))
async def cmd_cancel(m: Message):
    await set_state(m.from_user.id)
    await m.answer("Ок, отменил 👌", reply_markup=main_menu(access.is_admin(m.from_user.id)))


@router.message(Command("group"))
async def cmd_group(m: Message):
    await set_state(m.from_user.id)
    await show_depts(m, change=True)


# ───────────────────────── расписание ─────────────────────────

async def _need_group(target, s, u: User) -> bool:
    if u.group_id:
        return False
    await show_depts(target)
    return True


async def show_day(target, d: date | None = None, user=None):
    tg_user = user or target.from_user
    async with Session() as s:
        u = await get_user(s, tg_user)
        if await _need_group(target, s, u):
            return
        now = now_local()
        d = d or now.date()
        text = await render_day_text(s, u, d, None, now)
    await reply(target, text, day_kb(d, now.date()))


async def show_week(target, monday: date | None = None):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        if await _need_group(target, s, u):
            return
        now = now_local()
        monday = monday or week_monday(now.date())
        text = await render_week_text(s, u, monday)
    await reply(target, text, week_kb(monday, now.date()))


@router.message(Command("today"))
@router.message(F.text == BTN_TODAY)
async def m_today(m: Message):
    await set_state(m.from_user.id)
    await show_day(m)


@router.message(Command("tomorrow"))
@router.message(F.text == BTN_TOMORROW)
async def m_tomorrow(m: Message):
    await set_state(m.from_user.id)
    await show_day(m, now_local().date() + timedelta(days=1))


@router.message(Command("week"))
@router.message(F.text == BTN_WEEK)
async def m_week(m: Message):
    await set_state(m.from_user.id)
    await show_week(m)


@router.callback_query(F.data.startswith("d:"))
async def cb_day(c: CallbackQuery):
    await show_day(c, date.fromisoformat(c.data[2:]))


@router.callback_query(F.data.startswith("w:"))
async def cb_week(c: CallbackQuery):
    await show_week(c, date.fromisoformat(c.data[2:]))


async def _next_text(s, u: User) -> str:
    now = now_local()
    res = await next_item(s, u, now)
    if not res:
        return "На ближайшую неделю пар не нашёл 🎉"
    d, it = res
    left = int((datetime.combine(d, it.start) - now).total_seconds() // 60)
    rooms = await rooms_map(s)
    lines = [f"⏭ <b>Ближайшая пара</b> — через {fmt_dur(left)}", "",
             f"📚 <b>{esc(it.title)}</b>",
             f"🕘 {WEEKDAYS_SHORT[d.weekday()]}, {d.day:02d}.{d.month:02d} · {it.start:%H:%M}–{it.end:%H:%M}"]
    if it.room:
        lines.append(f"📍 {room_line(it.room, rooms)}")
    if it.teacher:
        lines.append(f"👤 {esc(it.teacher)}")
    return "\n".join(lines)


@router.message(Command("next"))
@router.message(F.text == BTN_NEXT)
async def m_next(m: Message):
    await set_state(m.from_user.id)
    async with Session() as s:
        u = await get_user(s, m.from_user)
        if await _need_group(m, s, u):
            return
        text = await _next_text(s, u)
    await m.answer(text)


@router.callback_query(F.data == "nx")
async def cb_next(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user)
        text = await _next_text(s, u)
    await c.message.answer(text)
    await c.answer()


@router.message(Command("room"))
async def cmd_room(m: Message, command: CommandObject):
    if not command.args:
        await m.answer("Напиши номер: <code>/room 305</code>")
        return
    async with Session() as s:
        rooms = await rooms_map(s)
    await m.answer(room_card(command.args.strip(), rooms))


@router.message(Command("changes"))
async def cmd_changes(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user)
        if await _need_group(m, s, u):
            return
        since = now_local() - timedelta(days=14)
        rows = list(await s.scalars(select(ChangeLog).where(
            ChangeLog.group_id == u.group_id, ChangeLog.created_at >= since)
            .order_by(ChangeLog.id.desc()).limit(12)))
    if not rows:
        await m.answer("За последние 2 недели расписание твоей группы не менялось ✅")
        return
    parts = [f"<i>{r.created_at:%d.%m %H:%M}</i>\n{r.text}" for r in rows]
    await m.answer("🕓 <b>Последние изменения</b>\n\n" + "\n\n".join(parts))


# ───────────────────────── новости ─────────────────────────

NEWS_PAGE = 3


async def show_news(target, bot: Bot, offset: int = 0):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        q = select(Post).where(Post.status == "sent")
        q = q.where((Post.target_group_id.is_(None)) | (Post.target_group_id == (u.group_id or -1)))
        posts = list(await s.scalars(q.order_by(Post.id.desc()).offset(offset).limit(NEWS_PAGE + 1)))
        news_on = u.news_on
    chat_id = target.from_user.id
    if not posts:
        await bot.send_message(chat_id, "📰 Новостей пока нет." if offset == 0 else "Это были все новости.")
    for p in reversed(posts[:NEWS_PAGE]):
        try:
            await bot.copy_message(chat_id, p.src_chat_id, p.src_message_id)
        except Exception:
            pass
    kb = InlineKeyboardBuilder()
    if len(posts) > NEWS_PAGE:
        kb.button(text="⬇️ Ещё новости", callback_data=f"news:{offset + NEWS_PAGE}")
    kb.button(text="🔕 Отписаться от рассылки" if news_on else "🔔 Подписаться на рассылку", callback_data="news_toggle")
    kb.adjust(1)
    if posts:
        await bot.send_message(chat_id, "📰 Лента новостей университета", reply_markup=kb.as_markup())
    if isinstance(target, CallbackQuery):
        await target.answer()


@router.message(Command("news"))
@router.message(F.text == BTN_NEWS)
async def m_news(m: Message, bot: Bot):
    await set_state(m.from_user.id)
    await show_news(m, bot)


@router.callback_query(F.data.startswith("news:"))
async def cb_news_more(c: CallbackQuery, bot: Bot):
    await show_news(c, bot, int(c.data[5:]))


@router.callback_query(F.data == "news_toggle")
async def cb_news_toggle(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user)
        u.news_on = not u.news_on
        await s.commit()
        on = u.news_on
    await c.answer("Рассылка новостей включена 🔔" if on else "Рассылка выключена 🔕", show_alert=True)


# ───────────────────────── настройки ─────────────────────────

def _tg(flag: bool) -> str:
    return "✅" if flag else "⬜️"


def _onoff(flag: bool) -> str:
    return "вкл" if flag else "выкл"


def s_main(u: User):
    first = f", первая пара — за {u.remind_before + u.first_extra} мин" if u.first_extra else ""
    text = (
        "⚙️ <b>Настройки</b>\n\n"
        f"👥 Группа: <b>{esc(cache.title(u.group_id) or 'не выбрана')}</b>\n\n"
        f"🔔 Напоминания: <b>{_onoff(u.notify_enabled)}</b> · за {u.remind_before} мин{first}\n"
        f"✅ «Пара закончилась»: {_onoff(u.end_on)} · ☕ Перемены: {_onoff(u.break_on)}\n"
        f"☀️ Утренняя сводка: {u.morning_time:%H:%M} ({_onoff(u.morning_on)})\n"
        f"🌙 Вечерняя сводка: {u.evening_time:%H:%M} ({_onoff(u.evening_on)})\n"
        f"🔄 Изменения расписания: {_onoff(u.changes_on)} · 📰 Новости: {_onoff(u.news_on)}")
    kb = InlineKeyboardBuilder()
    kb.button(text="🔔 Напоминания", callback_data="st:rem")
    kb.button(text="⏰ Утро и вечер", callback_data="st:dig")
    kb.button(text="📬 Рассылки", callback_data="st:sub")
    kb.button(text="👥 Сменить группу", callback_data="st:grp")
    kb.button(text="⭐ Мои события", callback_data="st:ev")
    kb.button(text="🧪 Тест уведомления", callback_data="st:test")
    kb.adjust(2, 2, 2)
    return text, kb.as_markup()


def s_rem(u: User):
    text = (
        "🔔 <b>Напоминания о парах</b>\n\n"
        f"За сколько минут предупреждать: <b>{u.remind_before} мин</b>\n"
        f"Первую пару дня — ещё раньше (чтобы успеть собраться): "
        f"<b>{'+' + str(u.first_extra) + ' мин' if u.first_extra else 'не надо'}</b>"
        + (f" → за {u.remind_before + u.first_extra} мин" if u.first_extra else "") + "\n\n"
        "Ещё можно получать «пара закончилась» (что дальше и через сколько) и «перемена» между академическими часами.")
    kb = InlineKeyboardBuilder()
    kb.button(text=f"{_tg(u.notify_enabled)} Напоминания включены", callback_data="t:notify_enabled:rem")
    for n in REMIND_OPTIONS:
        kb.button(text=("🔘 " if u.remind_before == n else "") + f"{n}", callback_data=f"rb:{n}")
    for n in FIRST_EXTRA_OPTIONS:
        kb.button(text=("🔘 " if u.first_extra == n else "") + ("1-я: как все" if n == 0 else f"1-я: +{n}"),
                  callback_data=f"fe:{n}")
    kb.button(text=f"{_tg(u.end_on)} Пара закончилась", callback_data="t:end_on:rem")
    kb.button(text=f"{_tg(u.break_on)} Перемены", callback_data="t:break_on:rem")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1, 4, 4, 2, 1)
    return text, kb.as_markup()


def s_dig(u: User):
    text = (
        "⏰ <b>Утренняя и вечерняя сводки</b>\n\n"
        f"☀️ Утро — расписание на сегодня: <b>{u.morning_time:%H:%M}</b> ({_onoff(u.morning_on)})\n"
        f"🌙 Вечер — расписание на завтра: <b>{u.evening_time:%H:%M}</b> ({_onoff(u.evening_on)})\n\n"
        "Выбери время кнопкой или впиши своё. Если в этот день пар нет, утренняя сводка не приходит.")
    kb = InlineKeyboardBuilder()
    kb.button(text=f"{_tg(u.morning_on)} Утренняя сводка", callback_data="t:morning_on:dig")
    for t in MORNING_PRESETS:
        kb.button(text=("🔘 " if u.morning_time == t else "") + f"{t:%H:%M}", callback_data=f"mt:{t:%H:%M}")
    kb.button(text="✍️ Своё время (утро)", callback_data="mc")
    kb.button(text=f"{_tg(u.evening_on)} Вечерняя сводка", callback_data="t:evening_on:dig")
    for t in EVENING_PRESETS:
        kb.button(text=("🔘 " if u.evening_time == t else "") + f"{t:%H:%M}", callback_data=f"et:{t:%H:%M}")
    kb.button(text="✍️ Своё время (вечер)", callback_data="ec")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1, 3, 3, 1, 1, 3, 3, 1, 1)
    return text, kb.as_markup()


def s_sub(u: User):
    text = (
        "📬 <b>Рассылки</b>\n\n"
        "🔄 <b>Изменения расписания</b> — пришлю, что именно поменялось, и актуальное расписание. "
        "Очень рекомендую оставить включённым.\n\n"
        "📰 <b>Новости</b> — объявления университета.")
    kb = InlineKeyboardBuilder()
    kb.button(text=f"{_tg(u.changes_on)} Изменения расписания", callback_data="t:changes_on:sub")
    kb.button(text=f"{_tg(u.news_on)} Новости университета", callback_data="t:news_on:sub")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1)
    return text, kb.as_markup()


SCREENS = {"main": s_main, "rem": s_rem, "dig": s_dig, "sub": s_sub}
TOGGLES = {"notify_enabled", "end_on", "break_on", "morning_on", "evening_on", "changes_on", "news_on"}


async def show_settings(target, screen: str = "main"):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        text, kb = SCREENS[screen](u)
    await reply(target, text, kb)


@router.message(Command("settings"))
@router.message(F.text == BTN_SETTINGS)
async def m_settings(m: Message):
    await set_state(m.from_user.id)
    await show_settings(m)


@router.callback_query(F.data.startswith("st:"))
async def cb_settings_nav(c: CallbackQuery, bot: Bot):
    screen = c.data[3:]
    if screen in SCREENS:
        await show_settings(c, screen)
    elif screen == "grp":
        await show_depts(c, change=True)
    elif screen == "ev":
        await show_my(c)
    elif screen == "test":
        async with Session() as s:
            u = await get_user(s, c.from_user)
        text = ("🧪 <b>Тест уведомлений</b> — так они будут выглядеть:\n\n"
                f"⏰ Через <b>{fmt_dur(u.remind_before)}</b>: <b>Пример пары</b>\n🕘 12:10–15:10 · 3 ак. ч\n📍 304\n\n"
                "✅ <b>Пара закончилась</b>: Пример пары\n⏭ Дальше: <b>Другая пара</b> — через 20 мин")
        await bot.send_message(c.from_user.id, text)
        await c.answer("Отправил пример 👆")


@router.callback_query(F.data.startswith("t:"))
async def cb_toggle(c: CallbackQuery):
    _, field, screen = c.data.split(":")
    if field not in TOGGLES or screen not in SCREENS:
        await c.answer()
        return
    async with Session() as s:
        u = await get_user(s, c.from_user)
        setattr(u, field, not getattr(u, field))
        await s.commit()
        text, kb = SCREENS[screen](u)
    await reply(c, text, kb)


@router.callback_query(F.data.startswith(("rb:", "fe:", "mt:", "et:")))
async def cb_values(c: CallbackQuery):
    kind, val = c.data.split(":", 1)
    async with Session() as s:
        u = await get_user(s, c.from_user)
        if kind == "rb" and int(val) in REMIND_OPTIONS:
            u.remind_before, screen = int(val), "rem"
        elif kind == "fe" and int(val) in FIRST_EXTRA_OPTIONS:
            u.first_extra, screen = int(val), "rem"
        elif kind in ("mt", "et") and parse_hhmm(val):
            if kind == "mt":
                u.morning_time, u.morning_on = parse_hhmm(val), True
            else:
                u.evening_time, u.evening_on = parse_hhmm(val), True
            screen = "dig"
        else:
            await c.answer()
            return
        await s.commit()
        text, kb = SCREENS[screen](u)
    await reply(c, text, kb)


@router.callback_query(F.data.in_({"mc", "ec"}))
async def cb_custom_time(c: CallbackQuery):
    await set_state(c.from_user.id, "time_morning" if c.data == "mc" else "time_evening")
    which = "утренней" if c.data == "mc" else "вечерней"
    await reply(c, f"✍️ Напиши время {which} сводки в формате <b>ЧЧ:ММ</b>, например <code>7:45</code>.",
                back_kb("st:dig", "⬅️ Отмена"))


@router.message(InState("time_morning", "time_evening"))
async def on_custom_time(m: Message, st: str, st_data: str):
    t = parse_hhmm(m.text or "")
    if not t:
        await m.answer("Не понял время 🤔 Напиши так: <code>7:45</code> (или /cancel)")
        return
    async with Session() as s:
        u = await get_user(s, m.from_user)
        if st == "time_morning":
            u.morning_time, u.morning_on = t, True
        else:
            u.evening_time, u.evening_on = t, True
        u.state = ""
        await s.commit()
        text, kb = s_dig(u)
    await m.answer(f"Готово ✅ Сводка будет в <b>{t:%H:%M}</b>")
    await m.answer(text, reply_markup=kb)


# ───────────────────────── свои события / скрытые предметы ─────────────────────────

ADD_RE = re.compile(
    r"^(\S+)\s+(\d{1,2}[:.]\d{2})\s*[-–—]\s*(\d{1,2}[:.]\d{2})\s+(.+?)(?:,\s*(?:ауд\w*\.?\s*)?(\S+))?$", re.I)


async def show_my(target):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        mine = list(await s.scalars(select(PersonalLesson).where(PersonalLesson.user_id == u.tg_id)
                                    .order_by(PersonalLesson.weekday, PersonalLesson.start)))
        hidden = list(await s.scalars(select(HiddenSubject).where(HiddenSubject.user_id == u.tg_id)))
    lines = ["⭐ <b>Мои события</b>", "<i>Свои занятия (кружок, отработка…) — добавляются к расписанию и тоже с напоминаниями</i>", ""]
    kb = InlineKeyboardBuilder()
    for p in mine:
        lines.append(f"• {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M}–{p.end:%H:%M} · {esc(p.title)}"
                     + (f" · {esc(p.room)}" if p.room else ""))
        kb.button(text=f"🗑 {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M} {p.title[:16]}", callback_data=f"ev:del:{p.id}")
    if not mine:
        lines.append("Пока пусто.")
    lines += ["", "🙈 <b>Скрытые предметы</b> (не показываю и не напоминаю)"]
    for h in hidden:
        lines.append(f"• {esc(h.subject)}")
        kb.button(text=f"👁 Вернуть: {h.subject[:22]}", callback_data=f"hd:del:{h.id}")
    if not hidden:
        lines.append("нет")
    kb.button(text="➕ Добавить событие", callback_data="ev:add")
    kb.button(text="🙈 Скрыть предмет", callback_data="hd:add")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1)
    await reply(target, "\n".join(lines), kb.as_markup())


@router.message(Command("my"))
async def cmd_my(m: Message):
    await show_my(m)


@router.callback_query(F.data == "ev:add")
async def cb_ev_add(c: CallbackQuery):
    await set_state(c.from_user.id, "add_event")
    await reply(c, "➕ Напиши событие в формате:\n<code>пн 15:00-16:30 Английский, 210</code>\n"
                   "(день, время, название и — через запятую — аудитория, если нужна)",
                back_kb("ev:list", "⬅️ Отмена"))


@router.callback_query(F.data == "ev:list")
async def cb_ev_list(c: CallbackQuery):
    await set_state(c.from_user.id)
    await show_my(c)


@router.callback_query(F.data.startswith("ev:del:"))
async def cb_ev_del(c: CallbackQuery):
    async with Session() as s:
        await s.execute(delete(PersonalLesson).where(
            PersonalLesson.id == int(c.data[7:]), PersonalLesson.user_id == c.from_user.id))
        await s.commit()
    await show_my(c)


async def _add_event(m: Message, text: str):
    mt = ADD_RE.match((text or "").strip())
    day = DAYS.get(mt[1].lower()) if mt else None
    t1, t2 = (parse_hhmm(mt[2]), parse_hhmm(mt[3])) if mt else (None, None)
    if not mt or day is None or not t1 or not t2 or t2 <= t1:
        await m.answer("Не получилось разобрать 🤔 Пример: <code>пн 15:00-16:30 Английский, 210</code> (или /cancel)")
        return
    title, room = mt[4].strip(), (mt[5] or "")
    async with Session() as s:
        u = await get_user(s, m.from_user)
        s.add(PersonalLesson(user_id=u.tg_id, weekday=day, start=t1, end=t2, title=title[:200],
                             room=room[:50], parity=detect_parity(title)))
        u.state = ""
        await s.commit()
    await m.answer(f"Добавил ⭐ <b>{esc(title)}</b> — {WEEKDAYS_SHORT[day]} {t1:%H:%M}–{t2:%H:%M}")
    await show_my(m)


@router.message(InState("add_event"))
async def on_add_event(m: Message):
    await _add_event(m, m.text or "")


@router.message(Command("add"))
async def cmd_add(m: Message, command: CommandObject):
    if command.args:
        await _add_event(m, command.args)
    else:
        await set_state(m.from_user.id, "add_event")
        await m.answer("➕ Напиши событие: <code>пн 15:00-16:30 Английский, 210</code>")


@router.callback_query(F.data == "hd:add")
async def cb_hide_add(c: CallbackQuery):
    await set_state(c.from_user.id, "hide_subject")
    await reply(c, "🙈 Напиши <b>часть названия</b> предмета, который скрыть (например: <i>физкультура</i>).",
                back_kb("ev:list", "⬅️ Отмена"))


async def _hide(m: Message, name: str):
    name = (name or "").strip()
    if len(name) < 3:
        await m.answer("Напиши хотя бы 3 буквы (или /cancel)")
        return
    async with Session() as s:
        u = await get_user(s, m.from_user)
        s.add(HiddenSubject(user_id=u.tg_id, subject=name[:200]))
        u.state = ""
        await s.commit()
    await m.answer(f"Скрыл всё, где в названии «{esc(name)}» 🙈")
    await show_my(m)


@router.message(InState("hide_subject"))
async def on_hide(m: Message):
    await _hide(m, m.text or "")


@router.message(Command("hide"))
async def cmd_hide(m: Message, command: CommandObject):
    if command.args:
        await _hide(m, command.args)
    else:
        await set_state(m.from_user.id, "hide_subject")
        await m.answer("🙈 Напиши часть названия предмета, который скрыть:")


@router.callback_query(F.data.startswith("hd:del:"))
async def cb_hide_del(c: CallbackQuery):
    async with Session() as s:
        await s.execute(delete(HiddenSubject).where(
            HiddenSubject.id == int(c.data[7:]), HiddenSubject.user_id == c.from_user.id))
        await s.commit()
    await show_my(c)


# ───────────────────────── поиск группы текстом (должен быть последним) ─────────────────────────

@router.message(F.text & ~F.text.startswith("/"))
async def on_text(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user)
    if u.state == "group_search" or not u.group_id:
        await find_group(m, m.text)
    else:
        await m.answer("Не понял 🤔 Пользуйся кнопками внизу или /help")
