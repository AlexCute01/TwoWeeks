"""Для студентов: меню, расписание, выбор группы, настройки каждого оповещения, спросить про аудиторию текстом."""
import re
from datetime import date, datetime, timedelta

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import delete, func, select

from . import access
from .cache import cache
from .common import InState, eat, ephemeral, get_user, parse_hhmm, set_state, show, show_photo
from .config import COURSES, EVENING_PRESETS, FIRST_EXTRA_OPTIONS, MORNING_PRESETS, REMIND_OPTIONS, settings
from .db import ChangeLog, Group, HiddenSubject, PersonalLesson, Session, User
from .fmt import fmt_dur, room_card, room_line
from .parser import DAYS, detect_parity
from .programs import DEPTS, norm
from .schedule import next_item, render_day_text, render_week_text, rooms_map, week_monday
from .ui import (BTN_NEWS_OLD, BTN_NEXT, BTN_SETTINGS, BTN_TODAY, BTN_TOMORROW, BTN_WEATHER, BTN_WEEK, back_kb,
                 close_kb, day_kb, main_menu, week_kb)
from .util import WEEKDAYS_SHORT, esc, norm_room, now_local
from .weather import day_weather, short_weather

router = Router()
B = InlineKeyboardButton

HELP = """<b>📖 Как пользоваться</b>

Внизу — кнопки: сегодня, завтра, неделя, ближайшая пара, погода и настройки.

<b>Просто напиши</b> номер аудитории — например <code>304</code> или <code>где а501</code> — и я покажу, как её найти.
Или: <i>сегодня</i>, <i>завтра</i>, <i>неделя</i>, <i>где пара</i>, <i>погода</i>.

<b>Команды</b>
/today /tomorrow /week /next — расписание
/changes — что менялось за 2 недели
/group — сменить группу
/settings — уведомления (каждое включается отдельно) и время сводок
/my — свои события и скрытые предметы
/cancel — отменить ввод

<b>Свои события:</b> /add пн 15:00-16:30 Английский, 210
<b>Скрыть предмет:</b> /hide физкультура"""

WELCOME = ("👋 <b>Привет! Я бот расписания.</b>\n\n"
           "• напомню о паре и скажу, когда она началась;\n"
           "• между парами подскажу: перемена, что дальше или что учёба закончилась;\n"
           "• <b>сразу напишу, если расписание изменится</b>;\n"
           "• каждое оповещение можно выключить отдельно.\n\n"
           "Для начала выбери свой курс 👇")


def _menu(uid: int):
    return main_menu(access.is_admin(uid), bool(settings.openweather_api_key))


# ───────────────────────── выбор группы: курс → отделение → программа ─────────────────────────

async def show_courses(target, change: bool = False, **kw):
    async with Session() as s:
        rows = await s.execute(select(Group.course, func.count()).group_by(Group.course))
        counts = dict(rows.all())
    if not counts:
        await show(target, "База расписания пока пуста. Загляни чуть позже 🙏", **kw)
        return
    kb = InlineKeyboardBuilder()
    for c in COURSES:
        if counts.get(c):
            kb.button(text=f"📘 {c} курс", callback_data=f"gc:{c}")
    kb.button(text="🔎 Найти по названию", callback_data="gs")
    kb.adjust(*([len([c for c in COURSES if counts.get(c)])] if len(counts) <= 3 else [2]), 1)
    head = "🔄 <b>Смена группы</b>\n\n" if change else ""
    await show(target, head + "Выбери свой <b>курс</b>:", kb.as_markup(), **kw)


@router.callback_query(F.data == "gb")
async def cb_back(c: CallbackQuery):
    await show_courses(c)


@router.callback_query(F.data.startswith("gc:"))
async def cb_course(c: CallbackQuery):
    course = int(c.data[3:])
    async with Session() as s:
        rows = await s.execute(select(Group.dept, func.count()).where(Group.course == course).group_by(Group.dept))
        counts = {d or "": n for d, n in rows}
    kb = InlineKeyboardBuilder()
    for key, label in DEPTS.items():
        if counts.get(key):
            kb.button(text=f"{label} · {counts[key]}", callback_data=f"gd:{course}:{key or '_'}")
    kb.button(text="⬅️ К курсам", callback_data="gb")
    kb.adjust(1)
    await show(c, f"📘 <b>{course} курс</b>\nВыбери отделение:", kb.as_markup())


@router.callback_query(F.data.startswith("gd:"))
async def cb_dept(c: CallbackQuery):
    _, course, dept = c.data.split(":")
    dept = dept.replace("_", "")
    async with Session() as s:
        groups = list(await s.scalars(select(Group).where(Group.course == int(course), Group.dept == dept)
                                      .order_by(Group.title)))
    kb = InlineKeyboardBuilder()
    for g in groups:
        kb.button(text=(g.title or g.name)[:44], callback_data=f"gp:{g.id}")
    kb.button(text="⬅️ Назад", callback_data=f"gc:{course}")
    kb.adjust(1)
    await show(c, f"📘 {course} курс · {DEPTS.get(dept, '📂')}\n\nВыбери свою <b>программу</b>:", kb.as_markup())


@router.callback_query(F.data == "gs")
async def cb_search(c: CallbackQuery):
    await set_state(c.from_user.id, "group_search")
    await show(c, "🔎 Напиши часть названия — например: <i>юр</i>, <i>маркетинг</i>, <i>fintech</i>, <i>учёт</i>.",
               back_kb("gb", "⬅️ К курсам"))


@router.callback_query(F.data.startswith("gp:"))
async def cb_pick(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user)
        g = await s.get(Group, int(c.data[3:]))
        if not g:
            await c.answer("Не нашёл такую группу", show_alert=True)
            return
        first = u.group_id is None
        u.group_id, u.state, u.state_data, u.subgroup = g.id, "", "", ""
        await s.commit()
    await show_day(c)
    await ephemeral(c.message, ("🎉 <b>Готово!</b> " if first else "✅ ") +
                    f"Группа: <b>{esc(cache.title(g.id))}</b>\nНапоминания включены; настроить каждое — ⚙️ Настройки.",
                    8, kb=_menu(c.from_user.id))


async def find_group(m: Message, query: str):
    q = norm(query)
    await eat(m)
    if len(q) < 2:
        await ephemeral(m, "Напиши хотя бы 2 буквы 🙂")
        return
    async with Session() as s:
        groups = list(await s.scalars(select(Group).order_by(Group.course, Group.title)))
    hits = [g for g in groups if q in norm(g.title) or q in norm(g.name) or q in norm(g.codes)]
    if not hits:
        await ephemeral(m, "Ничего не нашёл 🤔 Попробуй другое слово или выбери из списка: /group")
        return
    kb = InlineKeyboardBuilder()
    for g in hits[:14]:
        kb.button(text=cache.title(g.id)[:46], callback_data=f"gp:{g.id}")
    kb.button(text="⬅️ К курсам", callback_data="gb")
    kb.adjust(1)
    await show(m, f"Нашёл: {len(hits)}. Выбери свою:" + (" (первые 14)" if len(hits) > 14 else ""),
               kb.as_markup(), delete_src=False)


# ───────────────────────── старт / команды ─────────────────────────

@router.message(CommandStart())
async def cmd_start(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user)
        has_group = bool(u.group_id)
        u.state, u.state_data = "", ""
        await s.commit()
    await m.answer("👇", reply_markup=_menu(m.from_user.id))   # включает кнопки внизу; ниже — единый экран
    await show_day(m) if has_group else await show_courses(m)
    if not has_group:
        await ephemeral(m, WELCOME, 20)


@router.message(Command("help"))
async def cmd_help(m: Message):
    await show(m, HELP, close_kb())


@router.callback_query(F.data == "x:close")
async def cb_close(c: CallbackQuery):
    await c.answer()
    try:
        await c.message.delete()
    except Exception:
        pass
    await _clear_screen(c.from_user.id)


async def _clear_screen(uid: int):
    async with Session() as s:
        u = await s.get(User, uid)
        if u:
            u.screen_id = 0
            await s.commit()


@router.message(Command("cancel"))
async def cmd_cancel(m: Message):
    await set_state(m.from_user.id)
    await show_day(m)


@router.message(Command("group"))
async def cmd_group(m: Message):
    await set_state(m.from_user.id)
    await show_courses(m, change=True)


@router.message(F.text == BTN_NEWS_OLD)
async def m_old_news(m: Message):
    await eat(m)
    await ephemeral(m, "Новости теперь приходят сами сообщением. Отказаться от них можно в ⚙️ Настройки → 🔔 Уведомления.",
                    8, kb=_menu(m.from_user.id))


# ───────────────────────── расписание ─────────────────────────

async def show_day(target, d: date | None = None, user=None):
    tg_user = user or target.from_user
    async with Session() as s:
        u = await get_user(s, tg_user)
        if not u.group_id:
            await show_courses(target)
            return
        now = now_local()
        d = d or now.date()
        text = await render_day_text(s, u, d, None, now)
    if d == now.date():
        w = await short_weather(d)
        if w:
            text = text.replace("\n\n", f"\n{w}\n\n", 1) if "\n\n" in text else text + "\n" + w
    await show(target, text, day_kb(d, now.date()), user=tg_user)


async def show_week(target, monday: date | None = None):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        if not u.group_id:
            await show_courses(target)
            return
        now = now_local()
        monday = monday or week_monday(now.date())
        text = await render_week_text(s, u, monday)
    await show(target, text, week_kb(monday, now.date()))


@router.message(Command("today"))
@router.message(F.text == BTN_TODAY)
async def m_today(m: Message):
    await set_state(m.from_user.id)
    await show_day(m)


@router.message(Command("tomorrow"))
@router.message(F.text == BTN_TOMORROW)
async def m_tomorrow(m: Message):
    await set_state(m.from_user.id)
    await show_day(m, now_local().date() + timedelta(days=1))


@router.message(Command("week"))
@router.message(F.text == BTN_WEEK)
async def m_week(m: Message):
    await set_state(m.from_user.id)
    await show_week(m)


@router.callback_query(F.data.startswith("d:"))
async def cb_day(c: CallbackQuery):
    await show_day(c, date.fromisoformat(c.data[2:]))


@router.callback_query(F.data.startswith("w:"))
async def cb_week(c: CallbackQuery):
    await show_week(c, date.fromisoformat(c.data[2:]))


async def _next_text(s, u: User) -> str:
    now = now_local()
    res = await next_item(s, u, now)
    if not res:
        return "⏭ На ближайшую неделю пар не нашёл 🎉"
    d, it = res
    left = int((datetime.combine(d, it.start) - now).total_seconds() // 60)
    rooms = await rooms_map(s)
    lines = [f"⏭ <b>Ближайшая пара</b> — через {fmt_dur(left)}", "",
             f"📚 <b>{esc(it.title)}</b>",
             f"🕘 {WEEKDAYS_SHORT[d.weekday()]}, {d.day:02d}.{d.month:02d} · {it.start:%H:%M}–{it.end:%H:%M}"]
    if it.room:
        lines.append(f"📍 {room_line(it.room, rooms)}")
    if it.teacher:
        lines.append(f"👤 {esc(it.teacher)}")
    return "\n".join(lines)


def _next_kb():
    kb = InlineKeyboardBuilder()
    kb.button(text="📅 Сегодня", callback_data=f"d:{now_local().date()}")
    kb.button(text="🗓 Неделя", callback_data=f"w:{week_monday(now_local().date())}")
    return kb.as_markup()


@router.message(Command("next"))
@router.message(F.text == BTN_NEXT)
async def m_next(m: Message):
    await set_state(m.from_user.id)
    async with Session() as s:
        u = await get_user(s, m.from_user)
        if not u.group_id:
            return await show_courses(m)
        text = await _next_text(s, u)
    await show(m, text, _next_kb())


@router.callback_query(F.data == "nx")
async def cb_next(c: CallbackQuery):
    async with Session() as s:
        u = await get_user(s, c.from_user)
        text = await _next_text(s, u)
    await show(c, text, _next_kb())


@router.message(Command("weather"))
@router.message(F.text == BTN_WEATHER)
async def m_weather(m: Message):
    await set_state(m.from_user.id)
    today = now_local().date()
    parts = [p for p in (await day_weather(today), await day_weather(today + timedelta(days=1))) if p]
    if not parts:
        text = "🌤 Погода сейчас недоступна."
    else:
        text = parts[0].replace("Погода в", "Сегодня · погода в", 1)
        if len(parts) > 1:
            text += "\n\n" + parts[1].replace("Погода в", "Завтра · погода в", 1)
    await show(m, text, close_kb())


@router.message(Command("changes"))
async def cmd_changes(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user)
        if not u.group_id:
            return await show_courses(m)
        since = now_local() - timedelta(days=14)
        rows = list(await s.scalars(select(ChangeLog).where(
            ChangeLog.group_id == u.group_id, ChangeLog.created_at >= since)
            .order_by(ChangeLog.id.desc()).limit(10)))
    if not rows:
        text = "За последние 2 недели расписание твоей группы не менялось ✅"
    else:
        text = "🕓 <b>Последние изменения</b>\n\n" + "\n\n".join(f"<i>{r.created_at:%d.%m %H:%M}</i>\n{r.text}" for r in rows)
    await show(m, text, close_kb())


# ───────────────────────── аудитории: можно просто спросить ─────────────────────────

ROOM_Q = re.compile(r"^\s*(?P<ask>где\s+(?:находится\s+|искать\s+)?)?(?P<kw>ауд\w*\.?|каб\w*\.?|room)?\s*"
                    r"(?P<code>[а-яa-z]?\s?\d{2,4}[а-яa-z]?)\s*[?!.]*\s*$", re.I)


async def answer_room(m: Message, code: str, u: User | None = None):
    code = re.sub(r"\s+", "", code)
    key = norm_room(code)
    async with Session() as s:
        rooms = await rooms_map(s)
        u = u or await get_user(s, m.from_user)
    r = rooms.get(key)
    where = ""
    if u.group_id:      # что у ТВОЕЙ группы проходит в этой аудитории
        hits = []
        for wd in range(6):
            for l in cache.lessons(u.group_id, wd):
                if key in {norm_room(p) for p in (l.room or "").split(",")}:
                    hits.append(f"• {WEEKDAYS_SHORT[wd]} {l.start:%H:%M} — {esc(l.subject)}")
        if hits:
            where = "\n\n<b>У твоей группы здесь:</b>\n" + "\n".join(hits[:8])
    if not r and key not in cache.rooms_in_use:
        await eat(m)
        await ephemeral(m, f"🤷 Не нашёл аудиторию <b>{esc(code)}</b> ни в расписании, ни в справочнике.", 7)
        return
    text = room_card(code, rooms) if r else (f"📍 <b>Аудитория {esc(code)}</b>\n"
                                             "Описания пока нет — администратор скоро добавит.")
    text += where
    if r and r.photo_id:
        await show_photo(m, r.photo_id, text[:1020], close_kb(), user=m.from_user)
    else:
        await show(m, text, close_kb())


@router.message(Command("room"))
async def cmd_room(m: Message, command: CommandObject):
    if not command.args:
        await eat(m)
        await ephemeral(m, "Просто напиши номер аудитории, например <code>304</code> или <code>где а501</code> 🙂", 8)
        return
    await answer_room(m, command.args.strip())


async def smart_text(m: Message, u: User, text: str) -> bool:
    """Понимает обычные фразы: номер аудитории, «сегодня», «завтра», «неделя», «где пара», «погода»."""
    t = text.strip().lower()
    mt = ROOM_Q.match(t)
    if mt:
        code = re.sub(r"\s+", "", mt["code"])
        explicit = bool(mt["ask"] or mt["kw"])
        async with Session() as s:
            known = norm_room(code) in await rooms_map(s) or norm_room(code) in cache.rooms_in_use
        if explicit or known or code[0].isalpha():
            await answer_room(m, code, u)
            return True
    if re.search(r"\bпогод", t):
        await m_weather(m)
        return True
    if re.search(r"где\s+(?:сейчас\s+)?(?:моя\s+)?(?:пар|занят|следующ|ближайш)|следующая пара|ближайшая пара", t):
        await m_next(m)
        return True
    if re.fullmatch(r"(?:расписание\s+)?(?:на\s+)?сегодня\??", t):
        await show_day(m)
        return True
    if re.fullmatch(r"(?:расписание\s+)?(?:на\s+)?завтра\??", t):
        await show_day(m, now_local().date() + timedelta(days=1))
        return True
    if re.fullmatch(r"(?:расписание\s+)?(?:на\s+)?(?:эту\s+)?недел[юя]\??", t):
        await show_week(m)
        return True
    return False


# ───────────────────────── настройки ─────────────────────────

def _tg(flag: bool) -> str:
    return "✅" if flag else "⬜️"


def _onoff(flag: bool) -> str:
    return "вкл" if flag else "выкл"


def s_main(u: User):
    first = f" (первая пара — за {u.remind_before + u.first_extra})" if u.first_extra else ""
    text = (
        "⚙️ <b>Настройки</b>\n\n"
        f"👥 <b>{esc(cache.title(u.group_id) or 'группа не выбрана')}</b>\n\n"
        f"⏰ Напоминание: {_onoff(u.remind_on)} · за {u.remind_before} мин{first}\n"
        f"▶️ Пара началась: {_onoff(u.start_on)} · ☕ Между парами: {_onoff(u.end_on)}\n"
        f"☀️ Утро: {u.morning_time:%H:%M} ({_onoff(u.morning_on)}) · 🌙 Вечер: {u.evening_time:%H:%M} ({_onoff(u.evening_on)})\n"
        f"🔄 Изменения расписания: {_onoff(u.changes_on)} · 📰 Новости: {_onoff(u.news_on)}\n"
        f"🧹 Автоочистка: {_onoff(u.autoclean_on)}"
        + ("" if u.notify_enabled else "\n\n⏸ <b>Уведомления о парах на паузе</b>"))
    kb = InlineKeyboardBuilder()
    kb.button(text="🔔 Что присылать", callback_data="st:notif")
    kb.button(text="⏱ За сколько минут", callback_data="st:rem")
    kb.button(text="⏰ Время сводок", callback_data="st:dig")
    kb.button(text="👥 Сменить группу", callback_data="st:grp")
    kb.button(text="⭐ Мои события", callback_data="st:ev")
    kb.button(text="🧪 Тест", callback_data="st:test")
    kb.adjust(1, 2, 2, 1)
    return text, kb.as_markup()


def s_notif(u: User):
    text = ("🔔 <b>Что присылать</b>\n<i>Каждое оповещение включается и выключается отдельно.</i>\n\n"
            "☕ <b>Между парами</b> — одно сообщение: перемена и что дальше, окно, либо «учёба на сегодня закончилась».")
    kb = InlineKeyboardBuilder()
    rows = [
        ("notify_enabled", "🔔 Все уведомления о парах"),
        ("remind_on", f"⏰ За {u.remind_before} мин до пары"),
        ("start_on", "▶️ Пара началась"),
        ("end_on", "☕ Между парами"),
        ("break_on", "🕐 Перемены внутри пары (между ак. часами)"),
        ("morning_on", f"☀️ Утренняя сводка · {u.morning_time:%H:%M}"),
        ("weather_on", "🌤 Погода в утренней сводке"),
        ("evening_on", f"🌙 Вечерняя сводка · {u.evening_time:%H:%M}"),
        ("changes_on", "🔄 Изменения расписания"),
        ("news_on", "📰 Новости университета"),
        ("autoclean_on", "🧹 Удалять устаревшие уведомления"),
    ]
    for field, label in rows:
        if field == "weather_on" and not settings.openweather_api_key:
            continue
        kb.button(text=f"{_tg(getattr(u, field))} {label}", callback_data=f"t:{field}:notif")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1)
    return text, kb.as_markup()


def s_rem(u: User):
    text = (
        "⏱ <b>За сколько минут предупреждать</b>\n\n"
        f"Сейчас: <b>{u.remind_before} мин</b>\n"
        f"Первую пару дня — ещё раньше (чтобы успеть собраться): "
        f"<b>{'+' + str(u.first_extra) + ' мин → за ' + str(u.remind_before + u.first_extra) if u.first_extra else 'как все'}</b>")
    kb = InlineKeyboardBuilder()
    for n in REMIND_OPTIONS:
        kb.button(text=("🔘 " if u.remind_before == n else "") + f"{n} мин", callback_data=f"rb:{n}")
    for n in FIRST_EXTRA_OPTIONS:
        kb.button(text=("🔘 " if u.first_extra == n else "") + ("1-я: как все" if n == 0 else f"1-я: +{n}"),
                  callback_data=f"fe:{n}")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(4, 3, 4, 1)
    return text, kb.as_markup()


def s_dig(u: User):
    text = (
        "⏰ <b>Утренняя и вечерняя сводки</b>\n\n"
        f"☀️ Утро (расписание на сегодня{' + погода' if settings.openweather_api_key else ''}): "
        f"<b>{u.morning_time:%H:%M}</b> ({_onoff(u.morning_on)})\n"
        f"🌙 Вечер (расписание на завтра): <b>{u.evening_time:%H:%M}</b> ({_onoff(u.evening_on)})\n\n"
        "Выбери время кнопкой или впиши своё. Если в этот день пар нет, утренняя сводка не приходит.")
    kb = InlineKeyboardBuilder()
    kb.button(text=f"{_tg(u.morning_on)} Утренняя сводка", callback_data="t:morning_on:dig")
    for t in MORNING_PRESETS:
        kb.button(text=("🔘 " if u.morning_time == t else "") + f"{t:%H:%M}", callback_data=f"mt:{t:%H:%M}")
    kb.button(text="✍️ Своё время (утро)", callback_data="mc")
    kb.button(text=f"{_tg(u.evening_on)} Вечерняя сводка", callback_data="t:evening_on:dig")
    for t in EVENING_PRESETS:
        kb.button(text=("🔘 " if u.evening_time == t else "") + f"{t:%H:%M}", callback_data=f"et:{t:%H:%M}")
    kb.button(text="✍️ Своё время (вечер)", callback_data="ec")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1, 3, 3, 1, 1, 3, 3, 1, 1)
    return text, kb.as_markup()


SCREENS = {"main": s_main, "notif": s_notif, "rem": s_rem, "dig": s_dig}
TOGGLES = {"notify_enabled", "remind_on", "start_on", "end_on", "break_on", "morning_on", "weather_on",
           "evening_on", "changes_on", "news_on", "autoclean_on"}


async def show_settings(target, screen: str = "main"):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        text, kb = SCREENS[screen](u)
    await show(target, text, kb)


@router.message(Command("settings"))
@router.message(F.text == BTN_SETTINGS)
async def m_settings(m: Message):
    await set_state(m.from_user.id)
    await show_settings(m)


@router.callback_query(F.data.startswith("st:"))
async def cb_nav(c: CallbackQuery, bot: Bot):
    screen = c.data[3:]
    if screen in SCREENS:
        await show_settings(c, screen)
    elif screen == "grp":
        await show_courses(c, change=True)
    elif screen == "ev":
        await show_my(c)
    elif screen == "test":
        async with Session() as s:
            u = await get_user(s, c.from_user)
        text = ("🧪 <b>Тест</b> — так выглядят уведомления:\n\n"
                f"⏰ Через <b>{fmt_dur(u.remind_before)}</b>: <b>Пример пары</b>\n🕘 12:10–15:10 · 3 ак. ч\n📍 304\n\n"
                "▶️ <b>Пара началась</b>: Пример пары\n\n"
                "☕ <b>Перемена 20 мин</b>\n⏭ Дальше: <b>Другая пара</b> в <b>15:30</b>")
        await c.answer("Отправил пример — исчезнет через минуту")
        await ephemeral(c.message, text, 60)


@router.callback_query(F.data.startswith("t:"))
async def cb_toggle(c: CallbackQuery):
    _, field, screen = c.data.split(":")
    if field not in TOGGLES or screen not in SCREENS:
        await c.answer()
        return
    async with Session() as s:
        u = await get_user(s, c.from_user)
        setattr(u, field, not getattr(u, field))
        await s.commit()
        text, kb = SCREENS[screen](u)
    await show(c, text, kb)


@router.callback_query(F.data.startswith(("rb:", "fe:", "mt:", "et:")))
async def cb_values(c: CallbackQuery):
    kind, val = c.data.split(":", 1)
    async with Session() as s:
        u = await get_user(s, c.from_user)
        if kind == "rb" and int(val) in REMIND_OPTIONS:
            u.remind_before, screen = int(val), "rem"
        elif kind == "fe" and int(val) in FIRST_EXTRA_OPTIONS:
            u.first_extra, screen = int(val), "rem"
        elif kind in ("mt", "et") and parse_hhmm(val):
            if kind == "mt":
                u.morning_time, u.morning_on = parse_hhmm(val), True
            else:
                u.evening_time, u.evening_on = parse_hhmm(val), True
            screen = "dig"
        else:
            await c.answer()
            return
        await s.commit()
        text, kb = SCREENS[screen](u)
    await show(c, text, kb)


@router.callback_query(F.data.in_({"mc", "ec"}))
async def cb_custom_time(c: CallbackQuery):
    await set_state(c.from_user.id, "time_morning" if c.data == "mc" else "time_evening")
    which = "утренней" if c.data == "mc" else "вечерней"
    await show(c, f"✍️ Напиши время {which} сводки в формате <b>ЧЧ:ММ</b>, например <code>7:45</code>.",
               back_kb("st:dig", "⬅️ Отмена"))


@router.message(InState("time_morning", "time_evening"))
async def on_custom_time(m: Message, st: str):
    t = parse_hhmm(m.text or "")
    if not t:
        await eat(m)
        await ephemeral(m, "Не понял время 🤔 Напиши так: <code>7:45</code> (или /cancel)", 6)
        return
    async with Session() as s:
        u = await get_user(s, m.from_user)
        if st == "time_morning":
            u.morning_time, u.morning_on = t, True
        else:
            u.evening_time, u.evening_on = t, True
        u.state = ""
        await s.commit()
        text, kb = s_dig(u)
    await show(m, text, kb)


# ───────────────────────── свои события / скрытые предметы ─────────────────────────

ADD_RE = re.compile(
    r"^(\S+)\s+(\d{1,2}[:.]\d{2})\s*[-–—]\s*(\d{1,2}[:.]\d{2})\s+(.+?)(?:,\s*(?:ауд\w*\.?\s*)?(\S+))?$", re.I)


async def show_my(target):
    async with Session() as s:
        u = await get_user(s, target.from_user)
        mine = list(await s.scalars(select(PersonalLesson).where(PersonalLesson.user_id == u.tg_id)
                                    .order_by(PersonalLesson.weekday, PersonalLesson.start)))
        hidden = list(await s.scalars(select(HiddenSubject).where(HiddenSubject.user_id == u.tg_id)))
    lines = ["⭐ <b>Мои события</b>", "<i>Свои занятия (кружок, отработка…) — добавляются к расписанию, с напоминаниями</i>", ""]
    kb = InlineKeyboardBuilder()
    for p in mine:
        lines.append(f"• {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M}–{p.end:%H:%M} · {esc(p.title)}"
                     + (f" · {esc(p.room)}" if p.room else ""))
        kb.button(text=f"🗑 {WEEKDAYS_SHORT[p.weekday]} {p.start:%H:%M} {p.title[:16]}", callback_data=f"ev:del:{p.id}")
    if not mine:
        lines.append("Пока пусто.")
    lines += ["", "🙈 <b>Скрытые предметы</b> (не показываю и не напоминаю)"]
    for h in hidden:
        lines.append(f"• {esc(h.subject)}")
        kb.button(text=f"👁 Вернуть: {h.subject[:22]}", callback_data=f"hd:del:{h.id}")
    if not hidden:
        lines.append("нет")
    kb.button(text="➕ Добавить событие", callback_data="ev:add")
    kb.button(text="🙈 Скрыть предмет", callback_data="hd:add")
    kb.button(text="⬅️ Назад", callback_data="st:main")
    kb.adjust(1)
    await show(target, "\n".join(lines), kb.as_markup())


@router.message(Command("my"))
async def cmd_my(m: Message):
    await show_my(m)


@router.callback_query(F.data == "ev:add")
async def cb_ev_add(c: CallbackQuery):
    await set_state(c.from_user.id, "add_event")
    await show(c, "➕ Напиши событие в формате:\n<code>пн 15:00-16:30 Английский, 210</code>\n"
                  "(день, время, название и — через запятую — аудитория, если нужна)", back_kb("ev:list", "⬅️ Отмена"))


@router.callback_query(F.data == "ev:list")
async def cb_ev_list(c: CallbackQuery):
    await set_state(c.from_user.id)
    await show_my(c)


@router.callback_query(F.data.startswith("ev:del:"))
async def cb_ev_del(c: CallbackQuery):
    async with Session() as s:
        await s.execute(delete(PersonalLesson).where(
            PersonalLesson.id == int(c.data[7:]), PersonalLesson.user_id == c.from_user.id))
        await s.commit()
    await show_my(c)


async def _add_event(m: Message, text: str):
    mt = ADD_RE.match((text or "").strip())
    day = DAYS.get(mt[1].lower()) if mt else None
    t1, t2 = (parse_hhmm(mt[2]), parse_hhmm(mt[3])) if mt else (None, None)
    await eat(m)
    if not mt or day is None or not t1 or not t2 or t2 <= t1:
        await ephemeral(m, "Не получилось разобрать 🤔 Пример: <code>пн 15:00-16:30 Английский, 210</code>", 8)
        return
    title, room = mt[4].strip(), (mt[5] or "")
    async with Session() as s:
        u = await get_user(s, m.from_user)
        s.add(PersonalLesson(user_id=u.tg_id, weekday=day, start=t1, end=t2, title=title[:200],
                             room=room[:50], parity=detect_parity(title)))
        u.state = ""
        await s.commit()
    await show_my(m)


@router.message(InState("add_event"))
async def on_add_event(m: Message):
    await _add_event(m, m.text or "")


@router.message(Command("add"))
async def cmd_add(m: Message, command: CommandObject):
    if command.args:
        await _add_event(m, command.args)
    else:
        await set_state(m.from_user.id, "add_event")
        await show(m, "➕ Напиши событие: <code>пн 15:00-16:30 Английский, 210</code>", back_kb("ev:list", "⬅️ Отмена"))


@router.callback_query(F.data == "hd:add")
async def cb_hide_add(c: CallbackQuery):
    await set_state(c.from_user.id, "hide_subject")
    await show(c, "🙈 Напиши <b>часть названия</b> предмета, который скрыть (например: <i>физкультура</i>).",
               back_kb("ev:list", "⬅️ Отмена"))


async def _hide(m: Message, name: str):
    name = (name or "").strip()
    await eat(m)
    if len(name) < 3:
        await ephemeral(m, "Напиши хотя бы 3 буквы", 5)
        return
    async with Session() as s:
        u = await get_user(s, m.from_user)
        s.add(HiddenSubject(user_id=u.tg_id, subject=name[:200]))
        u.state = ""
        await s.commit()
    await show_my(m)


@router.message(InState("hide_subject"))
async def on_hide(m: Message):
    await _hide(m, m.text or "")


@router.message(Command("hide"))
async def cmd_hide(m: Message, command: CommandObject):
    if command.args:
        await _hide(m, command.args)
    else:
        await set_state(m.from_user.id, "hide_subject")
        await show(m, "🙈 Напиши часть названия предмета, который скрыть:", back_kb("ev:list", "⬅️ Отмена"))


@router.callback_query(F.data.startswith("hd:del:"))
async def cb_hide_del(c: CallbackQuery):
    async with Session() as s:
        await s.execute(delete(HiddenSubject).where(
            HiddenSubject.id == int(c.data[7:]), HiddenSubject.user_id == c.from_user.id))
        await s.commit()
    await show_my(c)


# ───────────────────────── обычный текст (должен быть последним) ─────────────────────────

@router.message(F.text & ~F.text.startswith("/"))
async def on_text(m: Message):
    async with Session() as s:
        u = await get_user(s, m.from_user)
    if u.state == "group_search" or not u.group_id:
        await find_group(m, m.text)
        return
    if await smart_text(m, u, m.text):
        return
    await eat(m)
    await ephemeral(m, "Не понял 🤔 Напиши номер аудитории (например, <code>304</code>) или пользуйся кнопками внизу.", 6)
