"""Погода на день (OpenWeatherMap, бесплатный прогноз 5 дней / 3 часа). Ошибки молча игнорируются."""
import logging
import time as _time
from collections import Counter
from datetime import date, datetime, timedelta, timezone

import httpx

from .config import settings
from .util import esc

log = logging.getLogger(__name__)
_cache: dict[str, tuple[float, dict | None]] = {}
TTL = 30 * 60


async def _fetch(d: date) -> dict | None:
    if not settings.openweather_api_key:
        return None
    key = str(d)
    hit = _cache.get(key)
    if hit and _time.time() - hit[0] < TTL:
        return hit[1]
    data_out = None
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get("https://api.openweathermap.org/data/2.5/forecast", params={
                "lat": settings.weather_lat, "lon": settings.weather_lon, "units": "metric",
                "lang": "ru", "appid": settings.openweather_api_key})
        r.raise_for_status()
        data = r.json()
        shift = timedelta(seconds=data.get("city", {}).get("timezone", 18000))
        slots = []
        for it in data.get("list", []):
            local = datetime.fromtimestamp(it["dt"], tz=timezone.utc) + shift
            if local.date() == d and 5 <= local.hour <= 22:        # учебный день
                slots.append(it)
        if slots:
            data_out = dict(
                tmin=min(s["main"]["temp_min"] for s in slots), tmax=max(s["main"]["temp_max"] for s in slots),
                desc=Counter(s["weather"][0]["description"] for s in slots).most_common(1)[0][0],
                pop=max(s.get("pop", 0) for s in slots), wind=max(s["wind"]["speed"] for s in slots))
    except Exception as e:
        log.warning("weather failed: %s", e)
    _cache[key] = (_time.time(), data_out)
    return data_out


async def day_weather(d: date) -> str | None:
    """Полный блок для утренней сводки."""
    w = await _fetch(d)
    if not w:
        return None
    lines = [f"🌤 <b>Погода в {esc(settings.weather_city)}</b>",
             f"🌡 {w['tmin']:+.0f}…{w['tmax']:+.0f} °C · {esc(w['desc'])}",
             f"💧 осадки: {w['pop'] * 100:.0f}% · 💨 ветер до {w['wind']:.0f} м/с"]
    tips = []
    if w["pop"] >= 0.5:
        tips.append("☂️ возьми зонт")
    if w["tmax"] <= 5:
        tips.append("🧥 одевайся теплее")
    elif w["tmin"] >= 25:
        tips.append("🕶 жарко, бери воду")
    if tips:
        lines.append(" · ".join(tips))
    return "\n".join(lines)


async def short_weather(d: date) -> str | None:
    """Одна строка для экрана «Сегодня»."""
    w = await _fetch(d)
    if not w:
        return None
    return f"🌤 {w['tmin']:+.0f}…{w['tmax']:+.0f} °C · {esc(w['desc'])}" + (" · ☂️" if w["pop"] >= 0.5 else "")
