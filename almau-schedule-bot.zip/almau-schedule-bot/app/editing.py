"""
Операции редактора расписания (без интерфейса).

Ручные правки хранятся прямо в таблице lessons с пометкой manual:
  • изменённая пара из файла получает orig_key («день|начало|предмет» исходной) — по нему повторная загрузка файла
    её не дублирует и не затирает;
  • удалённая вручную пара остаётся строкой с deleted=True («надгробие»), чтобы файл её не вернул;
  • новая пара — manual без orig_key; пока не опубликована, это черновик (deleted=True) и студентам не видна.
Чтобы разослать студентам ИТОГОВЫЕ изменения (а не каждый клик), перед первой правкой группы сохраняется
снимок («base»), а при рассылке считается разница между снимком и текущим состоянием.
"""
from datetime import time

from sqlalchemy import delete, select

from .cache import cache
from .changes import Change, Entry, Slot, diff_group, dump_snapshot, load_snapshot, slot_of
from .db import Lesson, meta_get, meta_set

FIELDS = ["subject", "teacher", "room", "start", "end", "day"]
LABELS = {"subject": "📚 Предмет", "teacher": "👤 Преподаватель", "room": "📍 Аудитория",
          "start": "🕘 Начало", "end": "🕙 Конец", "day": "📅 День"}
DAYS_FULL = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"]


def _entry(l: Lesson) -> Entry:
    return (l.subject, l.teacher, l.room, l.start, l.end)


async def snapshot_group(s, gid: int) -> dict[Slot, list[Entry]]:
    snap: dict[Slot, list[Entry]] = {}
    for l in await s.scalars(select(Lesson).where(Lesson.group_id == gid, Lesson.deleted.is_(False))):
        snap.setdefault(slot_of(l.weekday, l.start, l.parity, l.subgroup), []).append(_entry(l))
    return snap


async def ensure_base(s, gid: int) -> None:
    """Запомнить состояние ДО правок (один раз, пока правки не разосланы)."""
    if not await meta_get(s, f"edit_base:{gid}"):
        await meta_set(s, f"edit_base:{gid}", dump_snapshot(await snapshot_group(s, gid)) or "[]")


async def pending(s, gid: int) -> list[Change]:
    raw = await meta_get(s, f"edit_base:{gid}")
    if not raw:
        return []
    return diff_group(load_snapshot(raw), await snapshot_group(s, gid))


async def clear_base(s, gid: int) -> None:
    await meta_set(s, f"edit_base:{gid}", "")


def _make_manual(l: Lesson) -> None:
    if not l.manual:
        l.manual = True
        l.orig_key = f"{l.weekday}|{l.start:%H:%M}|{l.subject}"


async def _touch(s, l: Lesson) -> None:
    await ensure_base(s, l.group_id)
    _make_manual(l)


async def set_text(s, l: Lesson, field: str, value: str) -> None:
    await _touch(s, l)
    value = value.strip()
    if field == "subject":
        if not value:
            return
        l.subject = value[:400]
    elif field == "teacher":
        l.teacher = "" if value in ("-", "—") else value[:400]
    elif field == "room":
        l.room = "" if value in ("-", "—") else value[:200]
    await s.flush()
    await cache.reload()


async def shift_time(s, l: Lesson, which: str, delta_min: int) -> bool:
    await _touch(s, l)
    cur = l.start if which == "start" else l.end
    total = max(0, min(23 * 60 + 59, cur.hour * 60 + cur.minute + delta_min))
    new = time(total // 60, total % 60)
    start, end = (new, l.end) if which == "start" else (l.start, new)
    if end <= start:
        return False
    l.start, l.end, l.segments = start, end, ""
    await s.flush()
    await cache.reload()
    return True


async def shift_day(s, l: Lesson, delta: int) -> None:
    await _touch(s, l)
    l.weekday = (l.weekday + delta) % 6
    await s.flush()
    await cache.reload()


async def delete_lesson(s, l: Lesson) -> None:
    await ensure_base(s, l.group_id)
    if l.manual and not l.orig_key:
        await s.delete(l)                    # своя ручная пара — просто удаляем
    else:
        _make_manual(l)
        l.deleted = True                     # пара из файла — «надгробие», чтобы файл её не вернул
    await s.flush()
    await cache.reload()


async def create_draft(s, gid: int, weekday: int) -> Lesson:
    l = Lesson(group_id=gid, weekday=weekday, pair_no=0, start=time(8, 0), end=time(10, 50),
               subject="Новая пара", teacher="", room="", kind="", parity=0, subgroup="", segments="",
               manual=True, deleted=True, orig_key="")
    s.add(l)
    await s.flush()
    return l


async def publish(s, l: Lesson) -> None:
    await ensure_base(s, l.group_id)
    l.deleted = False
    await s.flush()
    await cache.reload()


async def reset_group(s, gid: int) -> None:
    """Убрать все ручные правки программы (файл нужно применить заново — это делает вызывающий)."""
    await s.execute(delete(Lesson).where(Lesson.group_id == gid, Lesson.manual.is_(True)))
    await clear_base(s, gid)
    await s.flush()


async def day_lessons(s, gid: int, weekday: int, include_id: int | None = None) -> list[Lesson]:
    q = select(Lesson).where(Lesson.group_id == gid, Lesson.weekday == weekday)
    rows = [l for l in await s.scalars(q) if (not l.deleted) or l.id == include_id]
    return sorted(rows, key=lambda l: (l.start, l.end, l.id))
