"""
Проверка расписания: скачиваем файл по ссылке, сравниваем с текущим и рассылаем изменения.

Когда: с SYNC_START до SYNC_END каждые SYNC_EVERY_MIN минут (по умолчанию 06:00–18:00, шаг 50 мин) — см. notify.py.
Что делает check_schedule():
  1. скачивает xlsx; хэш не изменился — конец;
  2. защита: пар подозрительно мало (битый файл) — НЕ применяет, пишет админам;
  3. считает точный дифф по каждой программе, пишет журнал и кладёт уведомления в очередь
     В ТОЙ ЖЕ ТРАНЗАКЦИИ, что и новое расписание (либо всё, либо ничего);
  4. тем, кого коснулось, уходит: (а) что изменилось, (б) актуальное расписание на неделю.
"""
import asyncio
import hashlib
import logging
from collections import defaultdict

import httpx
from aiogram import Bot
from sqlalchemy import delete, select

from .cache import cache
from .changes import Change, Entry, Slot, build_message, describe, diff_group, is_relevant, slot_of
from .config import settings
from .db import ChangeLog, Group, HiddenSubject, Lesson, Session, User, meta_get, meta_set
from .outbox import PRIO_CHANGE, PRIO_URGENT, alert_admins, enqueue_many
from .parser import parse_workbook_ex
from .programs import info as program_info
from .schedule import render_week_text, rooms_map, week_monday
from .util import esc, now_local

log = logging.getLogger(__name__)
_lock = asyncio.Lock()


class SuspiciousFile(Exception):
    pass


async def fetch_xlsx(url: str | None = None) -> bytes:
    url = url or settings.schedule_url
    if not url:
        raise ValueError("SCHEDULE_URL не задан в /etc/schedule-bot.env")
    direct = url if "download=1" in url else url + ("&" if "?" in url else "?") + "download=1"
    async with httpx.AsyncClient(follow_redirects=True, timeout=90,
                                 headers={"User-Agent": "Mozilla/5.0 schedule-bot"}) as client:
        r = await client.get(direct)
    if r.status_code != 200 or not r.content.startswith(b"PK"):
        raise ValueError(
            f"Не удалось скачать xlsx (HTTP {r.status_code}). Скорее всего, ссылка требует входа в аккаунт: "
            "в SharePoint откройте «Поделиться → Все, у кого есть ссылка → Просмотр». "
            "Пока можно просто прислать файл боту.")
    return r.content


async def check_schedule(bot: Bot | None = None, force: bool = False) -> str:
    """Скачать и применить. Безопасно вызывать откуда угодно (есть блокировка от параллельных запусков)."""
    async with _lock:
        try:
            data = await fetch_xlsx()
        except Exception as e:
            log.warning("download failed: %s", e)
            async with Session() as s:
                n = int(await meta_get(s, "fail_count") or 0) + 1
                await meta_set(s, "fail_count", str(n))
                await meta_set(s, "last_check", f"{now_local():%d.%m %H:%M} — ❌ {e}"[:300])
                await s.commit()
            if n in (3, 12):         # не засыпаем админов: на 3-й и на 12-й сбой подряд
                await alert_admins(f"⚠️ Расписание не скачивается уже {n} раз подряд:\n{esc(str(e))}",
                                   key=f"dlfail:{now_local():%Y%m%d}:{n}")
            return f"❌ {e}"
        res = await apply_data(data, bot, force=force)
        async with Session() as s:
            await meta_set(s, "fail_count", "0")
            await meta_set(s, "last_check", f"{now_local():%d.%m %H:%M} — {res.splitlines()[0]}"[:300])
            await s.commit()
        return res


async def apply_data(data: bytes, bot: Bot | None = None, force: bool = False) -> str:
    """Применить файл (скачанный или присланный админом). Ошибки не пробрасывает — возвращает текст."""
    digest = hashlib.sha256(data).hexdigest()
    async with Session() as s:
        if not force:
            if digest == await meta_get(s, "xlsx_hash"):
                return "✅ Файл не изменился."
            if digest == await meta_get(s, "rejected_hash"):
                return "⛔ Этот файл уже отклонён как подозрительный."
    try:
        return await import_xlsx(data, bot, force=force)
    except SuspiciousFile as e:
        async with Session() as s:
            await meta_set(s, "rejected_hash", digest)
            await s.commit()
        await alert_admins(f"⚠️ {esc(str(e))}\n\nЕсли файл верный — пришлите его боту, импортирую принудительно.",
                           key=f"susp:{digest[:10]}")
        return f"⛔ {e}"
    except Exception as e:
        log.exception("apply_data failed")
        await alert_admins(f"❌ Не удалось применить файл расписания:\n{esc(str(e))}", key=f"err:{digest[:10]}")
        return f"❌ Ошибка: {e}"


def _slots(entries) -> dict[Slot, list[Entry]]:
    d: dict[Slot, list[Entry]] = defaultdict(list)
    for slot, e in entries:
        d[slot].append(e)
    return d


def _trim_html(text: str, limit: int = 3900) -> str:
    lines = text.split("\n")
    while len("\n".join(lines)) > limit and len(lines) > 3:
        lines.pop()
    return "\n".join(lines)


async def import_xlsx(data: bytes, bot: Bot | None = None, force: bool = False) -> str:
    digest = hashlib.sha256(data).hexdigest()
    dtos, report = await asyncio.to_thread(parse_workbook_ex, data, settings.include_hidden_sheets)
    if not dtos:
        raise ValueError("Не нашёл ни одной пары: структура файла отличается от ожидаемой (см. parser.py).")
    now = now_local()
    recipients: dict[int, int] = {}          # user_id -> priority (для «актуального расписания»)

    async with Session() as s:
        if not force and digest == await meta_get(s, "xlsx_hash"):
            return "✅ Файл не изменился."

        # --- что было ---
        old_by_group: dict[str, list] = defaultdict(list)
        old_count = 0
        rows = await s.execute(select(Group.name, Lesson).join(Lesson, Lesson.group_id == Group.id))
        for gname, l in rows:
            old_by_group[gname].append((slot_of(l.weekday, l.start, l.parity, l.subgroup),
                                        (l.subject, l.teacher, l.room, l.start, l.end)))
            old_count += 1

        if old_count and len(dtos) < old_count * settings.min_lessons_ratio and not force:
            raise SuspiciousFile(
                f"В новом файле пар: {len(dtos)}, а в текущем расписании: {old_count}. "
                "Похоже на сбой или недоредактированный файл — расписание НЕ обновлено.")

        # --- что стало ---
        new_by_group: dict[str, list] = defaultdict(list)
        for d in dtos:
            new_by_group[d.group].append((slot_of(d.weekday, d.start, d.parity, d.subgroup),
                                          (d.subject, d.teacher, d.room, d.start, d.end)))
        present = set(new_by_group) | set(report.groups)

        groups = {g.name: g for g in await s.scalars(select(Group))}
        for name in present:
            dept, title = program_info(name)
            g = groups.get(name)
            if not g:
                g = Group(name=name)
                s.add(g)
                await s.flush()
                groups[name] = g
            g.title, g.dept, g.codes = title, dept, report.codes.get(name, "")[:300]

        # пары заменяем только у программ, что есть в файле (пропавший лист не «обнуляется»)
        await s.execute(delete(Lesson).where(Lesson.group_id.in_([groups[n].id for n in present])))
        for d in dtos:
            s.add(Lesson(group_id=groups[d.group].id, weekday=d.weekday, pair_no=d.pair_no,
                         start=d.start, end=d.end, subject=d.subject, teacher=d.teacher,
                         room=d.room, kind=d.kind, parity=d.parity, subgroup=d.subgroup, segments=d.segments))

        # --- дифф и уведомления (в той же транзакции) ---
        changes: dict[int, tuple[str, list[Change]]] = {}
        if old_count:
            for name in present:
                if name not in old_by_group:
                    continue  # новая программа — уведомлять не о чем
                ch = diff_group(_slots(old_by_group[name]), _slots(new_by_group.get(name, [])))
                if ch:
                    changes[groups[name].id] = (groups[name].title or name, ch)

        queued = 0
        if changes:
            for gid, (_, chs) in changes.items():
                for c in chs:
                    s.add(ChangeLog(group_id=gid, created_at=now, text=describe(c)))
            users = list(await s.scalars(select(User).where(
                User.group_id.in_(list(changes)), User.changes_on.is_(True), User.blocked.is_(False))))
            hidden: dict[int, list[str]] = defaultdict(list)
            if users:
                hrows = await s.execute(select(HiddenSubject.user_id, HiddenSubject.subject).where(
                    HiddenSubject.user_id.in_([u.tg_id for u in users])))
                for uid, subj in hrows:
                    hidden[uid].append(subj.lower())
            items = []
            for u in users:
                title, chs = changes[u.group_id]
                rel = [c for c in chs if is_relevant(c, u.subgroup, hidden[u.tg_id])]
                if not rel:
                    continue
                text, urgent = build_message(title, rel, now)
                prio = PRIO_URGENT if urgent else PRIO_CHANGE
                items.append(dict(user_id=u.tg_id, text=text + "\n\n👇 <i>Актуальное расписание — ниже</i>",
                                  dedupe_key=f"chg:{digest[:12]}:{u.tg_id}", priority=prio))
                recipients[u.tg_id] = prio
            queued = await enqueue_many(s, items)

        missing = sorted(n for n in old_by_group if n not in present)
        await meta_set(s, "xlsx_hash", digest)
        await meta_set(s, "applied_at", now.isoformat())
        await s.commit()

    await cache.reload()

    # (б) актуальное расписание тем, кому ушло уведомление
    if recipients:
        async with Session() as s:
            rooms, monday = await rooms_map(s), week_monday(now.date())
            items = []
            for uid, prio in recipients.items():
                u = await s.get(User, uid)
                text = "📋 <b>Актуальное расписание</b>\n\n" + await render_week_text(s, u, monday, rooms)
                items.append(dict(user_id=uid, text=_trim_html(text), priority=prio,
                                  dedupe_key=f"sched:{digest[:12]}:{uid}"))
            await enqueue_many(s, items)
            await s.commit()

    lines = [f"✅ Пар: {len(dtos)}, программ: {len(present)}."]
    if changes:
        n_ch = sum(len(c) for _, c in changes.values())
        lines.append(f"Изменений: {n_ch} в {len(changes)} программах, уведомлений в очереди: {queued}.")
    elif old_count:
        lines.append("Изменений в парах нет.")
    if report.sheets_failed:
        lines.append(f"⚠️ Не распознал структуру листов: {', '.join(report.sheets_failed)}")
    for w in report.warnings[:5]:
        lines.append(f"⚠️ {w}")
    if missing:
        lines.append(f"⚠️ Нет в файле (оставил прежние пары): {', '.join(missing[:8])}")
    return "\n".join(lines)
