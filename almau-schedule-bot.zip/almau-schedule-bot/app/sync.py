"""
Проверка и загрузка расписания (по курсам).

Откуда берётся файл:
  • по ссылкам SCHEDULE_URL / _2 / _3 — автоматически с 06:00 до 18:00 каждые 50 минут (см. notify.py);
  • админ присылает .xlsx боту — тот же код, но с предпросмотром и подтверждением (admin.py).

Что делает import_xlsx():
  1. защита: пар подозрительно мало (битый файл) — НЕ применяет;
  2. считает точный дифф по каждой программе ТОЛЬКО этого курса — другие курсы не затрагиваются;
  3. ручные правки админа (редактор) сохраняются: пары, изменённые/удалённые вручную, файл не перезатирает;
  4. изменения, журнал и уведомления пишутся ОДНОЙ транзакцией (всё или ничего); режим dry_run откатывает её —
     это «предпросмотр» для админа;
  5. тем, кого коснулось: что изменилось + актуальное расписание на неделю.
Другие пользователи ничего не замечают: расписание подменяется атомарно, пока бот работает.
"""
import asyncio
import hashlib
import logging
import re
from collections import defaultdict
from pathlib import Path

import httpx
from aiogram import Bot
from sqlalchemy import delete, select

from .cache import cache
from .changes import Change, Entry, Slot, build_message, describe, diff_group, is_relevant, slot_of
from .config import settings
from .db import ChangeLog, Group, HiddenSubject, Lesson, Session, User, meta_get, meta_set
from .outbox import PRIO_CHANGE, PRIO_URGENT, alert_admins, enqueue_many
from .parser import parse_workbook_ex
from .programs import info as program_info
from .schedule import render_week_text, rooms_map, week_monday
from .util import esc, now_local

log = logging.getLogger(__name__)
_lock = asyncio.Lock()


class SuspiciousFile(Exception):
    pass


def stored_path(course: int) -> Path:
    d = Path(settings.data_dir) / "state"
    d.mkdir(parents=True, exist_ok=True)
    return d / f"xlsx_{course}.xlsx"


def course_from_filename(name: str) -> int | None:
    """«2_Расписание_2_курса_…» -> 2."""
    m = re.search(r"(\d)\s*[_ ]?\s*курс", name or "", re.I)
    return int(m.group(1)) if m else None


async def fetch_xlsx(url: str) -> bytes:
    direct = url if "download=1" in url else url + ("&" if "?" in url else "?") + "download=1"
    async with httpx.AsyncClient(follow_redirects=True, timeout=90,
                                 headers={"User-Agent": "Mozilla/5.0 schedule-bot"}) as client:
        r = await client.get(direct)
    if r.status_code != 200 or not r.content.startswith(b"PK"):
        raise ValueError(
            f"не удалось скачать (HTTP {r.status_code}). Скорее всего, ссылка требует входа в аккаунт: в SharePoint "
            "«Поделиться → Все, у кого есть ссылка → Просмотр». Пока можно прислать файл боту.")
    return r.content


# ───────────────────────── автопроверка по ссылкам ─────────────────────────

async def check_schedule(bot: Bot | None = None, force: bool = False, courses: list[int] | None = None) -> str:
    urls = settings.course_urls()
    if not urls:
        return "❌ Не задана ни одна ссылка (SCHEDULE_URL, SCHEDULE_URL_2, SCHEDULE_URL_3 в /etc/schedule-bot.env)."
    parts = []
    for c in sorted(courses or urls):
        if c in urls:
            parts.append(f"📘 <b>{c} курс</b>\n" + await check_course(c, bot, force))
    return "\n\n".join(parts) or "Нет ссылок для выбранных курсов."


async def check_course(course: int, bot: Bot | None = None, force: bool = False) -> str:
    async with _lock:
        try:
            data = await fetch_xlsx(settings.course_urls()[course])
        except Exception as e:
            log.warning("download failed (course %s): %s", course, e)
            async with Session() as s:
                n = int(await meta_get(s, f"fail:{course}") or 0) + 1
                await meta_set(s, f"fail:{course}", str(n))
                await meta_set(s, "last_check", f"{now_local():%d.%m %H:%M} — ❌ {course} курс: {e}"[:300])
                await s.commit()
            if n in (3, 12):         # не засыпаем админов: на 3-й и на 12-й сбой подряд
                await alert_admins(f"⚠️ {course} курс: расписание не скачивается {n} раз подряд — {esc(str(e))}",
                                   key=f"dlfail:{course}:{now_local():%Y%m%d}:{n}")
            return f"❌ {e}"
        res = await apply_data(data, course, bot, force=force)
        async with Session() as s:
            await meta_set(s, f"fail:{course}", "0")
            await meta_set(s, "last_check", f"{now_local():%d.%m %H:%M} — {course} курс: {res.splitlines()[0]}"[:300])
            await s.commit()
        return res


# ───────────────────────── применение файла ─────────────────────────

async def apply_data(data: bytes, course: int, bot: Bot | None = None, force: bool = False,
                     notify: bool = True, dry_run: bool = False) -> str:
    """Применить файл. Ошибки не пробрасывает — возвращает текст и предупреждает админов."""
    digest = hashlib.sha256(data).hexdigest()
    if not force and not dry_run:
        async with Session() as s:
            if digest == await meta_get(s, f"hash:{course}"):
                return "✅ Файл не изменился."
            if digest == await meta_get(s, f"rejected:{course}"):
                return "⛔ Этот файл уже отклонён как подозрительный."
    try:
        return await import_xlsx(data, course, bot, force=force, notify=notify, dry_run=dry_run)
    except SuspiciousFile as e:
        if not dry_run:
            async with Session() as s:
                await meta_set(s, f"rejected:{course}", digest)
                await s.commit()
            await alert_admins(f"⚠️ {course} курс: {esc(str(e))}\n\nЕсли файл верный — пришлите его боту и подтвердите.",
                               key=f"susp:{course}:{digest[:10]}")
        return f"⛔ {e}"
    except Exception as e:
        log.exception("apply_data failed")
        if not dry_run:
            await alert_admins(f"❌ {course} курс: не удалось применить файл — {esc(str(e))}", key=f"err:{digest[:10]}")
        return f"❌ Ошибка: {e}"


def _slots(entries) -> dict[Slot, list[Entry]]:
    d: dict[Slot, list[Entry]] = defaultdict(list)
    for slot, e in entries:
        d[slot].append(e)
    return d


def _trim_html(text: str, limit: int = 3900) -> str:
    lines = text.split("\n")
    while len("\n".join(lines)) > limit and len(lines) > 3:
        lines.pop()
    return "\n".join(lines)


async def record_and_notify(s, changes: dict[int, tuple[str, list[Change]]], key: str, now,
                            notify: bool = True) -> tuple[dict[int, int], int]:
    """Пишет журнал изменений и (если notify) кладёт в очередь уведомления. Общий код для импорта файла
    и для рассылки правок из редактора. -> ({user_id: приоритет}, сколько поставлено в очередь)."""
    if not notify or not changes:
        return {}, 0                      # «тихое» применение: ни рассылки, ни записи в историю
    for gid, (_, chs) in changes.items():
        for c in chs:
            s.add(ChangeLog(group_id=gid, created_at=now, text=describe(c)))
    users = list(await s.scalars(select(User).where(
        User.group_id.in_(list(changes)), User.changes_on.is_(True), User.blocked.is_(False))))
    hidden: dict[int, list[str]] = defaultdict(list)
    if users:
        hrows = await s.execute(select(HiddenSubject.user_id, HiddenSubject.subject).where(
            HiddenSubject.user_id.in_([u.tg_id for u in users])))
        for uid, subj in hrows:
            hidden[uid].append(subj.lower())
    items, recipients = [], {}
    for u in users:
        title, chs = changes[u.group_id]
        rel = [c for c in chs if is_relevant(c, u.subgroup, hidden[u.tg_id])]
        if not rel:
            continue
        text, urgent = build_message(title, rel, now)
        prio = PRIO_URGENT if urgent else PRIO_CHANGE
        items.append(dict(user_id=u.tg_id, text=text + "\n\n👇 <i>Актуальное расписание — ниже</i>",
                          dedupe_key=f"chg:{key}:{u.tg_id}", priority=prio))
        recipients[u.tg_id] = prio
    return recipients, await enqueue_many(s, items)


async def enqueue_actual(recipients: dict[int, int], key: str, now) -> None:
    """Вторым сообщением — актуальное расписание на неделю (вызывать ПОСЛЕ cache.reload())."""
    if not recipients:
        return
    async with Session() as s:
        rooms, monday = await rooms_map(s), week_monday(now.date())
        items = []
        for uid, prio in recipients.items():
            u = await s.get(User, uid)
            text = "📋 <b>Актуальное расписание</b>\n\n" + await render_week_text(s, u, monday, rooms)
            items.append(dict(user_id=uid, text=_trim_html(text), priority=prio, dedupe_key=f"sched:{key}:{uid}"))
        await enqueue_many(s, items)
        await s.commit()


async def import_xlsx(data: bytes, course: int, bot: Bot | None = None, force: bool = False,
                      notify: bool = True, dry_run: bool = False) -> str:
    digest = hashlib.sha256(data).hexdigest()
    dtos, report = await asyncio.to_thread(parse_workbook_ex, data, settings.include_hidden_sheets)
    if not dtos:
        raise ValueError("Не нашёл ни одной пары: структура файла отличается от ожидаемой (см. parser.py).")
    now = now_local()
    gname = lambda sheet: f"{course}|{sheet}"                         # noqa: E731
    recipients: dict[int, int] = {}

    async with Session() as s:
        if not force and not dry_run and digest == await meta_get(s, f"hash:{course}"):
            return "✅ Файл не изменился."

        # --- что было (пары курса, включая ручные) ---
        old_by_group: dict[str, list] = defaultdict(list)
        old_file_count = 0
        rows = await s.execute(select(Group.name, Lesson).join(Lesson, Lesson.group_id == Group.id)
                               .where(Group.course == course, Lesson.deleted.is_(False)))
        for name, l in rows:
            old_by_group[name].append((slot_of(l.weekday, l.start, l.parity, l.subgroup),
                                       (l.subject, l.teacher, l.room, l.start, l.end)))
            old_file_count += 0 if l.manual else 1

        if old_file_count and len(dtos) < old_file_count * settings.min_lessons_ratio and not force:
            raise SuspiciousFile(
                f"В новом файле пар: {len(dtos)}, а в текущем расписании: {old_file_count}. "
                "Похоже на сбой или недоредактированный файл — расписание НЕ обновлено.")

        # --- ручные правки админа: что подавлять в файле и что оставлять ---
        suppressed: dict[str, set[str]] = defaultdict(set)
        manual_live: dict[str, list] = defaultdict(list)
        mrows = await s.execute(select(Group.name, Lesson).join(Lesson, Lesson.group_id == Group.id)
                                .where(Group.course == course, Lesson.manual.is_(True)))
        for name, l in mrows:
            if l.orig_key:
                suppressed[name].add(l.orig_key)
            if not l.deleted:
                manual_live[name].append((slot_of(l.weekday, l.start, l.parity, l.subgroup),
                                          (l.subject, l.teacher, l.room, l.start, l.end)))

        # --- что стало ---
        present = {gname(sh) for sh in set(report.groups) | {d.group for d in dtos}}
        new_by_group: dict[str, list] = defaultdict(list)
        file_lessons: list = []
        for d in dtos:
            name = gname(d.group)
            if f"{d.weekday}|{d.start:%H:%M}|{d.subject}" in suppressed.get(name, set()):
                continue
            file_lessons.append(d)
            new_by_group[name].append((slot_of(d.weekday, d.start, d.parity, d.subgroup),
                                       (d.subject, d.teacher, d.room, d.start, d.end)))
        for name in present:
            new_by_group[name].extend(manual_live.get(name, []))

        groups = {g.name: g for g in await s.scalars(select(Group).where(Group.course == course))}
        for name in present:
            dept, title = program_info(name.split("|", 1)[1])
            g = groups.get(name)
            if not g:
                g = Group(name=name, course=course)
                s.add(g)
                await s.flush()
                groups[name] = g
            g.title, g.dept = title, dept
            g.codes = report.codes.get(name.split("|", 1)[1], "")[:300]

        # пары заменяем только у программ, что есть в файле; ручные правки остаются
        await s.execute(delete(Lesson).where(Lesson.group_id.in_([groups[n].id for n in present]),
                                             Lesson.manual.is_(False)))
        for d in file_lessons:
            s.add(Lesson(group_id=groups[gname(d.group)].id, weekday=d.weekday, pair_no=d.pair_no,
                         start=d.start, end=d.end, subject=d.subject, teacher=d.teacher,
                         room=d.room, kind=d.kind, parity=d.parity, subgroup=d.subgroup, segments=d.segments))

        # --- дифф и уведомления (в той же транзакции) ---
        changes: dict[int, tuple[str, list[Change]]] = {}
        if old_by_group:
            for name in present:
                if name not in old_by_group:
                    continue  # новая программа — уведомлять не о чем
                ch = diff_group(_slots(old_by_group[name]), _slots(new_by_group.get(name, [])))
                if ch:
                    changes[groups[name].id] = (groups[name].title or name, ch)
        recipients, queued = await record_and_notify(s, changes, digest[:12], now, notify=notify)

        missing = sorted(n.split("|", 1)[1] for n in old_by_group if n not in present)
        n_changes = sum(len(c) for _, c in changes.values())
        per_group = [f"• {esc(t)} — {len(c)}" for t, c in changes.values()]

        if dry_run:
            await s.rollback()                                       # предпросмотр: ничего не сохраняем
        else:
            await meta_set(s, f"hash:{course}", digest)
            await meta_set(s, "applied_at", now.isoformat())
            await meta_set(s, f"applied:{course}", now.isoformat())
            await s.commit()

    if not dry_run:
        stored_path(course).write_bytes(data)                        # копия — для «сбросить правки» в редакторе
        await cache.reload()
        if notify:
            await enqueue_actual(recipients, digest[:12], now)

    lines = [f"{'🔍 Предпросмотр' if dry_run else '✅ Применено'}: пар {len(dtos)}, программ {len(present)}."]
    if changes:
        lines.append(f"Изменений: {n_changes} в {len(changes)} программах"
                     + (f"; получат уведомление: {len(recipients)}" if notify else " (без рассылки)") + ".")
        lines += per_group[:12]
        if len(per_group) > 12:
            lines.append(f"…и ещё {len(per_group) - 12}")
    elif old_by_group:
        lines.append("Изменений в парах нет.")
    else:
        lines.append("Первая загрузка этого курса.")
    if report.sheets_failed:
        lines.append(f"⚠️ Не распознал структуру листов: {', '.join(report.sheets_failed)}")
    for w in report.warnings[:5]:
        lines.append(f"⚠️ {w}")
    if missing:
        lines.append(f"⚠️ Нет в файле (оставил прежние пары): {', '.join(missing[:8])}")
    return "\n".join(lines)


async def reapply_stored(course: int, bot: Bot | None = None) -> str:
    """Применить сохранённую копию файла заново (без рассылки) — после сброса ручных правок."""
    p = stored_path(course)
    if not p.exists():
        return "❌ Нет сохранённой копии файла этого курса — загрузите файл заново."
    return await apply_data(p.read_bytes(), course, bot, force=True, notify=False)
