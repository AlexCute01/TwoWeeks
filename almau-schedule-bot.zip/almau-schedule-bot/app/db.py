from datetime import datetime, time

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Index, Integer, String, Text, Time, event
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from .config import settings

engine = create_async_engine(settings.database_url)
Session = async_sessionmaker(engine, expire_on_commit=False)


@event.listens_for(engine.sync_engine, "connect")
def _sqlite_pragmas(dbapi_conn, _):
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")      # читатели не блокируют писателя
    cur.execute("PRAGMA synchronous=NORMAL")
    cur.execute("PRAGMA busy_timeout=10000")
    cur.close()


class Base(DeclarativeBase):
    pass


class Group(Base):
    """Образовательная программа = лист таблицы (все её группы учатся по одному расписанию)."""
    __tablename__ = "groups"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)    # ключ: название листа
    title: Mapped[str] = mapped_column(String(200), default="")    # красивое название («Юриспруденция»)
    dept: Mapped[str] = mapped_column(String(8), default="")       # ro / ko / ao
    codes: Mapped[str] = mapped_column(String(300), default="")    # коды групп из шапки (Б-СО-О-Р-ЮР-2601)


class Lesson(Base):
    __tablename__ = "lessons"
    __table_args__ = (Index("ix_lessons_group_day", "group_id", "weekday"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("groups.id"))
    weekday: Mapped[int] = mapped_column(Integer)            # 0 = Пн ... 5 = Сб
    pair_no: Mapped[int] = mapped_column(Integer)
    start: Mapped[time] = mapped_column(Time)
    end: Mapped[time] = mapped_column(Time)
    subject: Mapped[str] = mapped_column(String(400))
    teacher: Mapped[str] = mapped_column(String(400), default="")
    room: Mapped[str] = mapped_column(String(200), default="")
    kind: Mapped[str] = mapped_column(String(50), default="")
    parity: Mapped[int] = mapped_column(Integer, default=0)    # 0 — каждую, 1 — нечётная, 2 — чётная
    subgroup: Mapped[str] = mapped_column(String(8), default="")
    segments: Mapped[str] = mapped_column(String(300), default="")   # "08:00-08:50|09:00-09:50|10:00-10:50"


class User(Base):
    __tablename__ = "users"
    tg_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    username: Mapped[str] = mapped_column(String(64), default="")
    full_name: Mapped[str] = mapped_column(String(200), default="")
    group_id: Mapped[int | None] = mapped_column(ForeignKey("groups.id"), nullable=True)
    subgroup: Mapped[str] = mapped_column(String(8), default="")
    state: Mapped[str] = mapped_column(String(40), default="")        # ждём ввод: group_search / time_morning / ...
    state_data: Mapped[str] = mapped_column(String(200), default="")
    created_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # напоминания «вживую»
    notify_enabled: Mapped[bool] = mapped_column(Boolean, default=True)     # главный выключатель
    remind_before: Mapped[int] = mapped_column(Integer, default=10)         # за сколько минут до пары
    first_extra: Mapped[int] = mapped_column(Integer, default=0)            # первая пара дня — ещё на N минут раньше
    end_on: Mapped[bool] = mapped_column(Boolean, default=True)             # «пара закончилась»
    break_on: Mapped[bool] = mapped_column(Boolean, default=False)          # «перемена» между академическими часами
    # сводки
    morning_on: Mapped[bool] = mapped_column(Boolean, default=True)
    morning_time: Mapped[time] = mapped_column(Time, default=time(7, 30))
    evening_on: Mapped[bool] = mapped_column(Boolean, default=False)
    evening_time: Mapped[time] = mapped_column(Time, default=time(21, 0))
    # рассылки
    changes_on: Mapped[bool] = mapped_column(Boolean, default=True)
    news_on: Mapped[bool] = mapped_column(Boolean, default=True)
    blocked: Mapped[bool] = mapped_column(Boolean, default=False)           # заблокировал бота


class Admin(Base):
    """Админы, добавленные через бота. Владельцы из ADMIN_IDS здесь не хранятся."""
    __tablename__ = "admins"
    tg_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=False)
    added_by: Mapped[int] = mapped_column(BigInteger, default=0)
    created_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class Post(Base):
    """Пост для ленты новостей. Сам контент — сообщение админа (копируется как есть: текст, фото, файл)."""
    __tablename__ = "posts"
    id: Mapped[int] = mapped_column(primary_key=True)
    author_id: Mapped[int] = mapped_column(BigInteger)
    src_chat_id: Mapped[int] = mapped_column(BigInteger)
    src_message_id: Mapped[int] = mapped_column(Integer)
    target_group_id: Mapped[int | None] = mapped_column(Integer, nullable=True)   # None = всем
    status: Mapped[str] = mapped_column(String(8), default="draft")               # draft / sent
    created_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sent_count: Mapped[int] = mapped_column(Integer, default=0)


class PersonalLesson(Base):
    """Личные события пользователя (кружок, отработка и т.д.)."""
    __tablename__ = "personal_lessons"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.tg_id"), index=True)
    weekday: Mapped[int] = mapped_column(Integer)
    start: Mapped[time] = mapped_column(Time)
    end: Mapped[time] = mapped_column(Time)
    title: Mapped[str] = mapped_column(String(200))
    room: Mapped[str] = mapped_column(String(50), default="")
    parity: Mapped[int] = mapped_column(Integer, default=0)


class HiddenSubject(Base):
    __tablename__ = "hidden_subjects"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.tg_id"), index=True)
    subject: Mapped[str] = mapped_column(String(200))


class Room(Base):
    __tablename__ = "rooms"
    code: Mapped[str] = mapped_column(String(50), primary_key=True)
    building: Mapped[str] = mapped_column(String(100), default="")
    floor: Mapped[int | None] = mapped_column(Integer, nullable=True)
    description: Mapped[str] = mapped_column(Text, default="")


class Outbox(Base):
    """Очередь исходящих сообщений: переживает перезапуск, уходит с лимитом скорости.
    dedupe_key уникален — одно и то же уведомление не уйдёт дважды."""
    __tablename__ = "outbox"
    __table_args__ = (Index("ix_outbox_pending", "status", "priority", "id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger)
    kind: Mapped[str] = mapped_column(String(8), default="text")          # text / copy (копия сообщения админа)
    text: Mapped[str] = mapped_column(Text, default="")
    src_chat_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    src_message_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    dedupe_key: Mapped[str | None] = mapped_column(String(120), unique=True, nullable=True)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[int] = mapped_column(Integer, default=0)               # 0 ждёт, 1 отправлено, 2 отброшено
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    send_after: Mapped[datetime] = mapped_column(DateTime)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime)


class ChangeLog(Base):
    __tablename__ = "change_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("groups.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime)
    text: Mapped[str] = mapped_column(Text)


class Meta(Base):
    __tablename__ = "meta"
    key: Mapped[str] = mapped_column(String(50), primary_key=True)
    value: Mapped[str] = mapped_column(Text)


async def meta_get(s, key: str) -> str:
    m = await s.get(Meta, key)
    return m.value if m else ""


async def meta_set(s, key: str, value: str) -> None:
    m = await s.get(Meta, key)
    if m:
        m.value = value
    else:
        s.add(Meta(key=key, value=value))
