"""
Обновление КОДА бота прямо из Telegram (только владельцы из ADMIN_IDS).

Владелец присылает боту .zip с новой версией → бот проверяет архив → просит подтверждение → запускает установку
через sudo-обёртку `schedule-bot-apply-update` (её ставит install.sh) → сервис перезапускается ~на 10 секунд.
Остальные пользователи ничего не замечают: Telegram хранит их сообщения, пока бот перезапускается, очередь отправки
лежит в БД, пропущенные минуты напоминаний догоняются. Если новая версия не стартовала, update.sh откатывается сам.
Результат («обновлено» / «откат») приходит владельцу сообщением.
"""
import asyncio
import io
import logging
import re
import zipfile
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from . import access
from .common import eat, ephemeral, show
from .config import settings
from .ui import back_kb
from .util import esc, now_local
from .version import __version__

log = logging.getLogger(__name__)
router = Router()
MAX_ZIP = 20 * 1024 * 1024


def updates_dir() -> Path:
    d = Path(settings.data_dir) / "updates"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _validate(data: bytes) -> tuple[bool, str]:
    """-> (ок, версия | текст ошибки)."""
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        if z.testzip() is not None:
            return False, "архив повреждён"
        names = z.namelist()
    except zipfile.BadZipFile:
        return False, "это не zip-архив"
    if any(n.startswith("/") or ".." in n.split("/") for n in names):
        return False, "в архиве небезопасные пути"
    for need in ("app/main.py", "requirements.txt", "deploy/update.sh"):
        if not any(n.endswith(need) for n in names):
            return False, f"в архиве нет {need} — это не проект бота"
    ver = "?"
    for n in names:
        if n.endswith("app/version.py"):
            m = re.search(r'__version__\s*=\s*"([^"]+)"', z.read(n).decode("utf-8", "ignore"))
            ver = m.group(1) if m else "?"
    return True, ver


async def handle_zip(m: Message, bot: Bot):
    uid = m.from_user.id
    if not access.is_owner(uid):
        await eat(m)
        await ephemeral(m, "🔒 Обновлять код бота могут только <b>владельцы</b> (ADMIN_IDS на сервере).", 8)
        return
    if not settings.allow_bot_update:
        await eat(m)
        await ephemeral(m, "Обновление из Telegram отключено (ALLOW_BOT_UPDATE=false).", 6)
        return
    if (m.document.file_size or 0) > MAX_ZIP:
        await eat(m)
        await ephemeral(m, "Архив слишком большой (лимит Telegram для ботов — 20 МБ).", 6)
        return
    buf = io.BytesIO()
    await bot.download(m.document, destination=buf)
    ok, info = _validate(buf.getvalue())
    if not ok:
        await eat(m)
        await ephemeral(m, f"❌ Не подходит: {esc(info)}", 8)
        return
    ts = now_local().strftime("%Y%m%d%H%M%S")
    (updates_dir() / f"update-{ts}.zip").write_bytes(buf.getvalue())
    for old in sorted(updates_dir().glob("update-*.zip"))[:-3]:      # храним 3 последних архива
        old.unlink(missing_ok=True)
    kb = InlineKeyboardBuilder()
    kb.button(text=f"🚀 Обновить до v{esc(info)}", callback_data=f"upd:go:{ts}")
    kb.button(text="❌ Отмена", callback_data=f"upd:no:{ts}")
    kb.adjust(1)
    await show(m, f"📦 <b>Обновление бота</b>\n\nСейчас: v{__version__} → новая: <b>v{esc(info)}</b>\n\n"
                  "• бот перезапустится примерно на 10 секунд;\n"
                  "• данные, настройки и ссылки не затрагиваются, перед установкой делается копия базы;\n"
                  "• студенты ничего не заметят;\n"
                  "• если новая версия не запустится — откат произойдёт автоматически, я сообщу.", kb.as_markup(),
               delete_src=False)
    await eat(m)


@router.callback_query(F.data.startswith("upd:no:"))
async def cb_cancel(c: CallbackQuery):
    (updates_dir() / f"update-{c.data.split(':')[2]}.zip").unlink(missing_ok=True)
    from .admin import admin_home
    await admin_home(c)


@router.callback_query(F.data.startswith("upd:go:"))
async def cb_go(c: CallbackQuery):
    if not access.is_owner(c.from_user.id):
        return await c.answer("Только владельцы", show_alert=True)
    ts = c.data.split(":")[2]
    path = updates_dir() / f"update-{ts}.zip"
    if not re.fullmatch(r"\d{14}", ts) or not path.exists():
        return await c.answer("Архив уже не найден — пришлите заново", show_alert=True)
    await show(c, "⏳ Запускаю обновление…")
    try:
        proc = await asyncio.create_subprocess_exec(
            "sudo", "-n", "/usr/local/bin/schedule-bot-apply-update", str(path), str(c.message.chat.id),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=40)
        rc = proc.returncode
        text = out.decode("utf-8", "ignore")[-600:]
    except Exception as e:
        rc, text = 1, str(e)
    if rc != 0:
        await show(c, "❌ <b>Не удалось запустить обновление.</b>\n\n"
                      f"<code>{esc(text)}</code>\n\n"
                      "Скорее всего, на сервере ещё не настроено разрешение для этой функции. Один раз выполните там "
                      "<code>sudo bash deploy/install.sh</code> из папки с новой версией — дальше всё будет из Telegram.",
                   back_kb("ad:home", "⬅️ В админку"))
        return
    await show(c, "⏳ <b>Обновление идёт…</b>\nБот перезапустится сам и пришлёт сюда результат (обычно до минуты).")


# ───────────────────────── отчёт об обновлении ─────────────────────────

async def check_report(bot: Bot) -> None:
    """Если update.sh оставил отчёт — отправить его тому, кто запускал обновление. Вызывается при старте и в цикле."""
    f = Path(settings.data_dir) / "update_report.txt"
    if not f.exists():
        return
    try:
        data = dict(line.split("=", 1) for line in f.read_text(encoding="utf-8").splitlines() if "=" in line)
        f.unlink(missing_ok=True)
        status, chat = data.get("STATUS", ""), int(data.get("CHAT", "0") or 0)
        note = data.get("NOTE", "")
        if not chat:
            return
        text = {
            "ok": f"✅ <b>Бот обновлён</b> до v{__version__} и работает.\nДанные и настройки сохранены.",
            "rolled_back": f"↩️ <b>Новая версия не запустилась — выполнен откат</b> на предыдущую (v{__version__}).\n"
                           f"Данные целы.\n<code>{esc(note)}</code>",
            "rejected": f"❌ <b>Обновление отклонено</b> до установки: <code>{esc(note)}</code>\nБот не тронут.",
        }.get(status, f"ℹ️ Обновление: {esc(status)} {esc(note)}")
        await bot.send_message(chat, text)
    except Exception:
        log.exception("update report failed")
