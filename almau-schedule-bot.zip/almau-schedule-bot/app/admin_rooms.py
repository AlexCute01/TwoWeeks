"""Админ: аудитории — описание, корпус/этаж и фото. Студенты спрашивают обычным текстом («304», «где а501»)."""
import logging
import re

from aiogram import F, Router
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import select

from . import access
from .cache import cache
from .common import InState, eat, ephemeral, set_state, show
from .db import Room, Session
from .ui import back_kb, close_kb
from .util import esc, norm_room

log = logging.getLogger(__name__)
router = Router()
B = InlineKeyboardButton
PAGE = 12


def _deny(ev) -> bool:
    return not access.is_admin(ev.from_user.id)


async def _all_rooms() -> list[tuple[str, str, bool]]:
    """(ключ, как показывать, есть ли описание/фото) — комнаты из расписания + из справочника."""
    async with Session() as s:
        db = {r.code: r for r in await s.scalars(select(Room))}
    keys = set(cache.rooms_in_use) | set(db)
    out = []
    for k in keys:
        if len(k) > 28:
            continue
        r = db.get(k)
        out.append((k, cache.rooms_in_use.get(k) or k, bool(r and (r.description or r.photo_id or r.building))))
    return sorted(out, key=lambda x: (x[2], x[1]))      # сначала без описания


@router.callback_query(F.data.startswith("ad:rooms:"))
async def cb_list(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id)
    await rooms_list(c, int(c.data.split(":")[2]))


async def rooms_list(target, page: int = 0):
    rooms = await _all_rooms()
    chunk = rooms[page * PAGE:(page + 1) * PAGE]
    kb = InlineKeyboardBuilder()
    for i in range(0, len(chunk), 3):
        kb.row(*[B(text=f"{'✅' if d else '➖'} {name}", callback_data=f"ad:r:{k}") for k, name, d in chunk[i:i + 3]])
    nav = []
    if page > 0:
        nav.append(B(text="◀️", callback_data=f"ad:rooms:{page - 1}"))
    if (page + 1) * PAGE < len(rooms):
        nav.append(B(text="▶️", callback_data=f"ad:rooms:{page + 1}"))
    if nav:
        kb.row(*nav)
    kb.row(B(text="➕ Добавить по номеру", callback_data="ad:radd"), B(text="⬅️ В админку", callback_data="ad:home"))
    missing = sum(1 for _, _, d in rooms if not d)
    await show(target, f"🏫 <b>Аудитории</b> · всего {len(rooms)}, без описания: <b>{missing}</b>\n"
                       "➖ — описания ещё нет, ✅ — есть. Нажми на аудиторию, чтобы добавить описание и фото.\n\n"
                       "<i>Студенты просто пишут боту номер — «304» или «где а501» — и получают карточку.</i>",
               kb.as_markup(), **({"delete_src": False} if isinstance(target, Message) else {}))


@router.callback_query(F.data == "ad:radd")
async def cb_add(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id, "room_code")
    await show(c, "➕ Напиши номер аудитории, например <code>304</code> или <code>а501</code>.", back_kb("ad:rooms:0", "⬅️ Отмена"))


@router.message(InState("room_code"))
async def on_code(m: Message):
    if _deny(m):
        return
    key = norm_room(m.text or "")
    await eat(m)
    if not key or len(key) > 28:
        await ephemeral(m, "Не похоже на номер аудитории 🤔", 5)
        return
    await set_state(m.from_user.id)
    await card(m, key)


async def card(target, key: str):
    async with Session() as s:
        r = await s.get(Room, key)
    shown = cache.rooms_in_use.get(key) or key
    lines = [f"🏫 <b>Аудитория {esc(shown)}</b>", ""]
    lines.append(f"🏢 Корпус: <b>{esc(r.building) if r and r.building else '—'}</b>"
                 f" · этаж: <b>{r.floor if r and r.floor else '—'}</b>")
    lines.append(f"📝 Описание: {esc(r.description) if r and r.description else '—'}")
    lines.append(f"🖼 Фото: {'есть' if r and r.photo_id else 'нет'}")
    used = key in cache.rooms_in_use
    lines.append("\n" + ("✅ используется в расписании" if used else "ℹ️ в расписании сейчас не встречается"))
    kb = InlineKeyboardBuilder()
    kb.button(text="🏢 Корпус и этаж", callback_data=f"ad:rb:{key}")
    kb.button(text="📝 Описание", callback_data=f"ad:rd:{key}")
    kb.button(text="🖼 Загрузить фото", callback_data=f"ad:rp:{key}")
    if r and r.photo_id:
        kb.button(text="👁 Показать фото", callback_data=f"ad:rv:{key}")
        kb.button(text="🗑 Убрать фото", callback_data=f"ad:rpx:{key}")
    if r:
        kb.button(text="🗑 Удалить запись", callback_data=f"ad:rx:{key}")
    kb.button(text="⬅️ К списку", callback_data="ad:rooms:0")
    kb.adjust(1, 2, 2, 1, 1)
    await show(target, "\n".join(lines), kb.as_markup(), **({"delete_src": False} if isinstance(target, Message) else {}))


@router.callback_query(F.data.startswith("ad:r:"))
async def cb_card(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id)
    await card(c, c.data[5:])


def _prompt(kind: str) -> str:
    return {"room_bld": "🏢 Напиши корпус и этаж через запятую: <code>Главный корпус, 3</code>\n(«-» — очистить)",
            "room_desc": "📝 Напиши описание — как найти аудиторию: <code>3 этаж, налево от лифта, дверь с табличкой</code>\n(«-» — очистить)",
            "room_photo": "🖼 Пришли <b>фото</b> аудитории (можно с подписью — она станет описанием)."}[kind]


@router.callback_query(F.data.regexp(r"^ad:r[bdp]:"))
async def cb_edit(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, tag, key = c.data.split(":", 2)
    state = {"rb": "room_bld", "rd": "room_desc", "rp": "room_photo"}[tag]
    await set_state(c.from_user.id, state, key)
    await show(c, _prompt(state), back_kb(f"ad:r:{key}", "⬅️ Отмена"))


async def _room(s, key: str) -> Room:
    r = await s.get(Room, key)
    if not r:
        r = Room(code=key, building="", description="", photo_id="")
        s.add(r)
    return r


@router.message(InState("room_bld", "room_desc", "room_photo"))
async def on_input(m: Message, st: str, st_data: str):
    if _deny(m):
        return
    key = st_data
    async with Session() as s:
        r = await _room(s, key)
        if st == "room_photo":
            if not m.photo:
                await eat(m)
                await ephemeral(m, "Пришли именно фото 🖼", 5)
                return
            r.photo_id = m.photo[-1].file_id
            if m.caption:
                r.description = m.caption.strip()[:1000]
        else:
            text = (m.text or "").strip()
            if st == "room_bld":
                if text in ("-", "—"):
                    r.building, r.floor = "", None
                else:
                    mt = re.match(r"^(.*?)(?:[,;]\s*(\d+)\s*(?:эт\w*)?)?$", text)
                    r.building = (mt[1] or "").strip()[:100]
                    r.floor = int(mt[2]) if mt[2] else None
            else:
                r.description = "" if text in ("-", "—") else text[:1000]
        await s.commit()
    await set_state(m.from_user.id)
    await eat(m)
    await card(m, key)


@router.callback_query(F.data.startswith("ad:rv:"))
async def cb_show_photo(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    async with Session() as s:
        r = await s.get(Room, c.data[6:])
    if r and r.photo_id:
        await c.message.answer_photo(r.photo_id, caption=f"🏫 {esc(c.data[6:])}", reply_markup=close_kb())
    await c.answer()


@router.callback_query(F.data.startswith("ad:rpx:"))
async def cb_photo_del(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    key = c.data[7:]
    async with Session() as s:
        r = await s.get(Room, key)
        if r:
            r.photo_id = ""
            await s.commit()
    await card(c, key)


@router.callback_query(F.data.startswith("ad:rx:"))
async def cb_delete(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    key = c.data[6:]
    async with Session() as s:
        r = await s.get(Room, key)
        if r:
            await s.delete(r)
            await s.commit()
    await rooms_list(c, 0)
