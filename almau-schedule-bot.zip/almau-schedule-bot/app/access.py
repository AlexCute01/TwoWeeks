"""Права админов: владельцы из ADMIN_IDS + админы, добавленные через бота (хранятся в БД)."""
from datetime import datetime

from sqlalchemy import select

from .config import settings
from .db import Admin, Session

_extra: set[int] = set()


async def load() -> None:
    global _extra
    async with Session() as s:
        _extra = set(await s.scalars(select(Admin.tg_id)))


def is_owner(uid: int) -> bool:
    return uid in settings.owners


def is_admin(uid: int) -> bool:
    return uid in settings.owners or uid in _extra


def all_admins() -> set[int]:
    return set(settings.owners) | set(_extra)


def extra_admins() -> set[int]:
    return set(_extra)


async def add_admin(uid: int, by: int) -> bool:
    """False, если уже админ."""
    if is_admin(uid):
        return False
    async with Session() as s:
        s.add(Admin(tg_id=uid, added_by=by, created_at=datetime.now()))
        await s.commit()
    _extra.add(uid)
    return True


async def remove_admin(uid: int) -> bool:
    async with Session() as s:
        a = await s.get(Admin, uid)
        if not a:
            return False
        await s.delete(a)
        await s.commit()
    _extra.discard(uid)
    return True
