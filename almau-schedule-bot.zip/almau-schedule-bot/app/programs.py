"""
Справочник программ (data/programs.yaml).

Названия листов отличаются от курса к курсу («ЮР1кРО» → «ЮР 2кРО» → «ЮР3кРО + ТиПО»), поэтому программа
определяется по «основе» названия: без номера курса, пробелов и пометок после «+», плюс отделение (РО/КО/АО).
Достаточно один раз описать программу в programs.yaml — она сопоставится на всех курсах.
Для листов, которых в справочнике нет, название берётся из имени листа (без «2кРО» и т.п.).
"""
import re
from functools import lru_cache
from pathlib import Path

import yaml

DEPTS = {  # порядок = порядок кнопок
    "ro": "🇷🇺 Русское отделение",
    "ko": "🇰🇿 Қазақ бөлімі",
    "ao": "🇬🇧 English department",
    "": "📂 Другое",
}
_LOOKALIKE = str.maketrans("abcehkmoptxy", "авсенкмортху")   # латиница -> кириллица
_COURSE_RE = re.compile(r"\d+\s*к\s*(?:ро|ко|ао)?", re.I)
_DEPT_RE = re.compile(r"\d\s*к\s*(ро|ко|ао)")


def sheet_key(title: str) -> str:
    return re.sub(r"\s+", " ", title or "").strip()


def norm(s: str) -> str:
    return re.sub(r"\s+", "", (s or "").casefold()).translate(_LOOKALIKE)


def _split(sheet: str) -> tuple[str, str]:
    head, _, tail = (sheet or "").partition("+")
    return head, tail.strip()


def _dept_of(head: str) -> str:
    n = norm(head)
    m = _DEPT_RE.search(n)
    if m:
        return {"ро": "ro", "ко": "ko", "ао": "ao"}[m.group(1)]
    m = re.search(r"(ро|ко|ао)$", n)
    return {"ро": "ro", "ко": "ko", "ао": "ao"}[m.group(1)] if m else ""


def _base(head: str) -> str:
    """Основа названия: без курса, отделения и знаков препинания («ЮР 2кРО» -> «юр»)."""
    n = norm(head)
    n = _COURSE_RE.sub("", n)
    n = re.sub(r"к?(?:ро|ко|ао)$", "", n)           # «ТУРкКО» -> «тур»
    return re.sub(r"[^a-zа-яё]", "", n)


def _clean_title(head: str) -> str:
    s = _COURSE_RE.sub("", head)
    s = re.sub(r"[\s,.\-]*\b(?:ро|ко|ао)\b[\s,.\-]*$", "", s, flags=re.I)
    return re.sub(r"\s+", " ", s).strip(" ,.-") or sheet_key(head)


@lru_cache(maxsize=1)
def _load() -> dict[tuple[str, str], str]:
    path = Path(__file__).parent.parent / "data" / "programs.yaml"
    out: dict[tuple[str, str], str] = {}
    if path.exists():
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        for dept, rows in data.items():
            for r in rows or []:
                for s in [r["sheet"], *r.get("also", [])]:
                    out[(_base(s), dept)] = r["title"]
    return out


def info(sheet_title: str) -> tuple[str, str]:
    """-> (отделение, красивое название) для листа любого курса."""
    head, tail = _split(sheet_title)
    dept = _dept_of(head)
    title = _load().get((_base(head), dept)) or _clean_title(head)
    return dept, title + (f" + {tail}" if tail else "")
