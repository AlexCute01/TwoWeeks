"""Справочник программ (data/programs.yaml): название листа -> (отделение, красивое название)."""
import re
from functools import lru_cache
from pathlib import Path

import yaml

DEPTS = {  # порядок = порядок кнопок
    "ro": "🇷🇺 Русское отделение",
    "ko": "🇰🇿 Қазақ бөлімі",
    "ao": "🇬🇧 English department",
    "": "📂 Другое",
}
_LOOKALIKE = str.maketrans("abcehkmoptxy", "авсенкмортху")   # латиница -> кириллица


def sheet_key(title: str) -> str:
    return re.sub(r"\s+", " ", title or "").strip()


def norm(s: str) -> str:
    return re.sub(r"\s+", "", (s or "").casefold()).translate(_LOOKALIKE)


@lru_cache(maxsize=1)
def _load() -> dict[str, tuple[str, str]]:
    path = Path(__file__).parent.parent / "data" / "programs.yaml"
    out: dict[str, tuple[str, str]] = {}
    if path.exists():
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        for dept, rows in data.items():
            for r in rows or []:
                out[norm(r["sheet"])] = (dept, r["title"])
    return out


def info(sheet_title: str) -> tuple[str, str]:
    """-> (dept, title). Для неизвестных листов: отделение по суффиксу (…РО/КО/АО), название = название листа."""
    hit = _load().get(norm(sheet_title))
    if hit:
        return hit
    n = norm(sheet_title)
    dept = "ro" if n.endswith("ро") else "ko" if n.endswith("ко") else "ao" if n.endswith("ао") else ""
    return dept, sheet_key(sheet_title)
