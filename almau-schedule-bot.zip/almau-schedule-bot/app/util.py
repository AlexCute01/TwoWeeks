"""Мелкие общие функции (без БД и aiogram)."""
import html
import re
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from .config import settings

WEEKDAYS = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
WEEKDAYS_SHORT = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня",
          "июля", "августа", "сентября", "октября", "ноября", "декабря"]


def esc(x) -> str:
    return html.escape(str(x or ""))


def now_local() -> datetime:
    """Текущее локальное время (naive) — так хранится всё время в БД."""
    return datetime.now(ZoneInfo(settings.timezone)).replace(tzinfo=None)


_LOOKALIKE = str.maketrans("aceopx", "асеорх")   # латиница -> кириллица («a501» и «а501» — одна аудитория)


def norm_room(code: str) -> str:
    return re.sub(r"(?i)ауд\w*\.?|каб\w*\.?|\s+", "", code or "").lower().translate(_LOOKALIKE)


def week_parity(d: date) -> int:
    """1 — нечётная неделя, 2 — чётная."""
    start = date.fromisoformat(settings.semester_start)
    monday = start - timedelta(days=start.weekday())
    return 1 if ((d - monday).days // 7) % 2 == 0 else 2


def parity_name(p: int) -> str:
    return "нечётная неделя" if p == 1 else "чётная неделя"
