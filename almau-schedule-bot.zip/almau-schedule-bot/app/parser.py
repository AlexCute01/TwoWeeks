"""
Парсер xlsx -> список LessonDTO.

⚠️ Это ЧЕРНОВИК под самый типичный вузовский макет:

    |  день  | пара |  ГРУППА-1  |  ГРУППА-2  | ...
    |  Пн    |  1   | Предмет    |            |
    |        |      | Препод     |            |
    |        |      | 305        |            |

Ячейки могут быть объединёнными (лекции на потоки), внутри ячейки —
предмет / преподаватель / аудитория в разных строках.
Когда увижу реальный файл, подгоню именно эту функцию (остальной код не меняется):
контракт — parse_workbook(bytes) -> list[LessonDTO].
"""
import io
import logging
import re
from dataclasses import dataclass, replace
from datetime import time

from openpyxl import load_workbook

from .config import PAIR_TIMES

log = logging.getLogger(__name__)

DAYS = {
    "пн": 0, "вт": 1, "ср": 2, "чт": 3, "пт": 4, "сб": 5,
    "понедельник": 0, "вторник": 1, "среда": 2, "четверг": 3, "пятница": 4, "суббота": 5,
}
PAIR_RE = re.compile(r"^\s*(\d{1,2})\b")
TEACHER_RE = re.compile(r"[А-ЯЁA-Z][а-яёa-z\-]+\s+[А-ЯЁA-Z]\.\s?[А-ЯЁA-Z]?\.?")
ROOM_LINE_RE = re.compile(r"^(?:(?:ауд|каб)\w*\.?\s*)?(\d{1,4}[А-Яа-яA-Za-z]?(?:[-/]\d+)?)$", re.I)
ROOM_INLINE_RE = re.compile(r"\b(?:ауд(?:итория)?|каб(?:инет)?)\.?\s*(\d[\w\-/]*)", re.I)
# пометки в скобках вроде (нечет), (лекция) — не часть названия/аудитории
MARK_RE = re.compile(r"\((?:нечет|чет|числ|знам|лекц|практ|лаб|сем)[^)]*\)", re.I)
KIND_WORDS = {"лекция", "лек", "практика", "пр", "практическое", "лабораторная", "лаб", "семинар", "сем"}


@dataclass(frozen=True)
class LessonDTO:
    group: str
    weekday: int
    pair_no: int
    start: time
    end: time
    subject: str
    teacher: str = ""
    room: str = ""
    kind: str = ""
    parity: int = 0      # 0 — каждую неделю, 1 — нечётная, 2 — чётная
    subgroup: str = ""


def detect_parity(text: str) -> int:
    t = text.lower().replace("ё", "е")
    if re.search(r"\b(нечет\w*|числит\w*)", t):
        return 1
    if re.search(r"\b(чет\w*|знамен\w*)", t):
        return 2
    return 0


def _kind(text: str) -> str:
    t = text.lower()
    for key, name in (("лекц", "лекция"), ("практ", "практика"), ("лаб", "лабораторная"), ("семин", "семинар")):
        if key in t:
            return name
    return ""


def _day_of(value: str | None) -> int | None:
    if not value:
        return None
    s = value.lower().strip(" .")
    for key, n in DAYS.items():
        if s == key or (len(key) > 2 and s.startswith(key)):
            return n
    return None


def _grid(ws) -> dict[tuple[int, int], str]:
    """Значения ячеек; объединённые диапазоны раскрыты на все ячейки."""
    grid: dict[tuple[int, int], str] = {}
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None and str(c.value).strip():
                grid[(c.row, c.column)] = str(c.value).strip()
    for mr in ws.merged_cells.ranges:
        v = grid.get((mr.min_row, mr.min_col))
        if v is None:
            continue
        for r in range(mr.min_row, mr.max_row + 1):
            for c in range(mr.min_col, mr.max_col + 1):
                grid[(r, c)] = v
    return grid


def _split_cell(text: str) -> tuple[str, str, str, str, int] | None:
    """-> (subject, teacher, room, kind, parity)"""
    parity, kind = detect_parity(text), _kind(text)
    teacher = room = ""
    subject: list[str] = []
    for line in (MARK_RE.sub("", l).strip(" ,;") for l in re.split(r"[\r\n]+", text)):
        if not line or line.lower() in KIND_WORDS:
            continue
        m = ROOM_LINE_RE.match(line)
        if m and not room:
            room = m.group(1)
            continue
        mt = TEACHER_RE.search(line)
        if mt and not teacher:
            teacher = mt.group(0).strip()
            continue
        subject.append(line)
    if not room:
        mi = ROOM_INLINE_RE.search(text)
        if mi:
            room = mi.group(1)
    if not subject:
        return None
    return " ".join(subject), teacher, room, kind, parity


def _parse_sheet(ws) -> list[LessonDTO]:
    g = _grid(ws)
    if not g:
        return []
    max_r, max_c = ws.max_row, ws.max_column

    # 1) колонка с днями недели
    day_col = first_day_row = None
    for (r, c), v in sorted(g.items()):
        if _day_of(v) is not None:
            day_col, first_day_row = c, r
            break
    if day_col is None:
        log.warning("Лист %r: не нашёл колонку с днями недели — пропускаю", ws.title)
        return []

    # 2) колонка с номером пары
    pair_col = None
    for c in range(day_col + 1, day_col + 4):
        if PAIR_RE.match(g.get((first_day_row, c), "")):
            pair_col = c
            break
    if pair_col is None:
        log.warning("Лист %r: не нашёл колонку с номером пары", ws.title)
        return []

    # 3) строка с названиями групп — ближайшая непустая выше первого дня
    header_row = None
    for r in range(first_day_row - 1, 0, -1):
        if any((r, c) in g for c in range(pair_col + 1, max_c + 1)):
            header_row = r
            break
    if header_row is None:
        return []

    cols: dict[str, list[int]] = {}
    for c in range(pair_col + 1, max_c + 1):
        v = g.get((header_row, c))
        if v:
            cols.setdefault(" ".join(v.split()), []).append(c)

    # 4) строки с парами
    rows: list[tuple[int, int, int]] = []  # (row, weekday, pair_no)
    day = None
    for r in range(first_day_row, max_r + 1):
        d = _day_of(g.get((r, day_col)))
        if d is not None:
            day = d
        m = PAIR_RE.match(g.get((r, pair_col), ""))
        if day is None or not m:
            continue
        rows.append((r, day, int(m.group(1))))

    result: list[LessonDTO] = []
    for name, cs in cols.items():
        per_col: list[set[LessonDTO]] = []
        for i, c in enumerate(cs):
            sub = str(i + 1) if len(cs) > 1 else ""
            found: set[LessonDTO] = set()
            for r, wd, pn in rows:
                cell = g.get((r, c))
                times = PAIR_TIMES.get(pn)
                if not cell or not times:
                    continue
                parsed = _split_cell(cell)
                if not parsed:
                    continue
                subject, teacher, room, kind, parity = parsed
                found.add(LessonDTO(name, wd, pn, times[0], times[1], subject, teacher, room, kind, parity, sub))
            per_col.append(found)

        if len(cs) > 1:  # подгруппы: пара, общая для всех колонок, -> без подгруппы
            bases = [{replace(l, subgroup="") for l in col} for col in per_col]
            common = set.intersection(*bases)
            result.extend(common)
            result.extend(l for col in per_col for l in col if replace(l, subgroup="") not in common)
        else:
            result.extend(per_col[0])
    return result


def parse_workbook(data: bytes) -> list[LessonDTO]:
    wb = load_workbook(io.BytesIO(data), data_only=True)
    out: list[LessonDTO] = []
    for ws in wb.worksheets:
        out.extend(_parse_sheet(ws))
    return sorted(set(out), key=lambda l: (l.group, l.weekday, l.pair_no, l.parity, l.subgroup))
