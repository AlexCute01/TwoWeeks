"""
Парсер расписания университета (формат реального файла).

Формат: один лист = одна образовательная программа (или несколько групп сразу).
Колонки (сдвиг на 0–1 колонку вправо в разных листах):

    Дни | Время | Дисциплина | Преподаватель (+ код в Платонусе) | Ауд
    Понедельник | 08.00-08.50 | Название (объединённая ячейка на 3 строки) | ФИО | 304
                | 09.00-09.50 |
                | 10.00-10.50 |

• Пара = объединённая ячейка «дисциплины»; она охватывает 2–3 академических часа
  (начало — первая строка, конец — последняя). Время пары берётся прямо из таблицы.
• Названия дней на трёх языках (рус / қаз / eng), с опечатками — определяем по первым буквам.
• Код группы (Б-СО-О-Р-ЮР-2601) лежит в шапке; в шапке может быть несколько групп через запятую —
  тогда пары копируются каждой. Нет кода (одна программа) — берём название листа.
• Скрытые листы (архив/черновики) пропускаем.
• Ячейка преподавателей/аудиторий может содержать несколько строк (потоки): «Мухтар / Круглова», «309 / 311».
"""
import difflib
import io
import logging
import re
from dataclasses import dataclass, field
from datetime import time

from openpyxl import load_workbook

from .programs import sheet_key

log = logging.getLogger(__name__)

MAXC, MAXR = 14, 130   # читаем только рабочую область (в некоторых листах «мусорные» merge до колонки XFD)

DAYS = {  # для команды /add
    "пн": 0, "вт": 1, "ср": 2, "чт": 3, "пт": 4, "сб": 5,
    "понедельник": 0, "вторник": 1, "среда": 2, "четверг": 3, "пятница": 4, "суббота": 5,
}
DAY_PREFIX = {
    "пон": 0, "пне": 0, "вто": 1, "сре": 2, "чет": 3, "пят": 4, "суб": 5,          # русский (+опечатки)
    "дүй": 0, "дуй": 0, "сей": 1, "сәр": 2, "сар": 2, "бей": 3, "жұм": 4, "жум": 4, "сен": 5,   # қазақша
    "mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5,                    # English
}
TIME_RE = re.compile(r"^\s*(\d{1,2})[.:](\d{2})\s*[-–—]\s*(\d{1,2})[.:](\d{2})\s*$")
# Б-СО-О-Р-ЮР-2601 (буквы могут быть латинскими «двойниками»); номер группы — 4 цифры
GROUP_RE = re.compile(r"[БB]\s*-\s*[СC][ОO]\s*-\s*[ОOВB]\s*-\s*[РPКKАA]\s*-[^,;\n]*?-?\s*\d{4}", re.I)
# код дисциплины в Платонусе: «KMKP 1362151-7-CH», «PLA 002130-10-CH»
CODE_RE = re.compile(r"\b[A-Za-zА-Яа-яЁёӘәҚқҢңӨөҰұҮүҺһІі]{1,10}\s?\d{6,7}-\d{1,3}(?:-[A-Za-z]{1,3})?")
PLATONUS_RE = re.compile(r"\(\s*[вВ]\s*[Пп]латонус[^)]*\)?")
PARITY_RE = re.compile(r"\(\s*(не)?чет\w*\s*\)|числитель|знаменатель", re.I)


@dataclass(frozen=True)
class LessonDTO:
    group: str
    weekday: int
    pair_no: int        # порядковый номер пары в дне (для красоты), считается после разбора
    start: time
    end: time
    subject: str
    teacher: str = ""
    room: str = ""
    kind: str = ""
    parity: int = 0     # 0 — каждую неделю, 1 — нечётная, 2 — чётная
    subgroup: str = ""
    segments: str = ""  # академические часы: "08:00-08:50|09:00-09:50|10:00-10:50"


@dataclass
class ParseReport:
    groups: set = field(default_factory=set)      # все группы с корректной структурой (даже без пар)
    sheets_ok: list = field(default_factory=list)
    sheets_hidden: list = field(default_factory=list)
    sheets_failed: list = field(default_factory=list)   # видимые, но структура не распознана
    codes: dict = field(default_factory=dict)           # лист -> коды групп из шапки
    warnings: list = field(default_factory=list)        # подозрительные места (порядок дней/времени)


def detect_parity(text: str) -> int:
    m = PARITY_RE.search(text.lower().replace("ё", "е"))
    if not m:
        return 0
    return 1 if (m.group(1) or "нечет" in m.group(0)) else 2


DAY_NAMES = {
    "понедельник": 0, "вторник": 1, "среда": 2, "четверг": 3, "пятница": 4, "суббота": 5,
    "дүйсенбі": 0, "сейсенбі": 1, "сәрсенбі": 2, "бейсенбі": 3, "жұма": 4, "сенбі": 5,
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3, "friday": 4, "saturday": 5,
}


def _day_of(value: str | None) -> int | None:
    """Номер дня недели по подписи. Понимает 3 языка, опечатки («Понеделник», «Чеиверг»), латиницу-двойники."""
    if not value:
        return None
    s = re.sub(r"[\W_]+", "", value.strip().lower())
    if not s or s[0].isdigit():
        return None
    d = DAY_PREFIX.get(s[:3])
    if d is not None:
        return d
    if len(s) >= 5:                                   # опечатка в слове: ищем самое похожее название
        m = difflib.get_close_matches(s, DAY_NAMES, n=1, cutoff=0.72)
        if m:
            return DAY_NAMES[m[0]]
    return None


def _clean_text(s: str) -> str:
    s = PLATONUS_RE.sub("", s.replace("\t", " "))
    s = CODE_RE.sub("", s)
    return re.sub(r"\s+", " ", s).strip(" ,;")


def _subject(raw: str) -> str:
    return _clean_text(re.sub(r"\s*[\r\n]+\s*", " / ", raw))


def _people(raw: str) -> list[str]:
    t = PLATONUS_RE.sub("", raw.replace("\t", " "))
    t = CODE_RE.sub("", t)
    out: list[str] = []
    for p in re.split(r"[\r\n/,;]+", t):
        p = re.sub(r"\s+\.", ".", re.sub(r"\s+", " ", p)).strip(" ,;()")
        if p and p.lower() not in (x.lower() for x in out):
            out.append(p)
    return out


def _rooms(raw: str) -> list[str]:
    if "http" in raw.lower():                       # ссылка на онлайн-занятие
        return [raw.strip()]
    out: list[str] = []
    for r in re.split(r"[\r\n,;/]+|(?<=\d)\.(?=\d)", raw):
        r = re.sub(r"^[aAаА]\s*(?=\d)", "а", r.strip())   # латинская «a» -> кириллическая «а» (корпус А)
        if r and r not in out:
            out.append(r)
    return out


def _group_names(text: str) -> list[str]:
    names = []
    for m in GROUP_RE.findall(text):
        n = re.sub(r'["\s]+', "", m)
        n = re.sub(r"(?<=[^\d\-])(\d{4})$", r"-\1", n)
        if n not in names:
            names.append(n)
    return names


def _read_area(ws):
    grid: dict[tuple[int, int], str] = {}
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row or 1, MAXR), max_col=MAXC):
        for c in row:
            if c.value is None:
                continue
            s = str(c.value).strip()
            if s:
                grid[(c.row, c.column)] = s
    origin: dict[tuple[int, int], tuple[int, int]] = {}
    span_end: dict[tuple[int, int], int] = {}
    for rng in ws.merged_cells.ranges:
        if rng.min_col > MAXC or rng.min_row > MAXR:
            continue
        top = (rng.min_row, rng.min_col)
        last_r, last_c = min(rng.max_row, MAXR), min(rng.max_col, MAXC)
        span_end[top] = last_r
        for r in range(rng.min_row, last_r + 1):
            for c in range(rng.min_col, last_c + 1):
                origin[(r, c)] = top
    return grid, origin, span_end


def _parse_sheet(ws, report: ParseReport) -> list[LessonDTO] | None:
    """None — структура не распознана."""
    grid, origin, span_end = _read_area(ws)
    if not grid:
        return None

    def get(r: int, c: int) -> str | None:
        return grid.get(origin.get((r, c), (r, c)))

    max_r = max(r for r, _ in grid)

    # 1) колонка с днями недели: в ней ≥3 ячеек с названиями дней
    day_col, best = None, 0
    for c in range(1, 5):
        n = sum(1 for r in range(1, max_r + 1) if (r, c) in grid and _day_of(grid[(r, c)]) is not None)
        if n > best:
            day_col, best = c, n
    if day_col is None or best < 3:
        return None
    first_day_row = min(r for r in range(1, max_r + 1) if (r, day_col) in grid and _day_of(grid[(r, day_col)]) is not None)

    # 2) колонка со временем
    time_col, best = None, 0
    for c in (day_col + 1, day_col + 2):
        n = sum(1 for r in range(first_day_row, max_r + 1) if TIME_RE.match(get(r, c) or ""))
        if n > best:
            time_col, best = c, n
    if time_col is None:
        return None

    # 3) колонки: дисциплина / преподаватель / аудитория (ищем заголовок «ауд/room», иначе — по сдвигу)
    room_col = time_col + 3
    for r in range(1, first_day_row):
        for c in range(time_col + 1, time_col + 7):
            if re.fullmatch(r"\s*(ауд\.?|room|rooms)\s*", grid.get((r, c), ""), re.I):
                room_col = c
    teacher_col, subj_col = room_col - 1, room_col - 2

    # 4) программа = лист; коды групп из шапки — только для справки
    header_text = "\n".join(v for (r, _), v in sorted(grid.items()) if r < first_day_row)
    key = sheet_key(ws.title)
    groups = [key]
    report.codes[key] = ", ".join(_group_names(header_text))

    # 5) время по строкам и день по строкам
    times: dict[int, tuple[time, time]] = {}
    day_at: dict[int, int] = {}
    cur = None
    seen_days: list[int] = []
    for r in range(first_day_row, max_r + 1):
        d = _day_of(get(r, day_col))
        if d is not None:
            if origin.get((r, day_col), (r, day_col)) == (r, day_col):      # считаем подпись один раз
                seen_days.append(d)
            cur = d
        if cur is not None:
            day_at[r] = cur
        m = TIME_RE.match(get(r, time_col) or "")
        if m:
            times[r] = (time(int(m[1]), int(m[2])), time(int(m[3]), int(m[4])))

    if seen_days != sorted(set(seen_days)):
        report.warnings.append(f"Лист «{key}»: дни недели идут не по порядку или повторяются {seen_days}")

    # 6) пары
    lessons: list[LessonDTO] = []
    for r in sorted(times):
        if origin.get((r, subj_col), (r, subj_col)) != (r, subj_col):
            continue                                  # продолжение объединённой ячейки
        raw_subject = grid.get((r, subj_col))
        if not raw_subject or r not in day_at:
            continue
        last_r = span_end.get((r, subj_col), r)
        block = [x for x in sorted(times) if r <= x <= last_r]
        subject = _subject(raw_subject)
        if not subject:
            continue
        teachers = _people(get(r, teacher_col) or "")
        rooms: list[str] = []
        for x in block:
            for rm in _rooms(get(x, room_col) or ""):
                if rm not in rooms:
                    rooms.append(rm)
        start, end = times[block[0]][0], max(times[x][1] for x in block)
        segs = "|".join(f"{times[x][0]:%H:%M}-{times[x][1]:%H:%M}" for x in block)
        for g in groups:
            lessons.append(LessonDTO(g, day_at[r], 0, start, end, subject, "; ".join(teachers),
                                     ", ".join(rooms), "", detect_parity(raw_subject), "", segs))

    # защита от «склейки дней»: внутри одного дня время пар должно только расти
    by_day: dict[int, list[time]] = {}
    for l in lessons:
        by_day.setdefault(l.weekday, []).append(l.start)
    for wd, starts in by_day.items():
        if starts != sorted(starts):
            report.warnings.append(f"Лист «{key}»: в дне №{wd + 1} время пар идёт не по порядку — проверьте подписи дней")
    report.groups.update(groups)
    return lessons


def parse_workbook_ex(data: bytes, include_hidden: bool = False) -> tuple[list[LessonDTO], ParseReport]:
    wb = load_workbook(io.BytesIO(data), data_only=True)
    report = ParseReport()
    out: set[LessonDTO] = set()
    for ws in wb.worksheets:
        if ws.sheet_state != "visible" and not include_hidden:
            report.sheets_hidden.append(ws.title.strip())
            continue
        try:
            res = _parse_sheet(ws, report)
        except Exception:
            log.exception("Лист %r: ошибка разбора", ws.title)
            res = None
        if res is None:
            report.sheets_failed.append(ws.title.strip())
            continue
        report.sheets_ok.append(ws.title.strip())
        out.update(res)

    # порядковый номер пары в дне
    by_day: dict[tuple, list[LessonDTO]] = {}
    for l in out:
        by_day.setdefault((l.group, l.weekday), []).append(l)
    final: list[LessonDTO] = []
    for lst in by_day.values():
        for i, l in enumerate(sorted(lst, key=lambda x: (x.start, x.subject)), 1):
            final.append(LessonDTO(l.group, l.weekday, i, l.start, l.end, l.subject, l.teacher,
                                   l.room, l.kind, l.parity, l.subgroup, l.segments))
    final.sort(key=lambda l: (l.group, l.weekday, l.start, l.subject))
    return final, report


def parse_workbook(data: bytes) -> list[LessonDTO]:
    return parse_workbook_ex(data)[0]
