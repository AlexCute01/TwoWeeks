"""
«Умные» уведомления. run_due() вызывается каждые ~20 секунд и обрабатывает все ещё не обработанные
минуты (после перезапуска ничего не теряется — догоняем до 30 минут назад).

Масштаб: расписание лежит в памяти; на каждую минуту находим программы, у которых сейчас что-то
начинается/заканчивается, и берём из БД только нужных пользователей. Обхода «всех» нет.

Что делает:
  • напоминание перед парой — за N минут (5…60, настраивается), для первой пары дня — на M минут раньше;
  • «пара закончилась» + что дальше и сколько времени до неё;
  • «перемена» между академическими часами одной пары (по желанию);
  • утренняя и вечерняя сводки в выбранное время;
  • проверка расписания по слотам (06:00, 06:50, 07:40 … до 18:00) — один раз на слот;
  • ежедневный бэкап БД админам; ночная уборка.
"""
import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path

from sqlalchemy import and_, delete, or_, select

from . import access
from .backup import send_backup
from .cache import cache
from .config import FIRST_EXTRA_OPTIONS, REMIND_OPTIONS, settings
from .db import ChangeLog, Outbox, PersonalLesson, Session, User, meta_get, meta_set
from .fmt import building_of, date_label, fmt_dur, format_day, room_line
from .outbox import PRIO_DIGEST, PRIO_REMINDER, enqueue_many
from .schedule import day_items, rooms_map
from .sync import check_schedule
from .util import esc, norm_room, now_local, week_parity

log = logging.getLogger(__name__)
MAX_CATCHUP_MIN = 30
ALLOWED_MINS = set(REMIND_OPTIONS) | {r + e for r in REMIND_OPTIONS for e in FIRST_EXTRA_OPTIONS if e}
_tasks: set[asyncio.Task] = set()


def _bg(coro) -> None:
    """Фоновая задача с логированием ошибок (и без «потери» ссылки на неё)."""
    async def runner():
        try:
            await coro
        except Exception:
            log.exception("background task failed")
    t = asyncio.create_task(runner())
    _tasks.add(t)
    t.add_done_callback(_tasks.discard)


def _live():
    return (User.notify_enabled.is_(True), User.blocked.is_(False))


async def run_due(bot=None) -> None:
    now = now_local().replace(second=0, microsecond=0)
    try:
        hb = Path(settings.data_dir) / "heartbeat"
        hb.parent.mkdir(parents=True, exist_ok=True)
        hb.write_text(now.isoformat())          # по нему update.sh понимает, что новая версия жива
    except OSError:
        pass
    async with Session() as s:
        last = await meta_get(s, "last_tick")
    start = now
    if last:
        start = max(datetime.fromisoformat(last) + timedelta(minutes=1), now - timedelta(minutes=MAX_CATCHUP_MIN))
    m = start
    while m <= now:
        try:
            await process_minute(m, bot)
        except Exception:
            log.exception("process_minute %s", m)
        async with Session() as s:
            await meta_set(s, "last_tick", m.isoformat())
            await s.commit()
        m += timedelta(minutes=1)


def _find(day, l):
    return next((i for i, it in enumerate(day) if it.start == l.start and it.title == l.subject), None)


async def process_minute(m: datetime, bot=None) -> None:
    today, hhmm = m.date(), m.strftime("%H:%M")
    wd, parity = today.weekday(), week_parity(today)
    async with Session() as s:
        rooms = await rooms_map(s)
        items: list[dict] = []

        for gid, lessons in cache.groups_on(wd):
            active = [l for l in lessons if l.parity in (0, parity)]
            if not active:
                continue
            first_start = min(l.start for l in active)
            for l in active:
                mins = int((datetime.combine(today, l.start) - m).total_seconds() // 60)

                # 1) напоминание перед парой
                if mins in ALLOWED_MINS:
                    cond = User.remind_before == mins
                    if l.start == first_start:    # первая пара дня: «ранний» вариант (remind_before + first_extra)
                        cond = or_(cond, and_(User.first_extra > 0, User.remind_before + User.first_extra == mins))
                    for u in await s.scalars(select(User).where(User.group_id == gid, cond, *_live())):
                        it = await _reminder(s, u, l, m, mins, rooms)
                        if it:
                            items.append(it)

                # 2) пара закончилась
                if l.end == m.time():
                    for u in await s.scalars(select(User).where(User.group_id == gid, User.end_on.is_(True), *_live())):
                        it = await _end_msg(s, u, l, m, rooms)
                        if it:
                            items.append(it)

                # 3) перемена между академическими часами внутри пары
                for i, (_, seg_end) in enumerate(l.segments[:-1]):
                    if seg_end == m.time():
                        nxt_start = l.segments[i + 1][0]
                        for u in await s.scalars(select(User).where(User.group_id == gid, User.break_on.is_(True), *_live())):
                            day = await day_items(s, u, today)
                            if _find(day, l) is None:
                                continue
                            gap = (nxt_start.hour * 60 + nxt_start.minute) - (seg_end.hour * 60 + seg_end.minute)
                            text = (f"☕ <b>Перемена {fmt_dur(gap)}</b>\n"
                                    f"▶️ Продолжение в <b>{nxt_start:%H:%M}</b>: {esc(l.subject)}")
                            items.append(dict(user_id=u.tg_id, text=text, priority=PRIO_REMINDER,
                                              dedupe_key=f"brk:{u.tg_id}:{today}:{hhmm}",
                                              expires_at=m + timedelta(minutes=max(gap, 3))))

        # 4) личные события
        for lead in REMIND_OPTIONS:
            t = (m + timedelta(minutes=lead)).time()
            rows = await s.execute(
                select(PersonalLesson, User).join(User, User.tg_id == PersonalLesson.user_id).where(
                    PersonalLesson.weekday == wd, PersonalLesson.parity.in_((0, parity)),
                    PersonalLesson.start == t, User.remind_before == lead, *_live()))
            for pl, u in rows:
                text = (f"⏰ Через <b>{lead} мин</b>: ⭐ <b>{esc(pl.title)}</b>\n🕘 {pl.start:%H:%M}–{pl.end:%H:%M}"
                        + (f"\n📍 {room_line(pl.room, rooms)}" if pl.room else ""))
                items.append(dict(user_id=u.tg_id, text=text, priority=PRIO_REMINDER,
                                  dedupe_key=f"pre:{u.tg_id}:{today}:{pl.start:%H%M}:p{pl.id}",
                                  expires_at=datetime.combine(today, pl.start)))

        # 5) утренняя и вечерняя сводки (в выбранное пользователем время)
        t = m.time()
        for u in await s.scalars(select(User).where(User.morning_on.is_(True), User.morning_time == t,
                                                    User.blocked.is_(False))):
            day = await day_items(s, u, today)
            if day:
                head = (f"☀️ <b>Доброе утро!</b> Сегодня пар: {len(day)} "
                        f"(с {day[0].start:%H:%M} до {day[-1].end:%H:%M})\n\n")
                items.append(dict(user_id=u.tg_id, text=head + format_day(day, today, rooms, None, cache.title(u.group_id)),
                                  priority=PRIO_DIGEST, dedupe_key=f"am:{u.tg_id}:{today}"))
        for u in await s.scalars(select(User).where(User.evening_on.is_(True), User.evening_time == t,
                                                    User.blocked.is_(False))):
            tomorrow = today + timedelta(days=1)
            day = await day_items(s, u, tomorrow)
            if day:
                text = (f"🌙 <b>Завтра</b> — {date_label(tomorrow)}\n"
                        f"Пар: {len(day)}, первая в <b>{day[0].start:%H:%M}</b> — не забудь про будильник ⏰\n\n"
                        + format_day(day, tomorrow, rooms, None, cache.title(u.group_id)))
            else:
                text = f"🌙 <b>Завтра</b> — {date_label(tomorrow)}\nПар нет — можно выспаться 😴"
            items.append(dict(user_id=u.tg_id, text=text, priority=PRIO_DIGEST, dedupe_key=f"ev:{u.tg_id}:{today}"))

        await enqueue_many(s, items)

        # 6) проверка расписания — ровно один раз на каждый слот (06:00, 06:50, …, до 18:00)
        slot_key = f"{today} {hhmm}"
        if hhmm in settings.sync_slots() and await meta_get(s, "last_sync_slot") != slot_key:
            await meta_set(s, "last_sync_slot", slot_key)
            _bg(check_schedule(bot))

        # 7) бэкап и уборка
        if hhmm == settings.backup_time and await meta_get(s, "last_backup_day") != str(today):
            await meta_set(s, "last_backup_day", str(today))
            if bot:
                _bg(send_backup(bot, sorted(access.all_admins())))
        if hhmm == "04:00":
            await s.execute(delete(Outbox).where(Outbox.status != 0, Outbox.created_at < m - timedelta(days=3)))
            await s.execute(delete(ChangeLog).where(ChangeLog.created_at < m - timedelta(days=30)))
        await s.commit()


async def _reminder(s, u: User, l, m: datetime, mins: int, rooms) -> dict | None:
    """Точная проверка для конкретного пользователя (скрытые предметы, «первая пара», пары подряд)."""
    today = m.date()
    day = await day_items(s, u, today)
    idx = _find(day, l)
    if idx is None:
        return None                       # пара не его (скрыта)
    it, is_first = day[idx], idx == 0
    if mins > u.remind_before and not is_first:
        return None                       # «ранний» вариант годится только для первой пары дня

    prev = day[idx - 1] if idx else None
    if prev and prev.room and prev.room == it.room and (
            datetime.combine(today, it.start) - datetime.combine(today, prev.end)).total_seconds() <= 15 * 60:
        return None                       # идёт подряд в той же аудитории — напоминание не нужно

    lines = []
    if is_first:
        lines.append("🌅 <b>Первая пара сегодня</b>")
    lines.append(f"⏰ Через <b>{fmt_dur(mins)}</b>: <b>{esc(it.title)}</b>")
    lines.append(f"🕘 {it.start:%H:%M}–{it.end:%H:%M}" + (f" · {len(it.segs)} ак. ч" if len(it.segs) > 1 else ""))
    if it.room:
        lines.append(f"📍 {room_line(it.room, rooms)}")
        r = rooms.get(norm_room(it.room))
        if r and r.description:
            lines.append(f"<i>{esc(r.description)}</i>")
    if it.teacher:
        lines.append(f"👤 {esc(it.teacher)}")
    if prev:
        pb, nb = building_of(prev.room, rooms), building_of(it.room, rooms)
        if pb and nb and pb != nb:
            lines.append(f"🚶 <b>Смена корпуса</b>: {esc(pb)} → {esc(nb)}. Не задерживайся!")
    if idx == len(day) - 1 and len(day) > 1:
        lines.append("🏁 Это последняя пара на сегодня")
    return dict(user_id=u.tg_id, text="\n".join(lines), priority=PRIO_REMINDER,
                dedupe_key=f"pre:{u.tg_id}:{today}:{it.start:%H%M}",
                expires_at=datetime.combine(today, it.start))


async def _end_msg(s, u: User, l, m: datetime, rooms) -> dict | None:
    today = m.date()
    day = await day_items(s, u, today)
    idx = _find(day, l)
    if idx is None:
        return None
    nxt = day[idx + 1] if idx + 1 < len(day) else None
    lines = [f"✅ <b>Пара закончилась</b>: {esc(l.subject)}"]
    if nxt:
        gap = (nxt.start.hour * 60 + nxt.start.minute) - (l.end.hour * 60 + l.end.minute)
        lines += ["", f"⏭ Дальше: <b>{esc(nxt.title)}</b>",
                  f"🕘 {nxt.start:%H:%M} — через <b>{fmt_dur(gap)}</b>"]
        if nxt.room:
            lines.append(f"📍 {room_line(nxt.room, rooms)}")
        pb, nb = building_of(day[idx].room, rooms), building_of(nxt.room, rooms)
        if pb and nb and pb != nb:
            lines.append(f"🚶 Смена корпуса: {esc(pb)} → {esc(nb)}")
    else:
        lines += ["", "🏁 На сегодня занятия закончились — хорошего вечера!"]
    return dict(user_id=u.tg_id, text="\n".join(lines), priority=PRIO_REMINDER,
                dedupe_key=f"end:{u.tg_id}:{today}:{l.end:%H%M}", expires_at=m + timedelta(minutes=40))
