"""
«Умные» напоминания. run_due() вызывается каждые ~20 секунд и обрабатывает все ещё не
обработанные минуты (так после перезапуска ничего не пропадает — максимум за 30 минут).

Как это масштабируется: расписание лежит в памяти, поэтому на каждую минуту мы за микросекунды
находим группы, у которых через 5/10/15/30 минут начинается пара, и запрашиваем в БД только
тех пользователей этих групп, кто выбрал именно такое время напоминания. Никакого «обхода всех».

Что умеет:
  • напоминание перед парой (за N минут, настраивается);
  • перед ПЕРВОЙ парой дня — раньше на FIRST_PAIR_EXTRA_MIN (время на сборы);
  • не дёргает, если следующая пара идёт подряд в той же аудитории;
  • предупреждает о смене корпуса и показывает, как найти аудиторию;
  • утренняя сводка и вечерняя сводка на завтра.
"""
import logging
from datetime import datetime, timedelta

from sqlalchemy import delete, select

from .cache import cache
from .config import FIRST_PAIR_EXTRA_MIN, LEADS
from .db import ChangeLog, Outbox, PersonalLesson, Session, User, meta_get, meta_set
from .outbox import PRIO_DIGEST, PRIO_REMINDER, enqueue_many
from .schedule import building_of, date_label, day_items, format_day, room_line, rooms_map
from .util import esc, norm_room, now_local, parity_name, week_parity

log = logging.getLogger(__name__)
MAX_CATCHUP_MIN = 30


def _active():
    """Условия: пользователю можно слать напоминания."""
    return (User.notify_enabled.is_(True), User.blocked.is_(False))


async def run_due() -> None:
    now = now_local().replace(second=0, microsecond=0)
    async with Session() as s:
        last = await meta_get(s, "last_tick")
    start = now
    if last:
        start = max(datetime.fromisoformat(last) + timedelta(minutes=1), now - timedelta(minutes=MAX_CATCHUP_MIN))
    m = start
    while m <= now:
        try:
            await process_minute(m)
        except Exception:
            log.exception("process_minute %s", m)
        async with Session() as s:
            await meta_set(s, "last_tick", m.isoformat())
            await s.commit()
        m += timedelta(minutes=1)


async def process_minute(m: datetime) -> None:
    today = m.date()
    wd, parity = today.weekday(), week_parity(today)
    async with Session() as s:
        rooms = await rooms_map(s)
        items: list[dict] = []

        # 1) напоминания о парах из общего расписания
        for gid, lessons in cache.groups_on(wd):
            active = [l for l in lessons if l.parity in (0, parity)]
            if not active:
                continue
            first_start = min(l.start for l in active)
            for l in active:
                mins = int((datetime.combine(today, l.start) - m).total_seconds() // 60)
                leads = set()
                if mins in LEADS:
                    leads.add(mins)
                if l.start == first_start and (mins - FIRST_PAIR_EXTRA_MIN) in LEADS:
                    leads.add(mins - FIRST_PAIR_EXTRA_MIN)   # «ранний» вариант для первой пары
                for lead in leads:
                    users = await s.scalars(select(User).where(
                        User.group_id == gid, User.remind_before == lead, *_active()))
                    for u in users:
                        it = await _reminder(s, u, l, m, mins, rooms)
                        if it:
                            items.append(it)

        # 2) напоминания о личных событиях
        for lead in LEADS:
            t = (m + timedelta(minutes=lead)).time()
            rows = await s.execute(
                select(PersonalLesson, User).join(User, User.tg_id == PersonalLesson.user_id).where(
                    PersonalLesson.weekday == wd, PersonalLesson.parity.in_((0, parity)),
                    PersonalLesson.start == t, User.remind_before == lead, *_active()))
            for pl, u in rows:
                text = (f"⏰ Через <b>{lead} мин</b>: ⭐ <b>{esc(pl.title)}</b>\n🕘 {pl.start:%H:%M}–{pl.end:%H:%M}"
                        + (f"\n📍 {room_line(pl.room, rooms)}" if pl.room else ""))
                items.append(dict(user_id=u.tg_id, text=text, priority=PRIO_REMINDER,
                                  dedupe_key=f"pre:{u.tg_id}:{today}:{pl.start:%H%M}:p{pl.id}",
                                  expires_at=datetime.combine(today, pl.start)))

        # 3) утренняя и вечерняя сводки
        t = m.time()
        for u in await s.scalars(select(User).where(User.morning_on.is_(True), User.morning_time == t, *_active())):
            day = await day_items(s, u, today)
            if day:
                span = f"с {day[0].start:%H:%M} до {day[-1].end:%H:%M}"
                head = f"☀️ <b>Доброе утро!</b> Сегодня пар: {len(day)} ({span})\n\n"
                items.append(dict(user_id=u.tg_id, text=head + format_day(day, today, rooms),
                                  priority=PRIO_DIGEST, dedupe_key=f"am:{u.tg_id}:{today}"))
        for u in await s.scalars(select(User).where(User.evening_on.is_(True), User.evening_time == t, *_active())):
            tomorrow = today + timedelta(days=1)
            day = await day_items(s, u, tomorrow)
            lines = [f"🌙 <b>Завтра</b> — {date_label(tomorrow)}"]
            if tomorrow.weekday() == 0:
                lines.append(f"Новая неделя: <i>{parity_name(week_parity(tomorrow))}</i>")
            if day:
                lines.append(f"Пар: {len(day)}, первая в <b>{day[0].start:%H:%M}</b> — не забудь про будильник ⏰\n")
                lines.append(format_day(day, tomorrow, rooms))
            else:
                lines.append("Пар нет — можно выспаться 😴")
            items.append(dict(user_id=u.tg_id, text="\n".join(lines), priority=PRIO_DIGEST,
                              dedupe_key=f"ev:{u.tg_id}:{today}"))

        await enqueue_many(s, items)

        # 4) ночная уборка
        if m.hour == 4 and m.minute == 0:
            await s.execute(delete(Outbox).where(Outbox.status != 0, Outbox.created_at < m - timedelta(days=3)))
            await s.execute(delete(ChangeLog).where(ChangeLog.created_at < m - timedelta(days=30)))
        await s.commit()


async def _reminder(s, u: User, l, m: datetime, mins: int, rooms) -> dict | None:
    """Точная проверка для конкретного пользователя (подгруппа, скрытые предметы, «первая пара», соседи)."""
    today = m.date()
    day = await day_items(s, u, today)
    idx = next((i for i, it in enumerate(day) if it.start == l.start and it.title == l.subject), None)
    if idx is None:
        return None                       # пара не его (другая подгруппа / скрыта)
    it, is_first = day[idx], idx == 0
    if mins > u.remind_before and not is_first:
        return None                       # «ранний» вариант годится только для первой пары дня

    prev = day[idx - 1] if idx else None
    if prev and prev.room and prev.room == it.room and (
            datetime.combine(today, it.start) - datetime.combine(today, prev.end)).total_seconds() <= 15 * 60:
        return None                       # идёт подряд в той же аудитории — напоминание не нужно

    lines = []
    if is_first:
        lines.append("🌅 <b>Первая пара сегодня</b>")
    lines.append(f"⏰ Через <b>{max(1, mins)} мин</b>: <b>{esc(it.title)}</b>")
    lines.append(f"🕘 {it.start:%H:%M}–{it.end:%H:%M}" + (f" · {esc(it.kind)}" if it.kind else ""))
    if it.room:
        lines.append(f"📍 {room_line(it.room, rooms)}")
        r = rooms.get(norm_room(it.room))
        if r and r.description:
            lines.append(f"<i>{esc(r.description)}</i>")
    if it.teacher:
        lines.append(f"👤 {esc(it.teacher)}")
    if prev:
        pb, nb = building_of(prev.room, rooms), building_of(it.room, rooms)
        if pb and nb and pb != nb:
            lines.append(f"🚶 <b>Смена корпуса</b>: {esc(pb)} → {esc(nb)}. Не задерживайся!")
    if idx == len(day) - 1 and len(day) > 1:
        lines.append("🏁 Это последняя пара на сегодня")
    return dict(user_id=u.tg_id, text="\n".join(lines), priority=PRIO_REMINDER,
                dedupe_key=f"pre:{u.tg_id}:{today}:{it.start:%H%M}",
                expires_at=datetime.combine(today, it.start))
