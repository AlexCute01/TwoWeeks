"""Клавиатуры и тексты кнопок."""
from datetime import date, timedelta

from aiogram.types import KeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from .util import WEEKDAYS_SHORT

BTN_TODAY, BTN_TOMORROW = "📅 Сегодня", "📆 Завтра"
BTN_WEEK, BTN_NEXT = "🗓 Неделя", "⏭ Ближайшая пара"
BTN_NEWS, BTN_SETTINGS, BTN_ADMIN = "📰 Новости", "⚙️ Настройки", "🛠 Админ"
MENU_TEXTS = {BTN_TODAY, BTN_TOMORROW, BTN_WEEK, BTN_NEXT, BTN_NEWS, BTN_SETTINGS, BTN_ADMIN}


def main_menu(admin: bool = False):
    kb = ReplyKeyboardBuilder()
    kb.row(KeyboardButton(text=BTN_TODAY), KeyboardButton(text=BTN_TOMORROW))
    kb.row(KeyboardButton(text=BTN_WEEK), KeyboardButton(text=BTN_NEXT))
    kb.row(KeyboardButton(text=BTN_NEWS), KeyboardButton(text=BTN_SETTINGS))
    if admin:
        kb.row(KeyboardButton(text=BTN_ADMIN))
    return kb.as_markup(resize_keyboard=True, input_field_placeholder="Выбери действие 👇")


def _chips(kb, monday: date, selected: date | None, today: date) -> None:
    for i in range(6):
        x = monday + timedelta(days=i)
        label = WEEKDAYS_SHORT[i]
        label = f"【{label}】" if x == selected else (f"•{label}" if x == today else label)
        kb.button(text=label, callback_data=f"d:{x}")


def day_kb(d: date, today: date):
    monday = d - timedelta(days=d.weekday())
    kb = InlineKeyboardBuilder()
    _chips(kb, monday, d, today)
    kb.button(text="◀️", callback_data=f"d:{d - timedelta(days=1)}")
    kb.button(text="Сегодня", callback_data=f"d:{today}")
    kb.button(text="▶️", callback_data=f"d:{d + timedelta(days=1)}")
    kb.button(text="🗓 Неделя", callback_data=f"w:{monday}")
    kb.button(text="⏭ Ближайшая", callback_data="nx")
    kb.adjust(6, 3, 2)
    return kb.as_markup()


def week_kb(monday: date, today: date):
    kb = InlineKeyboardBuilder()
    _chips(kb, monday, None, today)
    kb.button(text="◀️ Пред. неделя", callback_data=f"w:{monday - timedelta(days=7)}")
    kb.button(text="След. неделя ▶️", callback_data=f"w:{monday + timedelta(days=7)}")
    kb.adjust(6, 2)
    return kb.as_markup()


def back_kb(target: str, text: str = "⬅️ Назад"):
    kb = InlineKeyboardBuilder()
    kb.button(text=text, callback_data=target)
    return kb.as_markup()
