"""Админ-панель: проверка расписания, админы, посты в ленту новостей, статистика, бэкап."""
import io
import logging

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import CallbackQuery, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select

from . import access
from .backup import send_backup
from .common import InState, reply, set_state
from .config import settings
from .db import Group, Lesson, Outbox, Post, Room, Session, User, meta_get
from .outbox import PRIO_ADMIN, PRIO_NEWS, enqueue, enqueue_many
from .programs import DEPTS
from .sync import apply_data, check_schedule
from .ui import BTN_ADMIN, back_kb
from .util import esc, norm_room, now_local

log = logging.getLogger(__name__)
router = Router()


def _deny(c: CallbackQuery | Message) -> bool:
    return not access.is_admin(c.from_user.id)


# ───────────────────────── главная ─────────────────────────

async def admin_home(target):
    async with Session() as s:
        users = await s.scalar(select(func.count()).select_from(User))
        pending = await s.scalar(select(func.count()).select_from(Outbox).where(Outbox.status == 0))
        last_check = await meta_get(s, "last_check")
        applied = await meta_get(s, "applied_at")
    text = (
        "🛠 <b>Админ-панель</b>\n\n"
        f"👥 Пользователей: <b>{users}</b> · 📨 в очереди: {pending}\n"
        f"🕘 Последняя проверка: {esc(last_check or '—')}\n"
        f"📋 Расписание обновлено: {esc(applied[:16].replace('T', ' ')) if applied else '—'}")
    kb = InlineKeyboardBuilder()
    kb.button(text="🔄 Запросить актуальное расписание", callback_data="ad:sync")
    kb.button(text="📰 Новый пост в ленту", callback_data="ad:post")
    kb.button(text="👥 Админы", callback_data="ad:admins")
    kb.button(text="📊 Статистика", callback_data="ad:stats")
    kb.button(text="💾 Бэкап базы", callback_data="ad:backup")
    kb.button(text="📚 Посты", callback_data="ad:posts")
    kb.adjust(1, 1, 2, 2)
    await reply(target, text, kb.as_markup())


@router.message(Command("admin"))
@router.message(F.text == BTN_ADMIN)
async def m_admin(m: Message):
    if _deny(m):
        return
    await set_state(m.from_user.id)
    await admin_home(m)


@router.callback_query(F.data == "ad:home")
async def cb_home(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id)
    await admin_home(c)


# ───────────────────────── расписание ─────────────────────────

@router.callback_query(F.data.in_({"ad:sync", "ad:syncf"}))
async def cb_sync(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    force = c.data == "ad:syncf"
    await reply(c, "⏳ Скачиваю таблицу и сравниваю с текущим расписанием…\n<i>разбор занимает до минуты</i>")
    res = await check_schedule(bot, force=force)
    kb = InlineKeyboardBuilder()
    if not force:
        kb.button(text="🔁 Применить заново принудительно", callback_data="ad:syncf")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    await c.message.edit_text(f"<b>Результат проверки</b>\n\n{esc(res)}", reply_markup=kb.as_markup())


@router.message(Command("sync"))
async def cmd_sync(m: Message, bot: Bot):
    if _deny(m):
        return
    wait = await m.answer("⏳ Проверяю расписание…")
    res = await check_schedule(bot, force=False)
    await wait.edit_text(f"<b>Результат проверки</b>\n\n{esc(res)}")


@router.message(F.document)
async def on_document(m: Message, bot: Bot):
    """Админ прислал .xlsx — применяем принудительно (например, если ссылка закрыта)."""
    if _deny(m):
        return
    if not (m.document.file_name or "").lower().endswith((".xlsx", ".xlsm")):
        await m.answer("Нужен файл .xlsx")
        return
    wait = await m.answer("⏳ Разбираю файл…")
    buf = io.BytesIO()
    await bot.download(m.document, destination=buf)
    res = await apply_data(buf.getvalue(), bot, force=True)
    await wait.edit_text(f"<b>Файл обработан</b>\n\n{esc(res)}")


# ───────────────────────── админы ─────────────────────────

async def _names(ids: set[int]) -> dict[int, str]:
    async with Session() as s:
        rows = await s.execute(select(User.tg_id, User.username, User.full_name).where(User.tg_id.in_(ids or {0})))
    out = {i: str(i) for i in ids}
    for i, un, fn in rows:
        out[i] = (f"{fn} (@{un})" if un else fn) or str(i)
    return out


async def show_admins(c: CallbackQuery):
    owners, extra = sorted(settings.owners), sorted(access.extra_admins())
    names = await _names(set(owners) | set(extra))
    lines = ["👥 <b>Админы</b>", "", "👑 <b>Владельцы</b> (из настроек сервера):"]
    lines += [f"• {esc(names[i])} · <code>{i}</code>" for i in owners] or ["—"]
    lines += ["", "🛠 <b>Админы</b> (добавлены через бота):"]
    lines += [f"• {esc(names[i])} · <code>{i}</code>" for i in extra] or ["пока нет"]
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Добавить админа", callback_data="ad:addadm")
    if access.is_owner(c.from_user.id):
        for i in extra:
            kb.button(text=f"➖ Убрать: {names[i][:24]}", callback_data=f"ad:deladm:{i}")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    await reply(c, "\n".join(lines), kb.as_markup())


@router.callback_query(F.data == "ad:admins")
async def cb_admins(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await show_admins(c)


@router.callback_query(F.data == "ad:addadm")
async def cb_add_admin(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id, "adm_add")
    await reply(c, "➕ <b>Новый админ</b>\n\nПришли одно из:\n"
                   "• <b>Telegram ID</b> (число; узнать можно у @userinfobot)\n"
                   "• <b>@username</b> — если человек уже запускал этого бота\n"
                   "• любое <b>пересланное сообщение</b> от него\n\n"
                   "Человеку нужно хотя бы раз нажать /start в этом боте.",
                back_kb("ad:admins", "⬅️ Отмена"))


def _forwarded_id(m: Message) -> int | None:
    fo = getattr(m, "forward_origin", None)
    if fo is not None and getattr(fo, "type", "") == "user":
        return fo.sender_user.id
    ff = getattr(m, "forward_from", None)
    return ff.id if ff else None


@router.message(InState("adm_add"))
async def on_add_admin(m: Message):
    if _deny(m):
        return
    uid = _forwarded_id(m)
    text = (m.text or "").strip()
    if uid is None and text.lstrip("-").isdigit():
        uid = int(text)
    if uid is None and text.startswith("@"):
        async with Session() as s:
            uid = await s.scalar(select(User.tg_id).where(func.lower(User.username) == text[1:].lower()))
        if uid is None:
            await m.answer("Не знаю такого @username 🤷 Пусть человек сначала нажмёт /start в боте, "
                           "или пришли его Telegram ID.")
            return
    if uid is None:
        await m.answer("Не смог определить пользователя. Пришли ID, @username или пересланное сообщение "
                       "(если у человека скрыта пересылка — используй ID). /cancel — отмена.")
        return
    async with Session() as s:
        known = await s.get(User, uid)
    added = await access.add_admin(uid, m.from_user.id)
    await set_state(m.from_user.id)
    if not added:
        await m.answer("Он уже админ 👌")
        return
    await enqueue(uid, "🛠 <b>Вас назначили администратором бота.</b>\nПанель — кнопка «🛠 Админ» или /admin. "
                       "Если кнопки нет, нажмите /start.", priority=PRIO_ADMIN, dedupe_key=f"newadm:{uid}:{now_local():%Y%m%d%H%M}")
    warn = "" if known else "\n⚠️ Он ещё не запускал бота — пусть нажмёт /start, тогда получит уведомление и кнопку."
    await m.answer(f"✅ Добавлен админ <code>{uid}</code>{warn}")


@router.callback_query(F.data.startswith("ad:deladm:"))
async def cb_del_admin(c: CallbackQuery):
    if not access.is_owner(c.from_user.id):
        return await c.answer("Убирать админов могут только владельцы", show_alert=True)
    await access.remove_admin(int(c.data.split(":")[2]))
    await show_admins(c)


# ───────────────────────── статистика / бэкап ─────────────────────────

@router.callback_query(F.data == "ad:stats")
async def cb_stats(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await reply(c, await stats_text(), back_kb("ad:home", "⬅️ В админку"))


async def stats_text() -> str:
    async with Session() as s:
        users = await s.scalar(select(func.count()).select_from(User))
        with_group = await s.scalar(select(func.count()).select_from(User).where(User.group_id.is_not(None)))
        blocked = await s.scalar(select(func.count()).select_from(User).where(User.blocked.is_(True)))
        news_off = await s.scalar(select(func.count()).select_from(User).where(User.news_on.is_(False)))
        groups = await s.scalar(select(func.count()).select_from(Group))
        lessons = await s.scalar(select(func.count()).select_from(Lesson))
        pending = await s.scalar(select(func.count()).select_from(Outbox).where(Outbox.status == 0))
        fails = await meta_get(s, "fail_count")
        top = (await s.execute(select(Group.title, func.count(User.tg_id)).join(User, User.group_id == Group.id)
                               .group_by(Group.id).order_by(func.count(User.tg_id).desc()).limit(8))).all()
    lines = ["📊 <b>Статистика</b>", "",
             f"👥 Пользователей: <b>{users}</b> (с группой: {with_group})",
             f"🚫 Заблокировали бота: {blocked} · 🔕 отказались от новостей: {news_off}",
             f"📚 Программ: {groups} · пар: {lessons}",
             f"📨 В очереди на отправку: {pending}",
             f"⚠️ Неудачных скачиваний подряд: {fails or 0}"]
    if top:
        lines += ["", "<b>Больше всего студентов:</b>"] + [f"• {esc(t)} — {n}" for t, n in top]
    return "\n".join(lines)


@router.message(Command("stats"))
async def cmd_stats(m: Message):
    if _deny(m):
        return
    await m.answer(await stats_text())


@router.callback_query(F.data == "ad:backup")
async def cb_backup(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    await c.answer("Делаю бэкап…")
    n = await send_backup(bot, [c.from_user.id], "💾 Резервная копия по запросу")
    await c.message.answer("✅ Бэкап отправлен выше 👆" if n else "❌ Не получилось сделать бэкап (см. логи)")


@router.message(Command("backup"))
async def cmd_backup(m: Message, bot: Bot):
    if _deny(m):
        return
    n = await send_backup(bot, [m.from_user.id], "💾 Резервная копия по запросу")
    await m.answer("✅ Готово" if n else "❌ Не получилось сделать бэкап (см. логи)")


# ───────────────────────── лента новостей ─────────────────────────

async def _audience(s, post: Post) -> list[int]:
    q = select(User.tg_id).where(User.news_on.is_(True), User.blocked.is_(False))
    if post.target_group_id:
        q = q.where(User.group_id == post.target_group_id)
    return list(await s.scalars(q))


@router.callback_query(F.data == "ad:post")
async def cb_post(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id, "post_compose")
    await reply(c, "📰 <b>Новый пост</b>\n\nПришли сообщение, которое нужно разослать: текст, фото, видео или файл "
                   "(с подписью). Придёт всем в том же виде. Форматирование (жирный, ссылки) сохранится.\n\n"
                   "Перед отправкой покажу превью и спрошу подтверждение.",
                back_kb("ad:home", "⬅️ Отмена"))


@router.message(InState("post_compose"))
async def on_post_compose(m: Message, bot: Bot):
    if _deny(m):
        return
    async with Session() as s:
        post = Post(author_id=m.from_user.id, src_chat_id=m.chat.id, src_message_id=m.message_id,
                    status="draft", created_at=now_local())
        s.add(post)
        await s.commit()
        pid, n = post.id, len(await _audience(s, post))
    await set_state(m.from_user.id)
    await m.answer("👆 <b>Так увидят студенты.</b>")
    await bot.copy_message(m.chat.id, m.chat.id, m.message_id)
    await _post_menu(m, pid, n)


async def _post_menu(target, pid: int, n: int | None = None):
    async with Session() as s:
        post = await s.get(Post, pid)
        n = len(await _audience(s, post)) if n is None else n
        title = (await s.get(Group, post.target_group_id)).title if post.target_group_id else None
    kb = InlineKeyboardBuilder()
    kb.button(text=f"✅ Отправить: {title or 'всем'} ({n})", callback_data=f"ad:pconf:{pid}")
    if not post.target_group_id:
        kb.button(text="🎯 Только одной группе", callback_data=f"ad:pt:{pid}")
    else:
        kb.button(text="👥 Вернуть «всем»", callback_data=f"ad:pall:{pid}")
    kb.button(text="🗑 Отменить пост", callback_data=f"ad:pdel:{pid}")
    kb.adjust(1)
    text = (f"Получателей: <b>{n}</b> (кто не отписался от новостей)" +
            (f"\nЦель: <b>{esc(title)}</b>" if title else "\nЦель: <b>все студенты</b>"))
    if isinstance(target, CallbackQuery):
        await reply(target, text, kb.as_markup())
    else:
        await target.answer(text, reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("ad:pall:"))
async def cb_post_all(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        post = await s.get(Post, pid)
        post.target_group_id = None
        await s.commit()
    await _post_menu(c, pid)


@router.callback_query(F.data.startswith("ad:pt:"))
async def cb_post_target(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    kb = InlineKeyboardBuilder()
    for key, label in DEPTS.items():
        if key:
            kb.button(text=label, callback_data=f"ad:pd:{pid}:{key}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pall:{pid}")
    kb.adjust(1)
    await reply(c, "Выбери отделение:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:pd:"))
async def cb_post_dept(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, pid, dept = c.data.split(":")
    async with Session() as s:
        groups = list(await s.scalars(select(Group).where(Group.dept == dept).order_by(Group.title)))
    kb = InlineKeyboardBuilder()
    for g in groups:
        kb.button(text=(g.title or g.name)[:40], callback_data=f"ad:pg:{pid}:{g.id}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pt:{pid}")
    kb.adjust(1)
    await reply(c, "Выбери программу:", kb.as_markup())


@router.callback_query(F.data.startswith("ad:pg:"))
async def cb_post_group(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, pid, gid = c.data.split(":")
    async with Session() as s:
        post = await s.get(Post, int(pid))
        post.target_group_id = int(gid)
        await s.commit()
    await _post_menu(c, int(pid))


@router.callback_query(F.data.startswith("ad:pconf:"))
async def cb_post_confirm(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        post = await s.get(Post, pid)
        n = len(await _audience(s, post))
    kb = InlineKeyboardBuilder()
    kb.button(text=f"🚀 Да, отправить ({n})", callback_data=f"ad:psend:{pid}")
    kb.button(text="⬅️ Назад", callback_data=f"ad:pall:{pid}" if not post.target_group_id else f"ad:pg:{pid}:{post.target_group_id}")
    kb.adjust(1)
    await reply(c, f"⚠️ Отправить пост <b>{n}</b> получателям? Отменить рассылку после отправки нельзя.", kb.as_markup())


@router.callback_query(F.data.startswith("ad:psend:"))
async def cb_post_send(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    pid = int(c.data.split(":")[2])
    async with Session() as s:
        post = await s.get(Post, pid)
        if post.status == "sent":
            return await c.answer("Этот пост уже отправлен", show_alert=True)
        ids = await _audience(s, post)
        items = [dict(user_id=uid, src_chat_id=post.src_chat_id, src_message_id=post.src_message_id,
                      priority=PRIO_NEWS, dedupe_key=f"post:{pid}:{uid}") for uid in ids]
        queued = await enqueue_many(s, items)
        post.status, post.sent_count = "sent", queued
        await s.commit()
    eta = max(1, queued // 25)
    await reply(c, f"🚀 <b>Рассылка запущена</b>: {queued} получателей.\nДоставка займёт ~{eta} сек. "
                   "Пост также доступен в «📰 Новости».", back_kb("ad:home", "⬅️ В админку"))


@router.callback_query(F.data.startswith("ad:pdel:"))
async def cb_post_del(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    async with Session() as s:
        post = await s.get(Post, int(c.data.split(":")[2]))
        if post and post.status == "draft":
            await s.delete(post)
            await s.commit()
    await admin_home(c)


@router.callback_query(F.data == "ad:posts")
async def cb_posts(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    async with Session() as s:
        posts = list(await s.scalars(select(Post).where(Post.status == "sent").order_by(Post.id.desc()).limit(10)))
    lines = ["📚 <b>Последние посты</b>", ""]
    for p in posts:
        lines.append(f"• {p.created_at:%d.%m %H:%M} — получателей: {p.sent_count}"
                     + (" · по группе" if p.target_group_id else ""))
    if not posts:
        lines.append("Пока ничего не отправляли.")
    await reply(c, "\n".join(lines), back_kb("ad:home", "⬅️ В админку"))


# ───────────────────────── аудитории ─────────────────────────

@router.message(Command("setroom"))
async def cmd_setroom(m: Message, command: CommandObject):
    """/setroom 305 | Главный корпус | 3 | Лифт слева, налево от буфета"""
    if _deny(m):
        return
    parts = [p.strip() for p in (command.args or "").split("|")]
    if len(parts) < 2 or not parts[0]:
        await m.answer("Формат: <code>/setroom 305 | Главный корпус | 3 | описание</code>")
        return
    floor = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None
    async with Session() as s:
        code = norm_room(parts[0])
        r = await s.get(Room, code) or Room(code=code)
        r.building, r.floor = parts[1], floor
        r.description = parts[3] if len(parts) > 3 else r.description or ""
        s.add(r)
        await s.commit()
    await m.answer("Сохранил ✅")
