"""Админ-панель (ядро): главная, проверка расписания, загрузка файла с предпросмотром, админы, статистика, бэкап."""
import io
import logging
import secrets
from datetime import timedelta
from pathlib import Path

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sqlalchemy import func, select

from . import access
from .backup import send_backup
from .common import InState, eat, ephemeral, set_state, show
from .config import COURSES, settings
from .db import Group, Lesson, Outbox, Session, User, meta_get
from .outbox import PRIO_ADMIN, enqueue
from .sync import apply_data, check_schedule, course_from_filename
from .ui import BTN_ADMIN, back_kb
from .util import esc, now_local
from .version import __version__

log = logging.getLogger(__name__)
router = Router()
B = InlineKeyboardButton


def _deny(ev) -> bool:
    return not access.is_admin(ev.from_user.id)


def uploads_dir() -> Path:
    d = Path(settings.data_dir) / "state" / "uploads"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ───────────────────────── главная ─────────────────────────

async def admin_home(target):
    async with Session() as s:
        users = await s.scalar(select(func.count()).select_from(User))
        active = await s.scalar(select(func.count()).select_from(User).where(User.last_seen >= now_local() - timedelta(days=7)))
        pending = await s.scalar(select(func.count()).select_from(Outbox).where(Outbox.status == 0))
        last_check = await meta_get(s, "last_check")
        applied = {c: await meta_get(s, f"applied:{c}") for c in COURSES}
    urls = settings.course_urls()
    cl = "\n".join(f"   {c} курс: " + (applied[c][:16].replace("T", " ") if applied[c] else "—") +
                   ("" if c in urls else " (нет ссылки)") for c in COURSES)
    text = (f"🛠 <b>Админ-панель</b> · v{__version__}\n\n"
            f"👥 Пользователей: <b>{users}</b> · активны за 7 дней: <b>{active}</b> · 📨 в очереди: {pending}\n"
            f"🕘 Последняя проверка: {esc(last_check or '—')}\n"
            f"📋 Расписание обновлено:\n{cl}\n\n"
            "<i>Чтобы обновить расписание, просто пришли сюда .xlsx — покажу, что изменится, и спрошу подтверждение.</i>")
    kb = InlineKeyboardBuilder()
    kb.button(text="🔄 Запросить актуальное расписание", callback_data="ad:sync")
    kb.button(text="🗓 Редактор расписания", callback_data="ed:home")
    kb.button(text="📰 Новый пост", callback_data="ad:post")
    kb.button(text="📚 Посты и лента", callback_data="ad:posts:0")
    kb.button(text="👥 Пользователи", callback_data="ad:users:0")
    kb.button(text="🏫 Аудитории", callback_data="ad:rooms:0")
    kb.button(text="🛡 Админы", callback_data="ad:admins")
    kb.button(text="📊 Статистика", callback_data="ad:stats")
    kb.button(text="💾 Бэкап", callback_data="ad:backup")
    kb.adjust(1, 1, 2, 2, 2, 1)
    await show(target, text, kb.as_markup())


@router.message(Command("admin"))
@router.message(F.text == BTN_ADMIN)
async def m_admin(m: Message):
    if _deny(m):
        return
    await set_state(m.from_user.id)
    await admin_home(m)


@router.callback_query(F.data == "ad:home")
async def cb_home(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id)
    await admin_home(c)


# ───────────────────────── запрос расписания по ссылке ─────────────────────────

@router.callback_query(F.data == "ad:sync")
async def cb_sync_menu(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    urls = settings.course_urls()
    kb = InlineKeyboardBuilder()
    if urls:
        kb.button(text="🔄 Все курсы", callback_data="ad:syncgo:0:0")
        for cc in sorted(urls):
            kb.button(text=f"📘 {cc} курс", callback_data=f"ad:syncgo:{cc}:0")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1, 3, 1)
    note = ("Бот скачает таблицы по ссылкам и применит изменения; студентам уйдут уведомления только о том, "
            "что изменилось.") if urls else "⚠️ Ссылки на таблицы не заданы — используйте загрузку файла."
    await show(c, f"🔄 <b>Запросить актуальное расписание</b>\n\n{note}\n\n"
                  "Автоматически бот сам проверяет с 06:00 до 18:00 каждые 50 минут.", kb.as_markup())


@router.callback_query(F.data.startswith("ad:syncgo:"))
async def cb_sync_go(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    _, _, course, force = c.data.split(":")
    await show(c, "⏳ Скачиваю таблицу и сравниваю с текущим расписанием…\n<i>разбор занимает до минуты на курс</i>")
    res = await check_schedule(bot, force=bool(int(force)), courses=[int(course)] if int(course) else None)
    kb = InlineKeyboardBuilder()
    kb.button(text="🔁 Применить заново принудительно", callback_data=f"ad:syncgo:{course}:1")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    await show(c, f"<b>Результат проверки</b>\n\n{res}", kb.as_markup())


@router.message(Command("sync"))
async def cmd_sync(m: Message, bot: Bot):
    if _deny(m):
        return
    await show(m, "⏳ Проверяю расписание…")
    res = await check_schedule(bot, force=False)
    await show(m, f"<b>Результат проверки</b>\n\n{res}", back_kb("ad:home", "⬅️ В админку"), delete_src=False)


# ───────────────────────── загрузка файла (.xlsx — расписание, .zip — обновление бота) ─────────────────────────

@router.message(F.document)
async def on_document(m: Message, bot: Bot):
    if _deny(m):
        return
    name = (m.document.file_name or "")
    low = name.lower()
    if low.endswith(".zip"):
        from .updater import handle_zip
        return await handle_zip(m, bot)
    if not low.endswith((".xlsx", ".xlsm")):
        await eat(m)
        await ephemeral(m, "Пришли <b>.xlsx</b> (расписание курса) или <b>.zip</b> (обновление бота).", 7)
        return
    buf = io.BytesIO()
    await bot.download(m.document, destination=buf)
    token = secrets.token_hex(4)
    (uploads_dir() / f"{token}.xlsx").write_bytes(buf.getvalue())
    await show(m, "⏳ Разбираю файл и сравниваю с текущим расписанием…")
    course = course_from_filename(name)
    if course not in COURSES:
        kb = InlineKeyboardBuilder()
        for cc in COURSES:
            kb.button(text=f"📘 {cc} курс", callback_data=f"up:c:{token}:{cc}")
        kb.button(text="❌ Отмена", callback_data=f"up:no:{token}")
        kb.adjust(3, 1)
        await show(m, f"📥 Файл «{esc(name)}»\n\nК какому <b>курсу</b> он относится?", kb.as_markup(), delete_src=False)
        return
    await _preview(m, token, course, name)


async def _preview(target, token: str, course: int, name: str = ""):
    path = uploads_dir() / f"{token}.xlsx"
    if not path.exists():
        await show(target, "Файл уже не найден — пришлите заново.", delete_src=False)
        return
    res = await apply_data(path.read_bytes(), course, None, force=False, dry_run=True)
    suspicious = res.startswith("⛔")
    kb = InlineKeyboardBuilder()
    if suspicious:
        kb.button(text="⚠️ Всё равно применить (с рассылкой)", callback_data=f"up:go:{token}:{course}:1:1")
        kb.button(text="🤫 Всё равно применить, без рассылки", callback_data=f"up:go:{token}:{course}:0:1")
    elif not res.startswith("❌"):
        kb.button(text="✅ Применить и разослать изменения", callback_data=f"up:go:{token}:{course}:1:0")
        kb.button(text="🤫 Применить без рассылки", callback_data=f"up:go:{token}:{course}:0:0")
    kb.button(text="❌ Отмена", callback_data=f"up:no:{token}")
    kb.adjust(1)
    note = ("\n\n<i>Студенты ничего не заметят, пока не нажмёте «Применить»: до этого это только предпросмотр.</i>"
            if not suspicious else "")
    await show(target, f"📥 <b>Файл · {course} курс</b>{(' · ' + esc(name)) if name else ''}\n\n{res}{note}",
               kb.as_markup(), delete_src=False)


@router.callback_query(F.data.startswith("up:c:"))
async def cb_upload_course(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    _, _, token, course = c.data.split(":")
    await show(c, "⏳ Разбираю файл…")
    await _preview(c, token, int(course))


@router.callback_query(F.data.startswith("up:go:"))
async def cb_upload_go(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    _, _, token, course, notify, force = c.data.split(":")
    path = uploads_dir() / f"{token}.xlsx"
    if not path.exists():
        return await c.answer("Файл уже не найден — пришлите заново", show_alert=True)
    await show(c, "⏳ Применяю…")
    res = await apply_data(path.read_bytes(), int(course), bot, force=bool(int(force)), notify=bool(int(notify)))
    path.unlink(missing_ok=True)
    await show(c, f"<b>Готово</b>\n\n{res}", back_kb("ad:home", "⬅️ В админку"))


@router.callback_query(F.data.startswith("up:no:"))
async def cb_upload_cancel(c: CallbackQuery):
    (uploads_dir() / f"{c.data.split(':')[2]}.xlsx").unlink(missing_ok=True)
    await admin_home(c)


# ───────────────────────── админы ─────────────────────────

async def _names(ids: set[int]) -> dict[int, str]:
    async with Session() as s:
        rows = await s.execute(select(User.tg_id, User.username, User.full_name).where(User.tg_id.in_(ids or {0})))
    out = {i: str(i) for i in ids}
    for i, un, fn in rows:
        out[i] = (f"{fn} (@{un})" if un else fn) or str(i)
    return out


async def show_admins(c: CallbackQuery):
    owners, extra = sorted(settings.owners), sorted(access.extra_admins())
    names = await _names(set(owners) | set(extra))
    lines = ["🛡 <b>Админы</b>", "", "👑 <b>Владельцы</b> (из настроек сервера, могут обновлять код бота):"]
    lines += [f"• {esc(names[i])} · <code>{i}</code>" for i in owners] or ["—"]
    lines += ["", "🛠 <b>Админы</b> (добавлены через бота):"]
    lines += [f"• {esc(names[i])} · <code>{i}</code>" for i in extra] or ["пока нет"]
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Добавить админа", callback_data="ad:addadm")
    if access.is_owner(c.from_user.id):
        for i in extra:
            kb.button(text=f"➖ Убрать: {names[i][:24]}", callback_data=f"ad:deladm:{i}")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    await show(c, "\n".join(lines), kb.as_markup())


@router.callback_query(F.data == "ad:admins")
async def cb_admins(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await show_admins(c)


@router.callback_query(F.data == "ad:addadm")
async def cb_add_admin(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await set_state(c.from_user.id, "adm_add")
    await show(c, "➕ <b>Новый админ</b>\n\nПришли одно из:\n"
                  "• <b>Telegram ID</b> (число; узнать у @userinfobot)\n"
                  "• <b>@username</b> — если человек уже запускал этого бота\n"
                  "• любое <b>пересланное сообщение</b> от него\n\n"
                  "Человеку нужно хотя бы раз нажать /start в этом боте.", back_kb("ad:admins", "⬅️ Отмена"))


def _forwarded_id(m: Message) -> int | None:
    fo = getattr(m, "forward_origin", None)
    if fo is not None and getattr(fo, "type", "") == "user":
        return fo.sender_user.id
    ff = getattr(m, "forward_from", None)
    return ff.id if ff else None


@router.message(InState("adm_add"))
async def on_add_admin(m: Message):
    if _deny(m):
        return
    uid = _forwarded_id(m)
    text = (m.text or "").strip()
    await eat(m)
    if uid is None and text.lstrip("-").isdigit():
        uid = int(text)
    if uid is None and text.startswith("@"):
        async with Session() as s:
            uid = await s.scalar(select(User.tg_id).where(func.lower(User.username) == text[1:].lower()))
        if uid is None:
            await ephemeral(m, "Не знаю такого @username 🤷 Пусть сначала нажмёт /start в боте, или пришли его ID.", 8)
            return
    if uid is None:
        await ephemeral(m, "Не смог определить пользователя. Пришли ID, @username или пересланное сообщение "
                           "(если пересылка скрыта — используй ID).", 8)
        return
    async with Session() as s:
        known = await s.get(User, uid)
    added = await access.add_admin(uid, m.from_user.id)
    await set_state(m.from_user.id)
    if added:
        await enqueue(uid, "🛠 <b>Вас назначили администратором бота.</b>\nПанель — кнопка «🛠 Админ» или /admin "
                           "(если кнопки нет — нажмите /start).", priority=PRIO_ADMIN,
                      dedupe_key=f"newadm:{uid}:{now_local():%Y%m%d%H%M}")
        await ephemeral(m, f"✅ Админ <code>{uid}</code> добавлен" +
                        ("" if known else "\n⚠️ Он ещё не запускал бота — пусть нажмёт /start."), 8)
    else:
        await ephemeral(m, "Он уже админ 👌", 5)
    await _admins_screen_for_message(m)


async def _admins_screen_for_message(m: Message):
    owners, extra = sorted(settings.owners), sorted(access.extra_admins())
    names = await _names(set(owners) | set(extra))
    lines = ["🛡 <b>Админы</b>", ""] + [f"👑 {esc(names[i])} · <code>{i}</code>" for i in owners] + \
            [f"🛠 {esc(names[i])} · <code>{i}</code>" for i in extra]
    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Ещё админ", callback_data="ad:addadm")
    kb.button(text="⬅️ В админку", callback_data="ad:home")
    kb.adjust(1)
    await show(m, "\n".join(lines), kb.as_markup(), delete_src=False)


@router.callback_query(F.data.startswith("ad:deladm:"))
async def cb_del_admin(c: CallbackQuery):
    if not access.is_owner(c.from_user.id):
        return await c.answer("Убирать админов могут только владельцы", show_alert=True)
    await access.remove_admin(int(c.data.split(":")[2]))
    await show_admins(c)


# ───────────────────────── статистика / бэкап ─────────────────────────

async def stats_text() -> str:
    now = now_local()
    async with Session() as s:
        users = await s.scalar(select(func.count()).select_from(User))
        with_group = await s.scalar(select(func.count()).select_from(User).where(User.group_id.is_not(None)))
        blocked = await s.scalar(select(func.count()).select_from(User).where(User.blocked.is_(True)))
        news_off = await s.scalar(select(func.count()).select_from(User).where(User.news_on.is_(False)))
        day = await s.scalar(select(func.count()).select_from(User).where(User.last_seen >= now - timedelta(days=1)))
        week = await s.scalar(select(func.count()).select_from(User).where(User.last_seen >= now - timedelta(days=7)))
        groups = await s.scalar(select(func.count()).select_from(Group))
        lessons = await s.scalar(select(func.count()).select_from(Lesson).where(Lesson.deleted.is_(False)))
        manual = await s.scalar(select(func.count()).select_from(Lesson).where(Lesson.manual.is_(True)))
        pending = await s.scalar(select(func.count()).select_from(Outbox).where(Outbox.status == 0))
        by_course = (await s.execute(select(Group.course, func.count(User.tg_id)).join(User, User.group_id == Group.id)
                                     .group_by(Group.course).order_by(Group.course))).all()
        top = (await s.execute(select(Group.course, Group.title, func.count(User.tg_id)).join(User, User.group_id == Group.id)
                               .group_by(Group.id).order_by(func.count(User.tg_id).desc()).limit(8))).all()
    lines = ["📊 <b>Статистика</b>", "",
             f"👥 Всего: <b>{users}</b> (с группой: {with_group})",
             f"🟢 Заходили за сутки: <b>{day}</b> · за неделю: <b>{week}</b>",
             f"🚫 Заблокировали бота: {blocked} · 🔕 без новостей: {news_off}",
             f"📚 Программ: {groups} · пар: {lessons} · ✋ ручных правок: {manual}",
             f"📨 В очереди на отправку: {pending}"]
    if by_course:
        lines += ["", "<b>По курсам:</b> " + " · ".join(f"{c} курс — {n}" for c, n in by_course)]
    if top:
        lines += ["", "<b>Больше всего студентов:</b>"] + [f"• {c} курс · {esc(t)} — {n}" for c, t, n in top]
    return "\n".join(lines)


@router.callback_query(F.data == "ad:stats")
async def cb_stats(c: CallbackQuery):
    if _deny(c):
        return await c.answer()
    await show(c, await stats_text(), back_kb("ad:home", "⬅️ В админку"))


@router.message(Command("stats"))
async def cmd_stats(m: Message):
    if _deny(m):
        return
    await show(m, await stats_text(), back_kb("ad:home", "⬅️ В админку"))


@router.callback_query(F.data == "ad:backup")
async def cb_backup(c: CallbackQuery, bot: Bot):
    if _deny(c):
        return await c.answer()
    await c.answer("Делаю бэкап…")
    n = await send_backup(bot, [c.from_user.id], "💾 Резервная копия по запросу")
    if not n:
        await ephemeral(c.message, "❌ Не получилось сделать бэкап (см. логи)", 6)


@router.message(Command("backup"))
async def cmd_backup(m: Message, bot: Bot):
    if _deny(m):
        return
    await eat(m)
    await send_backup(bot, [m.from_user.id], "💾 Резервная копия по запросу")
