"""Расписание в памяти: пары всех программ занимают считанные килобайты,
а читаются они постоянно (каждая команда, каждая минута тика)."""
from collections import defaultdict
from dataclasses import dataclass
from datetime import time

from sqlalchemy import select

from .db import Group, Lesson, Session


def _parse_segments(s: str) -> tuple[tuple[time, time], ...]:
    out = []
    for part in (s or "").split("|"):
        try:
            a, b = part.split("-")
            out.append((time(int(a[:2]), int(a[3:5])), time(int(b[:2]), int(b[3:5]))))
        except (ValueError, IndexError):
            continue
    return tuple(out)


@dataclass(frozen=True)
class CL:
    group_id: int
    weekday: int
    parity: int
    subgroup: str
    start: time
    end: time
    subject: str
    teacher: str
    room: str
    kind: str
    segments: tuple


class ScheduleCache:
    def __init__(self) -> None:
        self._by_gd: dict[tuple[int, int], list[CL]] = {}
        self._by_wd: dict[int, dict[int, list[CL]]] = {}
        self.titles: dict[int, str] = {}

    async def reload(self) -> None:
        async with Session() as s:
            rows = list(await s.scalars(select(Lesson)))
            groups = list(await s.scalars(select(Group)))
        by_gd: dict[tuple[int, int], list[CL]] = defaultdict(list)
        by_wd: dict[int, dict[int, list[CL]]] = defaultdict(lambda: defaultdict(list))
        for l in rows:
            cl = CL(l.group_id, l.weekday, l.parity, l.subgroup, l.start, l.end, l.subject,
                    l.teacher, l.room, l.kind, _parse_segments(l.segments))
            by_gd[(l.group_id, l.weekday)].append(cl)
            by_wd[l.weekday][l.group_id].append(cl)
        self._by_gd, self._by_wd = dict(by_gd), {k: dict(v) for k, v in by_wd.items()}
        self.titles = {g.id: (g.title or g.name) for g in groups}

    def lessons(self, group_id: int, weekday: int) -> list[CL]:
        return self._by_gd.get((group_id, weekday), [])

    def groups_on(self, weekday: int):
        return self._by_wd.get(weekday, {}).items()

    def title(self, group_id: int | None) -> str:
        return self.titles.get(group_id or 0, "")


cache = ScheduleCache()
