"""Расписание в памяти: пары всех групп занимают считанные килобайты,
а читаются они постоянно (каждая команда, каждая минута тика)."""
from collections import defaultdict
from dataclasses import dataclass
from datetime import time

from sqlalchemy import select

from .db import Lesson, Session


@dataclass(frozen=True)
class CL:
    group_id: int
    weekday: int
    parity: int
    subgroup: str
    start: time
    end: time
    subject: str
    teacher: str
    room: str
    kind: str


class ScheduleCache:
    def __init__(self) -> None:
        self._by_gd: dict[tuple[int, int], list[CL]] = {}
        self._by_wd: dict[int, dict[int, list[CL]]] = {}

    async def reload(self) -> None:
        async with Session() as s:
            rows = list(await s.scalars(select(Lesson)))
        by_gd: dict[tuple[int, int], list[CL]] = defaultdict(list)
        by_wd: dict[int, dict[int, list[CL]]] = defaultdict(lambda: defaultdict(list))
        for l in rows:
            cl = CL(l.group_id, l.weekday, l.parity, l.subgroup, l.start, l.end,
                    l.subject, l.teacher, l.room, l.kind)
            by_gd[(l.group_id, l.weekday)].append(cl)
            by_wd[l.weekday][l.group_id].append(cl)
        self._by_gd, self._by_wd = dict(by_gd), {k: dict(v) for k, v in by_wd.items()}

    def lessons(self, group_id: int, weekday: int) -> list[CL]:
        return self._by_gd.get((group_id, weekday), [])

    def groups_on(self, weekday: int):
        return self._by_wd.get(weekday, {}).items()


cache = ScheduleCache()
