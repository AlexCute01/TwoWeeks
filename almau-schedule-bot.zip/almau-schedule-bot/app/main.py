"""Точка входа: Telegram (long polling) + фоновые циклы (очередь, напоминания, автоочистка, отчёт об обновлении)."""
import asyncio
import logging
from pathlib import Path

import yaml
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand

from . import access, admin, admin_editor, admin_posts, admin_rooms, admin_users, handlers, updater
from .cache import cache
from .config import settings
from .db import Room, Session
from .migrate import migrate
from .notify import run_due
from .outbox import janitor_loop, sender_loop
from .util import norm_room

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")


async def seed_rooms() -> None:
    """Загружает data/rooms.yaml — только те аудитории, которых ещё нет в БД (правки админов не затираются)."""
    path = Path(__file__).parent.parent / "data" / "rooms.yaml"
    if not path.exists():
        return
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or []
    async with Session() as s:
        for r in data:
            code = norm_room(str(r["code"]))
            if not await s.get(Room, code):
                s.add(Room(code=code, building=r.get("building", ""), floor=r.get("floor"),
                           description=r.get("description", ""), photo_id=""))
        await s.commit()


async def tick_loop(bot: Bot) -> None:
    while True:
        try:
            await run_due(bot)
            await updater.check_report(bot)
        except Exception:
            log.exception("tick_loop")
        await asyncio.sleep(20)


async def main() -> None:
    Path(settings.data_dir).mkdir(parents=True, exist_ok=True)
    await migrate()                      # безопасно: перед изменениями схемы делает бэкап
    await seed_rooms()
    await access.load()
    await cache.reload()

    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    # порядок важен: специфичные состояния и админ-экраны — раньше общего текстового обработчика студентов
    for r in (admin_posts.router, admin_users.router, admin_rooms.router, admin_editor.router,
              updater.router, admin.router, handlers.router):
        dp.include_router(r)

    await bot.set_my_commands([
        BotCommand(command="today", description="📅 Расписание на сегодня"),
        BotCommand(command="tomorrow", description="📆 На завтра"),
        BotCommand(command="week", description="🗓 На неделю"),
        BotCommand(command="next", description="⏭ Ближайшая пара"),
        BotCommand(command="settings", description="⚙️ Настройки"),
        BotCommand(command="help", description="📖 Помощь"),
    ])
    tasks = [asyncio.create_task(c) for c in (sender_loop(bot), janitor_loop(bot), tick_loop(bot))]
    log.info("bot started")
    try:
        await bot.delete_webhook(drop_pending_updates=False)
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        for t in tasks:
            t.cancel()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
