"""Точка входа: Telegram (long polling) + фоновые циклы (очередь отправки, напоминания и проверка расписания)."""
import asyncio
import logging
from pathlib import Path

import yaml
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand

from . import access
from .admin import router as admin_router
from .cache import cache
from .db import Room, Session
from .handlers import router as user_router
from .migrate import migrate
from .notify import run_due
from .outbox import sender_loop
from .util import norm_room
from .config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")


async def seed_rooms() -> None:
    """Загружает data/rooms.yaml — только те аудитории, которых ещё нет в БД (правки через /setroom не затираются)."""
    path = Path(__file__).parent.parent / "data" / "rooms.yaml"
    if not path.exists():
        return
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or []
    async with Session() as s:
        for r in data:
            code = norm_room(str(r["code"]))
            if not await s.get(Room, code):
                s.add(Room(code=code, building=r.get("building", ""), floor=r.get("floor"),
                           description=r.get("description", "")))
        await s.commit()


async def tick_loop(bot: Bot) -> None:
    while True:
        try:
            await run_due(bot)
        except Exception:
            log.exception("tick_loop")
        await asyncio.sleep(20)


async def main() -> None:
    Path(settings.data_dir).mkdir(parents=True, exist_ok=True)
    await migrate()                      # безопасно: перед изменениями схемы делает бэкап
    await seed_rooms()
    await access.load()
    await cache.reload()

    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(admin_router)      # порядок важен: состояния админа — раньше общего текстового обработчика
    dp.include_router(user_router)

    await bot.set_my_commands([
        BotCommand(command="today", description="📅 Расписание на сегодня"),
        BotCommand(command="tomorrow", description="📆 На завтра"),
        BotCommand(command="week", description="🗓 На неделю"),
        BotCommand(command="next", description="⏭ Ближайшая пара"),
        BotCommand(command="news", description="📰 Новости"),
        BotCommand(command="settings", description="⚙️ Настройки"),
        BotCommand(command="help", description="📖 Помощь"),
    ])
    tasks = [asyncio.create_task(c) for c in (sender_loop(bot), tick_loop(bot))]
    log.info("bot started")
    try:
        await bot.delete_webhook(drop_pending_updates=False)
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        for t in tasks:
            t.cancel()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
